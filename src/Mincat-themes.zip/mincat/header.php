<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_lg   = mincat_logged_in();
$mincat_dash = (bool) get_query_var( 'mincat_dash', false );
?><!doctype html>
<html lang="id">
	<head>
		<link rel="icon" type="image/webp" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mincat-favicon.webp">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<title>MINCAT — Small Steps, Big Future</title>
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
		<style id="mincat-noadminbar">
#wpadminbar {
  display: none !important;
}
html {
  margin-top: 0 !important;
}
</style>
		<?php wp_head(); ?>
	</head>
	<body<?php echo $mincat_lg ? '' : ' class="guest"'; ?>>
		<header class="top">
			<a class="brand<?php echo mincat_is_page( 'home' ) ? ' active' : ''; ?>" href="<?php echo esc_url( mincat_url( 'home' ) ); ?>" data-page="home"<?php echo mincat_active_attrs( 'home' ); ?>><img class="logo-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mincat-logo.webp" alt="MINCAT" width="140" height="37"></a>
			<nav class="nav">
				<?php echo mincat_header_nav_html(); ?>
			</nav>
			<div id="authArea">
				<?php echo mincat_auth_html(); ?>
			</div>
		</header>
		<main class="shell<?php echo $mincat_dash ? '' : ' page-in'; ?>" id="view"<?php echo $mincat_dash ? ' hidden' : ''; ?>>