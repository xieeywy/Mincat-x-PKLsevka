<?php
/**
 * Lengkapi akun: username, nama tampil, dan password. Wajib untuk akun baru (termasuk dari Google).
 * Pemrosesan form ada di inc/mincat-auth.php.
 */

if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}

$mincat_user  = wp_get_current_user();
$mincat_error = get_transient( 'mincat_setup_error_' . $mincat_user->ID );
if ( $mincat_error ) {
	delete_transient( 'mincat_setup_error_' . $mincat_user->ID );
}

get_header();
?>
<section class="auth-wrap">
	<div class="auth-card">
		<div class="eyebrow">
			Langkah terakhir
		</div>
		<h1>
			Lengkapi akunmu
		</h1>
		<p class="tiny muted">
			Atur username dan password supaya kamu bisa masuk tanpa Google. Email kamu tetap <b><?php echo esc_html( $mincat_user->user_email ); ?></b>.
		</p>

		<?php if ( $mincat_error ) : ?>
		<p class="auth-error" role="alert">
			<?php echo esc_html( $mincat_error ); ?>
		</p>
		<?php endif; ?>

		<form class="auth-form" method="post" action="<?php echo esc_url( mincat_url( 'lengkapi-akun' ) ); ?>" novalidate>
			<?php wp_nonce_field( 'mincat_setup', 'mincat_setup_nonce' ); ?>
			<label for="su-name">Nama tampil</label>
			<input id="su-name" name="display_name" type="text" class="fld" value="<?php echo esc_attr( $mincat_user->display_name ); ?>" required>

			<label for="su-user">Username</label>
			<input id="su-user" name="username" type="text" class="fld" value="<?php echo esc_attr( $mincat_user->user_login ); ?>" pattern="[a-z0-9._]{3,20}" required>
			<p class="tiny muted" style="margin:4px 0 0">
				Huruf kecil, angka, titik, atau garis bawah. 3–20 karakter.
			</p>

			<label for="su-pass">Password baru</label>
			<input id="su-pass" name="password" type="password" class="fld" minlength="8" autocomplete="new-password" required>

			<label for="su-pass2">Ulangi password</label>
			<input id="su-pass2" name="password2" type="password" class="fld" minlength="8" autocomplete="new-password" required>

			<button class="auth-submit" type="submit">Simpan dan lanjut</button>
		</form>
	</div>
</section>
<?php get_footer(); ?>
