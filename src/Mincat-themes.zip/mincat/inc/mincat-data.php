<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ===================== Custom post type ===================== */

function mincat_register_cpts() {
	$types = array(
		'mincat_karya'    => 'Karya',
		'mincat_peluang'  => 'Peluang PKL',
		'mincat_mitra'    => 'Mitra',
		'mincat_lamaran'  => 'Lamaran',
		'mincat_jurnal'   => 'Jurnal PKL',
		'mincat_pesan'    => 'Pesan',
		'mincat_request'  => 'Permintaan akses',
	);
	foreach ( $types as $slug => $label ) {
		register_post_type(
			$slug,
			array(
				'label'        => $label,
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => true,
				'supports'     => array( 'title', 'editor', 'author', 'custom-fields' ),
				'has_archive'  => false,
				'rewrite'      => false,
			)
		);
	}
}
add_action( 'init', 'mincat_register_cpts' );

/** Ambil satu meta post. */
function mincat_meta( $id, $key, $default = '' ) {
	$v = get_post_meta( $id, $key, true );
	return ( '' === $v || null === $v ) ? $default : $v;
}

/* ===================== Sesi, peran, profil ===================== */

/** Db.isLoggedIn() */
function mincat_logged_in() {
	return is_user_logged_in();
}

/**
 * Db.getRole(). Akun tanpa peran = visitor (sesuai teks halaman Masuk: "Akun baru otomatis berstatus Visitor").
 * Administrator WordPress dianggap admin sekolah.
 */
function mincat_role() {
	if ( ! is_user_logged_in() ) {
		return null;
	}
	$user = wp_get_current_user();
	// Role dari plugin mincat-core (diatur di Users > Edit). Urutan ini menentukan prioritas.
	$map = array(
		'mincat_student'  => 'siswa',
		'mincat_teacher'  => 'guru',
		'mincat_mentor'   => 'mentor',
		'mincat_company'  => 'perusahaan',
		'mincat_wali'     => 'wali',
		'mincat_visitor'  => 'visitor',
	);
	foreach ( $map as $wp_role => $mincat_role ) {
		if ( in_array( $wp_role, (array) $user->roles, true ) ) {
			return $mincat_role;
		}
	}
	if ( current_user_can( 'manage_options' ) ) {
		return 'admin';
	}
	// Cadangan untuk data lama yang menyimpan peran di user meta.
	$r = get_user_meta( $user->ID, 'mincat_role', true );
	return $r ? $r : 'visitor';
}

/** Db.getRole()||'siswa' */
function mincat_nav_role() {
	$r = mincat_role();
	return $r ? $r : 'siswa';
}

/** Db.profile() */
function mincat_profile() {
	$u = wp_get_current_user();
	return array(
		'name'     => $u->exists() ? $u->display_name : '',
		'jurusan'  => $u->exists() ? (string) get_user_meta( $u->ID, 'mincat_jurusan', true ) : '',
		'username' => $u->exists() ? $u->user_login : '',
		'email'    => $u->exists() ? $u->user_email : '',
		'photo'    => $u->exists() ? (string) get_user_meta( $u->ID, 'mincat_photo', true ) : '',
	);
}

/** Db.profile().name.split(' ')[0] */
function mincat_first_name() {
	$p     = mincat_profile();
	$parts = explode( ' ', $p['name'] );
	return $parts[0];
}

/**
 * enforceRole(): tamu ke halaman privat -> Masuk; peran yang tidak berhak -> halaman pertamanya.
 * Panggil di awal template privat SEBELUM get_header().
 */
function mincat_enforce_role( $page ) {
	$public = array( 'home', 'about', 'masuk', 'shared', 'lengkapi-akun', 'opportunities', 'portfolio' );
	if ( in_array( $page, $public, true ) ) {
		return;
	}
	$r = mincat_role();
	if ( ! is_user_logged_in() || ! $r ) {
		wp_safe_redirect( mincat_url( 'masuk' ) );
		exit;
	}
	$nav     = mincat_role_nav();
	$allowed = array( 'home', 'about', 'shared', 'masuk', 'akun', 'verifikasi', 'jobdetail', 'portofolio-detail' );
	foreach ( $nav[ $r ] as $it ) {
		$allowed[] = $it[0];
	}
	if ( ! in_array( $page, $allowed, true ) ) {
		wp_safe_redirect( mincat_url( $nav[ $r ][0][0] ) );
		exit;
	}
}

/* ===================== Karya ===================== */

function mincat_project_from_post( $p ) {
	$id = $p->ID;
	return array(
		'id'       => $id,
		'author'   => (int) $p->post_author,
		't'        => get_the_title( $p ),
		'c'        => (string) mincat_meta( $id, 'c' ),
		's'        => (string) mincat_meta( $id, 's', 'Menunggu Review' ),
		'k'        => (string) mincat_meta( $id, 'k', 'review' ),
		'showcase' => (bool) mincat_meta( $id, 'showcase', 0 ),
		'art'      => (string) mincat_meta( $id, 'art' ),
		'd'        => (string) $p->post_content,
		'tools'    => (array) mincat_meta( $id, 'tools', array() ),
		'role'     => (string) mincat_meta( $id, 'role' ),
		'jenis'    => (string) mincat_meta( $id, 'jenis' ),
		'hasil'    => (string) mincat_meta( $id, 'hasil' ),
		'fb'       => (string) mincat_meta( $id, 'fb' ),
		'detail'   => (array) mincat_meta( $id, 'detail', array() ),
		'hist'     => (array) mincat_meta( $id, 'hist', array() ),
	);
}

/** Db.projects() untuk siswa yang sedang login (atau $uid). */
function mincat_projects( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	if ( ! $uid ) {
		return array();
	}
	$posts = get_posts(
		array(
			'post_type'   => 'mincat_karya',
			'author'      => $uid,
			'numberposts' => -1,
			'post_status' => 'publish',
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);
	return array_map( 'mincat_project_from_post', $posts );
}

/**
 * Karya tampil di halaman depan:
 * Db.consent().showcase ? Db.projects().filter(k==='verified' && showcase) : []
 * Dihitung untuk SEMUA siswa (halaman depan publik); hanya siswa yang persetujuannya aktif.
 */
function mincat_showcase_projects() {
	$posts = get_posts(
		array(
			'post_type'   => 'mincat_karya',
			'numberposts' => -1,
			'post_status' => 'publish',
			'orderby'     => 'date',
			'order'       => 'DESC',
			'meta_query'  => array(
				array(
					'key'   => 'k',
					'value' => 'verified',
				),
				array(
					'key'   => 'showcase',
					'value' => '1',
				),
			),
		)
	);
	$out = array();
	foreach ( $posts as $post ) {
		$p        = mincat_project_from_post( $post );
		$u        = get_userdata( (int) $post->post_author );
		$p['ini'] = $u ? mincat_initials( $u->display_name ) : '';
		$p['photo']       = $u ? (string) get_user_meta( $u->ID, 'mincat_photo', true ) : '';
		$p['banner_html'] = mincat_karya_banner( (int) $post->ID );
		$jur      = $u ? (string) get_user_meta( $u->ID, 'mincat_jurusan', true ) : '';
		$p['jur'] = $jur ? $jur : $p['c'];
		$out[]    = $p;
	}
	return $out;
}

/** Db.consent() */
function mincat_consent( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	$c   = $uid ? get_user_meta( $uid, 'mincat_consent', true ) : array();
	$c   = is_array( $c ) ? $c : array();
	return array_merge(
		array(
			'showcase' => false,
			'share'    => false,
			'kontak'   => false,
		),
		$c
	);
}

/* ===================== Peluang, mitra, lamaran ===================== */

function mincat_jobs() {
	$posts = get_posts(
		array(
			'post_type'   => 'mincat_peluang',
			'numberposts' => -1,
			'post_status' => 'publish',
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);
	$out = array();
	foreach ( $posts as $p ) {
		$id         = $p->ID;
		$perusahaan = (string) mincat_meta( $id, 'perusahaan' );
		$logo       = (string) mincat_meta( $id, 'logo' );
		$j          = array(
			0    => get_the_title( $p ),
			1    => $perusahaan,
			2    => (string) mincat_meta( $id, 'lokasi' ),
			3    => (string) mincat_meta( $id, 'bidang' ),
			4    => (string) mincat_meta( $id, 'durasi' ),
			5    => (string) mincat_meta( $id, 'uang_saku' ),
			6    => (string) mincat_meta( $id, 'tenggat' ),
			7    => $logo ? $logo : mb_strtoupper( mb_substr( $perusahaan, 0, 1 ) ),
			8    => (array) mincat_meta( $id, 'skills', array() ),
			9    => (string) mincat_meta( $id, 'status', 'disetujui' ),
			'id' => $id,
		);
		$out[]      = $j;
	}
	return $out;
}

/** S.jobs.filter(j => (j[9]||'disetujui')==='disetujui') */
function mincat_approved_jobs() {
	$out = array();
	foreach ( mincat_jobs() as $j ) {
		if ( 'disetujui' === ( $j[9] ? $j[9] : 'disetujui' ) ) {
			$out[] = $j;
		}
	}
	return $out;
}

/** Db.mitra() */
function mincat_mitra() {
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_mitra',
				'numberposts' => -1,
				'post_status' => 'publish',
				'orderby'     => 'menu_order date',
				'order'       => 'ASC',
			)
		) as $p ) {
		$out[] = array(
			'nama'   => get_the_title( $p ),
			'bidang' => (string) mincat_meta( $p->ID, 'bidang' ),
			'kota'   => (string) mincat_meta( $p->ID, 'kota' ),
		);
	}
	return $out;
}

/* ===================== Jurnal, pesan, notifikasi, permintaan akses ===================== */

/** Db.jurnal() */
function mincat_jurnal( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	if ( ! $uid ) {
		return array();
	}
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_jurnal',
				'author'      => $uid,
				'numberposts' => -1,
				'post_status' => 'publish',
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		) as $p ) {
		$out[] = array(
			'id'       => $p->ID,
			'tgl'      => (string) mincat_meta( $p->ID, 'tgl' ),
			'kegiatan' => (string) mincat_meta( $p->ID, 'kegiatan' ),
			'kendala'  => (string) mincat_meta( $p->ID, 'kendala' ),
			'solusi'   => (string) mincat_meta( $p->ID, 'solusi' ),
			'status'   => (string) mincat_meta( $p->ID, 'status', 'draft' ),
			'catatan'  => (string) mincat_meta( $p->ID, 'catatan' ),
		);
	}
	return $out;
}

/**
 * Db.pesan(): siswa melihat pesan yang ditujukan kepadanya; perusahaan melihat pesan yang ia kirim.
 * Setiap item: id, dari, untuk(nama), lamaran, isi, status, kontak, t.
 */
function mincat_pesan() {
	$uid  = get_current_user_id();
	$role = mincat_role();
	if ( ! $uid ) {
		return array();
	}
	$args = array(
		'post_type'   => 'mincat_pesan',
		'numberposts' => -1,
		'post_status' => 'publish',
		'orderby'     => 'date',
		'order'       => 'DESC',
	);
	if ( 'siswa' === $role ) {
		$args['meta_key']   = 'untuk';
		$args['meta_value'] = $uid;
	} else {
		$args['author'] = $uid;
	}
	$out = array();
	foreach ( get_posts( $args ) as $p ) {
		$to    = get_userdata( (int) mincat_meta( $p->ID, 'untuk', 0 ) );
		$from  = get_userdata( (int) $p->post_author );
		$out[] = array(
			'id'      => $p->ID,
			'dari'    => $from ? $from->display_name : '',
			'untuk'   => $to ? $to->display_name : '',
			'lamaran' => (string) mincat_meta( $p->ID, 'lamaran' ),
			'isi'     => (string) mincat_meta( $p->ID, 'isi' ),
			'status'  => (string) mincat_meta( $p->ID, 'status', 'menunggu' ),
			'kontak'  => (string) mincat_meta( $p->ID, 'kontak' ),
			't'       => get_the_date( 'j M, H.i', $p ),
		);
	}
	return $out;
}

/** Db.notifs() */
function mincat_notifs() {
	$n = get_user_meta( get_current_user_id(), 'mincat_notif', true );
	return is_array( $n ) ? $n : array();
}

/** unreadCount() */
function mincat_unread_count() {
	$c = 0;
	foreach ( mincat_notifs() as $n ) {
		if ( empty( $n['read'] ) ) {
			$c++;
		}
	}
	return $c;
}

/** Db.requests().filter(r => r.email === email) */
function mincat_requests_for( $email ) {
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_request',
				'numberposts' => -1,
				'post_status' => 'publish',
				'meta_key'    => 'email',
				'meta_value'  => $email,
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		) as $p ) {
		$out[] = array(
			'id'     => $p->ID,
			'email'  => (string) mincat_meta( $p->ID, 'email' ),
			'name'   => (string) mincat_meta( $p->ID, 'name' ),
			'role'   => (string) mincat_meta( $p->ID, 'role' ),
			'data'   => (array) mincat_meta( $p->ID, 'data', array() ),
			'status' => (string) mincat_meta( $p->ID, 'status', 'menunggu' ),
			'note'   => (string) mincat_meta( $p->ID, 'note' ),
			't'      => get_the_date( 'j M, H.i', $p ),
		);
	}
	return $out;
}

function mincat_apps( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	if ( ! $uid ) {
		return array();
	}
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_lamaran',
				'author'      => $uid,
				'numberposts' => -1,
				'post_status' => 'publish',
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		) as $p ) {
		$out[] = array(
			0    => (string) mincat_meta( $p->ID, 'lowongan' ),
			1    => (string) mincat_meta( $p->ID, 'perusahaan' ),
			2    => (string) mincat_meta( $p->ID, 'status', 'Menunggu Tinjauan' ),
			3    => (int) mincat_meta( $p->ID, 'karya_id', 0 ),
			'id' => $p->ID,
		);
	}
	return $out;
}

/** Db.saved(): judul lowongan yang disimpan. */
function mincat_saved() {
	$s = get_user_meta( get_current_user_id(), 'mincat_saved', true );
	return is_array( $s ) ? $s : array();
}

/** Db.requests() (semua; untuk admin). */
function mincat_requests_all() {
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_request',
				'numberposts' => -1,
				'post_status' => 'publish',
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		) as $p ) {
		$out[] = array(
			'id'     => $p->ID,
			'email'  => (string) mincat_meta( $p->ID, 'email' ),
			'name'   => (string) mincat_meta( $p->ID, 'name' ),
			'role'   => (string) mincat_meta( $p->ID, 'role' ),
			'data'   => (array) mincat_meta( $p->ID, 'data', array() ),
			'status' => (string) mincat_meta( $p->ID, 'status', 'menunggu' ),
			'note'   => (string) mincat_meta( $p->ID, 'note' ),
			't'      => get_the_date( 'j M, H.i', $p ),
		);
	}
	return $out;
}

/** Semua karya yang sudah dipublikasikan dari seluruh siswa (halaman Portofolio global). */
function mincat_projects_all() {
	$out = array();
	foreach ( get_posts(
			array(
				'post_type'   => 'mincat_karya',
				'numberposts' => -1,
				'post_status' => 'publish',
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		) as $p ) {
		$row          = mincat_project_from_post( $p );
		if ( 'verified' !== $row['k'] ) {
			continue;
		}
		$row['siswa'] = (string) get_the_author_meta( 'display_name', $p->post_author );
		$row['username'] = (string) get_the_author_meta( 'user_login', $p->post_author );
		$out[]        = $row;
	}
	return $out;
}
