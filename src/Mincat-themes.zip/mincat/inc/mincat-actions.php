<?php
/**
 * Aksi tombol (data-mincat-action). Satu endpoint admin-post dengan nonce dan pengecekan peran.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_post_mincat_act', 'mincat_action_handle' );

/** Balas dengan JSON galat. */
function mincat_act_fail( $msg, $code = 400 ) {
	wp_send_json_error( array( 'msg' => $msg ), $code );
}

function mincat_action_handle() {
	if ( ! is_user_logged_in() ) {
		mincat_act_fail( 'Masuk dulu untuk melakukan aksi ini.', 401 );
	}
	$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'mincat_act' ) ) {
		mincat_act_fail( 'Sesi tidak valid. Muat ulang halaman.', 403 );
	}

	$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
	$uid = get_current_user_id();
	$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

	switch ( $do ) {
		case 'toggle_consent':
			mincat_act_consent();
			break;

		case 'toggle_save':
			if ( ! $id || 'mincat_peluang' !== get_post_type( $id ) ) {
				mincat_act_fail( 'Lowongan tidak ditemukan.' );
			}
			$s  = mincat_saved();
			$on = ! in_array( $id, $s, true );
			$s  = $on ? array_merge( $s, array( $id ) ) : array_values( array_diff( $s, array( $id ) ) );
			update_user_meta( $uid, 'mincat_saved', $s );
			wp_send_json_success( array( 'on' => $on ) );
			break;

		case 'set_job_status':
			if ( ! current_user_can( 'manage_options' ) ) {
				mincat_act_fail( 'Hanya admin yang bisa mengubah status lowongan.', 403 );
			}
			$st = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
			if ( ! $id || 'mincat_peluang' !== get_post_type( $id ) || ! in_array( $st, array( 'disetujui', 'ditolak', 'menunggu' ), true ) ) {
				mincat_act_fail( 'Data tidak valid.' );
			}
			update_post_meta( $id, 'status', $st );
			wp_send_json_success();
			break;

		case 'toggle_notif':
			$n = mincat_notifs();
			foreach ( $n as $i => $x ) {
				if ( is_array( $x ) ) {
					$n[ $i ]['read'] = true;
				}
			}
			update_user_meta( $uid, 'mincat_notif', $n );
			wp_send_json_success();
			break;

		case 'bagikan_kontak':
		case 'tolak_pesan':
			$p = $id ? get_post( $id ) : null;
			if ( ! $p || 'mincat_pesan' !== $p->post_type ) {
				mincat_act_fail( 'Pesan tidak ditemukan.' );
			}
			if ( (int) get_post_meta( $id, 'untuk', true ) !== $uid ) {
				mincat_act_fail( 'Pesan ini bukan untukmu.', 403 );
			}
			update_post_meta( $id, 'status', 'bagikan_kontak' === $do ? 'kontak' : 'ditolak' );
			wp_send_json_success();
			break;

		case 'share_portfolio':
			$k = $id ? get_post( $id ) : null;
			if ( ! $k || 'mincat_karya' !== $k->post_type || (int) $k->post_author !== $uid ) {
				mincat_act_fail( 'Karya tidak ditemukan.', 403 );
			}
			if ( 'verified' !== get_post_meta( $id, 'k', true ) ) {
				mincat_act_fail( 'Hanya karya yang sudah terverifikasi yang bisa dibagikan.' );
			}
			$tok = (string) get_post_meta( $id, 'share_token', true );
			if ( '' === $tok ) {
				$tok = wp_generate_password( 24, false, false );
				update_post_meta( $id, 'share_token', $tok );
			}
			wp_send_json_success( array( 'url' => add_query_arg( array( 'karya' => $id, 't' => $tok ), mincat_url( 'portofolio-detail' ) ) ) );
			break;

		case 'download_data':
			mincat_act_download( $uid );
			break;

		case 'confirm_delete':
			mincat_act_delete( $uid );
			break;

		default:
			mincat_act_fail( 'Aksi tidak dikenal.' );
	}
}

/** Ubah persetujuan (showcase, share, kontak). Wali mengatur persetujuan anaknya. */
function mincat_act_consent() {
	$key = isset( $_POST['key'] ) ? sanitize_key( wp_unslash( $_POST['key'] ) ) : '';
	if ( ! in_array( $key, array( 'showcase', 'share', 'kontak' ), true ) ) {
		mincat_act_fail( 'Persetujuan tidak dikenal.' );
	}
	$uid    = get_current_user_id();
	$target = $uid;
	if ( 'wali' === mincat_role() ) {
		$target = (int) get_user_meta( $uid, 'mincat_anak_id', true );
		if ( ! $target ) {
			mincat_act_fail( 'Akun anak belum terhubung.' );
		}
	}
	$c         = mincat_consent( $target );
	$c[ $key ] = empty( $c[ $key ] );
	update_user_meta( $target, 'mincat_consent', $c );
	if ( 'showcase' === $key && empty( $c[ $key ] ) ) {
		foreach ( get_posts( array( 'post_type' => 'mincat_karya', 'numberposts' => -1, 'post_status' => 'any', 'author' => $target, 'fields' => 'ids' ) ) as $kid ) {
			update_post_meta( $kid, 'showcase', 0 );
		}
	}
	wp_send_json_success( array( 'on' => (bool) $c[ $key ] ) );
}

/** Unduh semua data akun dalam bentuk JSON. */
function mincat_act_download( $uid ) {
	$u    = get_userdata( $uid );
	$data = array(
		'akun'        => array(
			'username' => $u ? $u->user_login : '',
			'nama'     => $u ? $u->display_name : '',
			'email'    => $u ? $u->user_email : '',
			'peran'    => mincat_role(),
		),
		'profil'      => array(
			'telepon'  => (string) get_user_meta( $uid, 'mincat_phone', true ),
			'alamat'   => (string) get_user_meta( $uid, 'mincat_alamat', true ),
			'koordinat' => (string) get_user_meta( $uid, 'mincat_koord', true ),
			'jurusan'  => (string) get_user_meta( $uid, 'mincat_jurusan', true ),
		),
		'karya'       => function_exists( 'mincat_projects' ) ? mincat_projects( $uid ) : array(),
		'persetujuan' => mincat_consent( $uid ),
		'pesan'       => mincat_pesan(),
	);
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="mincat-data-saya.json"' );
	echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
	exit;
}

/** Hapus akun dan konten milik akun. Admin tidak bisa dihapus dari sini. */
function mincat_act_delete( $uid ) {
	$conf = isset( $_POST['confirm'] ) ? sanitize_text_field( wp_unslash( $_POST['confirm'] ) ) : '';
	if ( 'HAPUS' !== $conf ) {
		mincat_act_fail( 'Ketik HAPUS untuk konfirmasi.' );
	}
	if ( current_user_can( 'manage_options' ) ) {
		mincat_act_fail( 'Akun admin tidak bisa dihapus dari sini.', 403 );
	}
	foreach ( array( 'mincat_karya', 'mincat_lamaran', 'mincat_peluang' ) as $pt ) {
		foreach ( get_posts( array( 'post_type' => $pt, 'numberposts' => -1, 'post_status' => 'any', 'author' => $uid, 'fields' => 'ids' ) ) as $pid ) {
			wp_delete_post( $pid, true );
		}
	}
	foreach ( get_posts( array( 'post_type' => 'mincat_pesan', 'numberposts' => -1, 'post_status' => 'any', 'meta_key' => 'untuk', 'meta_value' => $uid, 'fields' => 'ids' ) ) as $pid ) {
		wp_delete_post( $pid, true );
	}
	require_once ABSPATH . 'wp-admin/includes/user.php';
	wp_logout();
	wp_delete_user( $uid );
	wp_send_json_success( array( 'redirect' => home_url( '/' ) ) );
}
