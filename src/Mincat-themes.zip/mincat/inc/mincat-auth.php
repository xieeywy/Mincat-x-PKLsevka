<?php
/**
 * Login dan pengaturan akun: akun baru (termasuk dari Google) wajib melengkapi username dan password.
 * Akun non-admin diarahkan ke Akun saya, tidak ke wp-admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Tandai setiap akun baru. */
function mincat_mark_new_user( $user_id ) {
	update_user_meta( $user_id, 'mincat_needs_setup', '1' );
	// Akun baru (termasuk dari Google lewat Nextend) otomatis berperan Visitor sampai disetujui admin.
	if ( get_role( 'mincat_visitor' ) ) {
		$user = new WP_User( $user_id );
		$user->set_role( 'mincat_visitor' );
	}
}
add_action( 'user_register', 'mincat_mark_new_user' );

function mincat_needs_setup( $user_id ) {
	return (bool) get_user_meta( $user_id, 'mincat_needs_setup', true );
}

/** Setelah login: akun baru ke Lengkapi akun, non-admin ke Akun saya. */
function mincat_login_redirect( $redirect_to, $request, $user ) {
	if ( is_wp_error( $user ) || ! $user ) {
		return $redirect_to;
	}
	if ( mincat_needs_setup( $user->ID ) ) {
		return mincat_url( 'lengkapi-akun' );
	}
	if ( ! user_can( $user, 'edit_posts' ) ) {
		return mincat_url( 'akun' );
	}
	return $redirect_to;
}
add_filter( 'login_redirect', 'mincat_login_redirect', 10, 3 );

/** Akun non-admin tidak masuk ke wp-admin. */
function mincat_block_wp_admin() {
	if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
		return;
	}
	// admin-post.php juga lewat admin_init. Jangan dialihkan di sini, karena handler form
	// (kirim permintaan, keputusan admin) harus tetap jalan.
	global $pagenow;
	if ( 'admin-post.php' === $pagenow ) {
		return;
	}
	if ( is_user_logged_in() && ! current_user_can( 'edit_posts' ) ) {
		wp_safe_redirect( mincat_url( 'akun' ) );
		exit;
	}
	// Login Google (Nextend) bisa berakhir di dashboard wp-admin tanpa lewat filter login_redirect.
	// Hanya administrator yang boleh ke dashboard wp-admin; peran lain dialihkan ke Akun saya.
	if ( is_user_logged_in() && 'index.php' === $pagenow && ! current_user_can( 'manage_options' ) ) {
		wp_safe_redirect( mincat_url( 'akun' ) );
		exit;
	}
}
add_action( 'admin_init', 'mincat_block_wp_admin' );

/** Akun yang belum lengkap hanya boleh di halaman Lengkapi akun. */
function mincat_enforce_setup() {
	if ( ! is_user_logged_in() || is_admin() ) {
		return;
	}
	if ( ! mincat_needs_setup( get_current_user_id() ) ) {
		return;
	}
	if ( is_page( 'lengkapi-akun' ) || is_page( 'masuk' ) ) {
		return;
	}
	wp_safe_redirect( mincat_url( 'lengkapi-akun' ) );
	exit;
}
add_action( 'template_redirect', 'mincat_enforce_setup' );

/** Proses form Lengkapi akun: username, nama tampil, dan password. */
function mincat_handle_setup_form() {
	if ( ! is_user_logged_in() || ! isset( $_POST['mincat_setup_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mincat_setup_nonce'] ) ), 'mincat_setup' ) ) {
		return;
	}
	$user_id  = get_current_user_id();
	$username = isset( $_POST['username'] ) ? strtolower( sanitize_user( wp_unslash( $_POST['username'] ), true ) ) : '';
	$display  = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
	$pass1    = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
	$pass2    = isset( $_POST['password2'] ) ? (string) wp_unslash( $_POST['password2'] ) : '';
	$error    = '';
	$taken    = username_exists( $username );

	if ( ! preg_match( '/^[a-z0-9._]{3,20}$/', $username ) ) {
		$error = 'Username 3–20 karakter: huruf kecil, angka, titik, atau garis bawah.';
	} elseif ( $taken && (int) $taken !== $user_id ) {
		$error = 'Username itu sudah dipakai. Coba yang lain.';
	} elseif ( mb_strlen( $display ) < 3 ) {
		$error = 'Isi nama tampil minimal 3 karakter.';
	} elseif ( strlen( $pass1 ) < 8 ) {
		$error = 'Password minimal 8 karakter.';
	} elseif ( $pass1 !== $pass2 ) {
		$error = 'Konfirmasi password tidak sama.';
	}

	if ( $error ) {
		set_transient( 'mincat_setup_error_' . $user_id, $error, 60 );
		wp_safe_redirect( mincat_url( 'lengkapi-akun' ) );
		exit;
	}

	global $wpdb;
	$current = get_userdata( $user_id );
	if ( $username !== $current->user_login ) {
		$wpdb->update( $wpdb->users, array( 'user_login' => $username ), array( 'ID' => $user_id ) );
		clean_user_cache( $user_id );
	}
	wp_update_user( array( 'ID' => $user_id, 'display_name' => $display, 'nickname' => $display, 'user_pass' => $pass1 ) );
	delete_user_meta( $user_id, 'mincat_needs_setup' );

	// Ganti password menghapus sesi lama; buat sesi baru supaya tetap masuk.
	wp_set_current_user( $user_id );
	wp_set_auth_cookie( $user_id, true );

	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}
add_action( 'template_redirect', 'mincat_handle_setup_form', 1 );

/**
 * Alamat tombol "Lanjut dengan Google".
 * Dipakai Nextend Social Login (sudah aktif). Kalau plugin tidak aktif, tombol tidak ditampilkan.
 */
function mincat_google_login_url() {
	if ( class_exists( 'NextendSocialLogin' ) || function_exists( 'NextendSocialLogin::isProviderEnabled' ) ) {
		return home_url( '/wp-login.php?loginSocial=google' );
	}
	return '';
}

function mincat_handle_update_profil() {
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( mincat_url( 'masuk' ) );
		exit;
	}
	check_admin_referer( 'mincat_update_profil', 'mincat_nonce' );

	$back  = add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) );
	$uid   = get_current_user_id();
	$name  = isset( $_POST['name'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['name'] ) ) ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

	if ( mb_strlen( $name ) < 3 ) {
		wp_safe_redirect( add_query_arg( 'err', 'name', $back ) );
		exit;
	}
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'err', 'email', $back ) );
		exit;
	}
	$phone = mincat_normalize_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
	if ( '' === $phone ) {
		wp_safe_redirect( add_query_arg( 'err', 'phone', $back ) );
		exit;
	}
	$pemilik = email_exists( $email );
	if ( $pemilik && (int) $pemilik !== $uid ) {
		wp_safe_redirect( add_query_arg( 'err', 'email', $back ) );
		exit;
	}

	$hasil = wp_update_user(
		array(
			'ID'           => $uid,
			'display_name' => $name,
			'user_email'   => $email,
		)
	);
	if ( is_wp_error( $hasil ) ) {
		wp_safe_redirect( add_query_arg( 'err', 'gagal', $back ) );
		exit;
	}
	update_user_meta( $uid, 'mincat_phone', $phone );
		$mc_alamat = isset( $_POST['alamat'] ) ? sanitize_textarea_field( wp_unslash( $_POST['alamat'] ) ) : '';
		update_user_meta( $uid, 'mincat_alamat', $mc_alamat );
		$mc_lat = isset( $_POST['lat'] ) ? trim( wp_unslash( $_POST['lat'] ) ) : '';
		$mc_lng = isset( $_POST['lng'] ) ? trim( wp_unslash( $_POST['lng'] ) ) : '';
		if ( '' === $mc_alamat ) {
			delete_user_meta( $uid, 'mincat_koord' );
		} elseif ( is_numeric( $mc_lat ) && is_numeric( $mc_lng ) && abs( (float) $mc_lat ) <= 90 && abs( (float) $mc_lng ) <= 180 ) {
			update_user_meta( $uid, 'mincat_koord', round( (float) $mc_lat, 6 ) . ',' . round( (float) $mc_lng, 6 ) );
		}
	wp_safe_redirect( add_query_arg( 'ok', '1', $back ) );
	exit;
}
add_action( 'admin_post_mincat_update_profil', 'mincat_handle_update_profil' );

/** Peran yang bisa diminta dari halaman Verifikasi, dan peran WordPress yang diberikan setelah disetujui. */
function mincat_request_wp_roles() {
	return array(
		'siswa'      => 'mincat_student',
		'guru'       => 'mincat_teacher',
		'mentor'     => 'mincat_mentor',
		'perusahaan' => 'mincat_company',
		'wali'       => 'mincat_wali',
	);
}

/** admin-post.php?action=mincat_submit_request: visitor mengirim permintaan peran (status menunggu). */
function mincat_handle_submit_request() {
	$back = mincat_url( 'verifikasi' );
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( mincat_url( 'masuk' ) );
		exit;
	}
	check_admin_referer( 'mincat_submit_request' );

	$uid   = get_current_user_id();
	$user  = wp_get_current_user();
	$roles = mincat_request_wp_roles();
	$role  = isset( $_POST['role'] ) ? sanitize_key( wp_unslash( $_POST['role'] ) ) : '';
	$nama  = isset( $_POST['nama'] ) ? sanitize_text_field( wp_unslash( $_POST['nama'] ) ) : '';
	$sek   = isset( $_POST['sekolah'] ) ? sanitize_text_field( wp_unslash( $_POST['sekolah'] ) ) : '';
	$kelas = isset( $_POST['kelas'] ) ? sanitize_text_field( wp_unslash( $_POST['kelas'] ) ) : '';
	$wali  = ! empty( $_POST['wali'] );

	$error = '';
	if ( ! isset( $roles[ $role ] ) ) {
		$error = 'Pilih peran yang valid.';
	} elseif ( mb_strlen( $nama ) < 3 ) {
		$error = 'Isi nama lengkap minimal 3 huruf.';
	} elseif ( '' === $sek ) {
		$error = 'Isi sekolah atau perusahaan.';
	} elseif ( 'siswa' === $role && '' === $kelas ) {
		$error = 'Isi kelas dan jurusan.';
	} elseif ( 'siswa' === $role && ! $wali ) {
		$error = 'Wali harus menyetujui akun ini untuk siswa.';
	}
	foreach ( mincat_requests_for( $user->user_email ) as $r ) {
		if ( 'menunggu' === $r['status'] ) {
			$error = 'Permintaanmu sudah dikirim dan sedang menunggu persetujuan.';
		}
	}
	if ( $error ) {
		wp_safe_redirect( add_query_arg( 'err', rawurlencode( $error ), $back ) );
		exit;
	}

	$data = array( 'nama' => $nama, 'sekolah' => $sek );
	if ( 'siswa' === $role ) {
		$data['kelas']  = $kelas;
		$data['wali']   = 'disetujui';
	}
	$id = wp_insert_post(
		array(
			'post_type'   => 'mincat_request',
			'post_status' => 'publish',
			'post_author' => $uid,
			'post_title'  => $nama . ' (' . $role . ')',
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'email', $user->user_email );
		update_post_meta( $id, 'user_id', (int) $uid );
		update_post_meta( $id, 'name', $nama );
		update_post_meta( $id, 'role', $role );
		update_post_meta( $id, 'data', $data );
		update_post_meta( $id, 'status', 'menunggu' );
		update_post_meta( $id, 'note', '' );
	}
	wp_safe_redirect( add_query_arg( 'ok', '1', $back ) );
	exit;
}
add_action( 'admin_post_mincat_submit_request', 'mincat_handle_submit_request' );

/** admin-post.php?action=mincat_request_decision: admin menyetujui atau menolak permintaan peran. */
function mincat_handle_request_decision() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Hanya admin yang bisa memutuskan permintaan akses.' );
	}
	$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	check_admin_referer( 'mincat_decide_' . $id );
	$post = get_post( $id );
	if ( ! $post || 'mincat_request' !== $post->post_type ) {
		wp_safe_redirect( mincat_url( 'akun' ) );
		exit;
	}

	$decision = isset( $_POST['decision'] ) ? sanitize_key( wp_unslash( $_POST['decision'] ) ) : '';
	$guru_id  = isset( $_POST['guru'] ) ? (int) $_POST['guru'] : 0;
	$role     = (string) get_post_meta( $id, 'role', true );
	$email    = (string) get_post_meta( $id, 'email', true );
	$roles    = mincat_request_wp_roles();

	if ( 'disetujui' === $decision && isset( $roles[ $role ] ) && get_role( $roles[ $role ] ) ) {
		// Akun dicari dengan ID pengirim, bukan email (email bisa diganti di akun).
		$req_uid = (int) get_post_meta( $id, 'user_id', true );
		$target  = $req_uid ? get_user_by( 'id', $req_uid ) : false;
		if ( ! $target ) {
			wp_die( 'Permintaan ini tidak punya akun pengirim yang valid. Minta siswa mengirim ulang permintaannya.' );
		}
		if ( ! in_array( 'mincat_visitor', (array) $target->roles, true ) ) {
			wp_die( 'Akun ini sudah punya peran. Permintaan tidak bisa disetujui lagi.' );
		}
		if ( 'siswa' === $role ) {
			$g = $guru_id ? get_user_by( 'id', $guru_id ) : false;
			if ( ! $g || ! in_array( 'mincat_teacher', (array) $g->roles, true ) ) {
				wp_die( 'Pilih guru pembimbing untuk siswa ini. <a href="' . esc_url( mincat_url( 'akun' ) ) . '">Kembali</a>' );
			}
		}
		if ( $target ) {
			$target->set_role( $roles[ $role ] );
			if ( 'siswa' === $role ) {
				update_user_meta( $target->ID, 'mincat_guru', $guru_id );
			}
		}
		update_post_meta( $id, 'status', 'disetujui' );
		update_post_meta( $id, 'note', '' );
	} elseif ( 'ditolak' === $decision ) {
		$note = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
		update_post_meta( $id, 'status', 'ditolak' );
		update_post_meta( $id, 'note', $note );
	}
	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}
add_action( 'admin_post_mincat_request_decision', 'mincat_handle_request_decision' );

/**
 * Nomor telepon (WhatsApp) disimpan dalam format 62 tanpa tanda plus, misalnya 6281234567890.
 * Menerima 08..., 628..., +628... (spasi, tanda hubung, dan titik diabaikan). Mengembalikan '' kalau tidak valid.
 */
function mincat_normalize_phone( $raw ) {
	$n = preg_replace( '/[\s\-\.\(\)]/', '', (string) $raw );
	if ( 0 === strpos( $n, '+' ) ) {
		$n = substr( $n, 1 );
	}
	if ( 0 === strpos( $n, '0' ) ) {
		$n = '62' . substr( $n, 1 );
	}
	return preg_match( '/^62\d{8,13}$/', $n ) ? $n : '';
}

/** Tampilan nomor di form: 62... kembali menjadi 08... */
function mincat_phone_display( $n ) {
	$n = (string) $n;
	return 0 === strpos( $n, '62' ) ? '0' . substr( $n, 2 ) : $n;
}

/** admin-post.php?action=mincat_upload_photo: foto profil siswa (JPG, PNG, WEBP, maksimal 2 MB). */
function mincat_handle_upload_photo() {
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( mincat_url( 'masuk' ) );
		exit;
	}
	check_admin_referer( 'mincat_upload_photo' );

	$back = add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) );
	$f    = isset( $_FILES['foto'] ) ? $_FILES['foto'] : array();
	$err  = isset( $f['error'] ) ? (int) $f['error'] : UPLOAD_ERR_NO_FILE;
	if ( UPLOAD_ERR_OK !== $err ) {
		mincat_flow_back( $back, 'foto' );
	}
	if ( (int) $f['size'] > 8 * 1024 * 1024 ) {
		mincat_flow_back( $back, 'foto' );
	}
	$ext = strtolower( pathinfo( (string) $f['name'], PATHINFO_EXTENSION ) );
	if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) {
		mincat_flow_back( $back, 'foto' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$upload_file = array(
		'name'     => sanitize_file_name( wp_unslash( $f['name'] ) ),
		'type'     => isset( $f['type'] ) ? (string) $f['type'] : '',
		'tmp_name' => $f['tmp_name'],
		'error'    => 0,
		'size'     => (int) $f['size'],
	);
	$res = wp_handle_upload(
		$upload_file,
		array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) )
	);
	if ( ! is_array( $res ) || isset( $res['error'] ) || empty( $res['url'] ) ) {
		mincat_flow_back( $back, 'foto' );
	}
	// Diperkecil otomatis ke 512 x 512 px supaya ringan. Kalau editor gambar tidak tersedia, file asli dipakai.
	$editor = wp_get_image_editor( $res['file'] );
	if ( ! is_wp_error( $editor ) ) {
		$editor->resize( 512, 512, true );
		$editor->set_quality( 82 );
		$editor->save( $res['file'] );
	}
	// Versi di URL ditambah penanda waktu supaya foto baru langsung tampil (tidak tertahan cache).
	update_user_meta( get_current_user_id(), 'mincat_photo', add_query_arg( 'v', time(), $res['url'] ) );
	wp_safe_redirect( add_query_arg( 'ok', 'foto', $back ) );
	exit;
}
add_action( 'admin_post_mincat_upload_photo', function () {
		mincat_safe_run( 'mincat_handle_upload_photo', add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) ) );
	} );
