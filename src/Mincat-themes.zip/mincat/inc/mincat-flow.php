<?php
/**
 * Alur lamaran PKL.
 * Siswa melamar (Menunggu Tinjauan) -> guru pembimbing meneruskan (Diteruskan ke perusahaan)
 * -> perusahaan menerima atau menolak (Diterima / Ditolak).
 * Perusahaan membuat lowongan sendiri lewat halaman /company/.
 *
 * Asumsi: guru pembimbing melihat semua lamaran yang menunggu tinjauan (belum ada relasi siswa bimbingan).
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mincat_status_labels() {
	return array(
		'menunggu' => 'Menunggu Tinjauan',
		'teruskan' => 'Diteruskan ke perusahaan',
		'diterima' => 'Diterima',
		'ditolak'  => 'Ditolak',
	);
}

/** Lamaran milik lowongan-lowongan tertentu, atau semua lamaran bila $job_ids null. */
function mincat_lamaran_list( $job_ids = null, $status_key = '' ) {
	if ( is_array( $job_ids ) && ! $job_ids ) {
		return array();
	}
	$labels = mincat_status_labels();
	$out    = array();
	$args   = array(
		'post_type'   => 'mincat_lamaran',
		'numberposts' => -1,
		'post_status' => 'publish',
		'orderby'     => 'date',
		'order'       => 'DESC',
	);
	foreach ( get_posts( $args ) as $p ) {
		$job = (int) get_post_meta( $p->ID, 'lowongan_id', true );
		if ( is_array( $job_ids ) && ! in_array( $job, array_map( 'intval', $job_ids ), true ) ) {
			continue;
		}
		$status = (string) get_post_meta( $p->ID, 'status', true );
		if ( '' !== $status_key && ( ! isset( $labels[ $status_key ] ) || $labels[ $status_key ] !== $status ) ) {
			continue;
		}
		$out[] = array(
			'id'        => $p->ID,
			'title'     => get_the_title( $p ),
			'student'   => get_the_author_meta( 'display_name', $p->post_author ),
			'perusahaan'=> (string) get_post_meta( $p->ID, 'perusahaan', true ),
			'status'    => $status,
			'job'       => $job,
		);
	}
	return $out;
}

/** Lowongan milik perusahaan yang sedang login. */
function mincat_my_jobs() {
	return get_posts(
		array(
			'post_type'   => 'mincat_peluang',
			'numberposts' => -1,
			'post_status' => 'publish',
			'author'      => get_current_user_id(),
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);
}

/** Kembali ke halaman asal dengan galat opsional. */
function mincat_flow_back( $url, $err = '' ) {
	if ( '' !== $err ) {
		$url = add_query_arg( 'err', rawurlencode( $err ), $url );
	}
	wp_safe_redirect( $url );
	exit;
}

/** admin-post.php?action=mincat_apply: siswa melamar lowongan. */
function mincat_handle_apply() {
	if ( ! is_user_logged_in() || 'siswa' !== mincat_role() ) {
		wp_die( 'Hanya siswa yang bisa melamar.' );
	}
	$job = isset( $_POST['job'] ) ? (int) $_POST['job'] : 0;
	check_admin_referer( 'mincat_apply_' . $job );

	$back = add_query_arg( 'tab', 'lamaran', mincat_url( 'akun' ) );
	$post = get_post( $job );
	if ( ! $post || 'mincat_peluang' !== $post->post_type || 'publish' !== $post->post_status ) {
		mincat_flow_back( mincat_url( 'opportunities' ) );
	}
	$uid = get_current_user_id();
	$dup = get_posts(
		array(
			'post_type'   => 'mincat_lamaran',
			'numberposts' => 1,
			'post_status' => 'publish',
			'author'      => $uid,
			'meta_key'    => 'lowongan_id',
			'meta_value'  => $job,
		)
	);
	if ( $dup ) {
		mincat_flow_back( $back );
	}
	$labels = mincat_status_labels();
	$id     = wp_insert_post(
		array(
			'post_type'   => 'mincat_lamaran',
			'post_status' => 'publish',
			'post_author' => $uid,
			'post_title'  => $post->post_title,
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'lowongan', $post->post_title );
		update_post_meta( $id, 'lowongan_id', $job );
		update_post_meta( $id, 'perusahaan', (string) get_post_meta( $job, 'perusahaan', true ) );
		update_post_meta( $id, 'status', $labels['menunggu'] );
		update_post_meta( $id, 'karya_id', 0 );
	}
	mincat_flow_back( $back );
}
add_action( 'admin_post_mincat_apply', 'mincat_handle_apply' );

/** admin-post.php?action=mincat_create_job: perusahaan membuat lowongan. */
function mincat_handle_create_job() {
	if ( ! is_user_logged_in() || 'perusahaan' !== mincat_role() ) {
		wp_die( 'Hanya perusahaan yang bisa membuat lowongan.' );
	}
	check_admin_referer( 'mincat_create_job' );

	$back  = add_query_arg( 'tab', 'lowongan', mincat_url( 'company' ) );
	$judul = isset( $_POST['judul'] ) ? sanitize_text_field( wp_unslash( $_POST['judul'] ) ) : '';
	$lokas = isset( $_POST['lokasi'] ) ? sanitize_text_field( wp_unslash( $_POST['lokasi'] ) ) : '';
	$kuota = isset( $_POST['kuota'] ) ? (int) $_POST['kuota'] : 0;
	$bidang = isset( $_POST['bidang'] ) ? sanitize_text_field( wp_unslash( $_POST['bidang'] ) ) : '';
	if ( ! in_array( $bidang, array( 'TKJ', 'TSM', 'TJAT' ), true ) ) {
		$bidang = 'TKJ';
	}
	$desk  = isset( $_POST['deskripsi'] ) ? sanitize_textarea_field( wp_unslash( $_POST['deskripsi'] ) ) : '';

	if ( mb_strlen( $judul ) < 5 ) {
		mincat_flow_back( $back, 'Judul lowongan minimal 5 huruf.' );
	}
	if ( '' === $lokas ) {
		mincat_flow_back( $back, 'Isi lokasi lowongan.' );
	}
	if ( $kuota < 1 ) {
		mincat_flow_back( $back, 'Kuota minimal 1 siswa.' );
	}
	$id = wp_insert_post(
		array(
			'post_type'   => 'mincat_peluang',
			'post_status' => 'publish',
			'post_author' => get_current_user_id(),
			'post_title'  => $judul,
			'post_content'=> $desk,
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'perusahaan', wp_get_current_user()->display_name );
		update_post_meta( $id, 'lokasi', $lokas );
		update_post_meta( $id, 'kuota', $kuota );
		update_post_meta( $id, 'bidang', $bidang );
		update_post_meta( $id, 'status', 'disetujui' );
	}
	mincat_flow_back( $back );
}
add_action( 'admin_post_mincat_create_job', 'mincat_handle_create_job' );

/**
 * admin-post.php?action=mincat_lamaran_action: keputusan guru (teruskan / tolak)
 * dan keputusan perusahaan untuk lowongan miliknya (terima / tolak).
 */
function mincat_handle_lamaran_action() {
	$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	check_admin_referer( 'mincat_lamaran_' . $id );

	$post = get_post( $id );
	$role = mincat_role();
	$act  = isset( $_POST['act'] ) ? sanitize_key( wp_unslash( $_POST['act'] ) ) : '';
	$st   = mincat_status_labels();
	$cur  = (string) get_post_meta( $id, 'status', true );
	$next = '';

	if ( ! $post || 'mincat_lamaran' !== $post->post_type ) {
		mincat_flow_back( mincat_url( 'akun' ) );
	}

	if ( 'guru' === $role && $cur === $st['menunggu'] ) {
		if ( 'teruskan' === $act ) {
			$next = 'teruskan';
		} elseif ( 'tolak' === $act ) {
			$next = 'ditolak';
		}
		$back = mincat_url( 'review' );
	} elseif ( 'perusahaan' === $role && $cur === $st['teruskan'] ) {
		$job = get_post( (int) get_post_meta( $id, 'lowongan_id', true ) );
		if ( $job && (int) $job->post_author === get_current_user_id() ) {
			if ( 'terima' === $act ) {
				$next = 'diterima';
			} elseif ( 'tolak' === $act ) {
				$next = 'ditolak';
			}
		}
		$back = add_query_arg( 'tab', 'pelamar', mincat_url( 'company' ) );
	} else {
		mincat_flow_back( mincat_url( 'akun' ) );
	}

	if ( $next ) {
		update_post_meta( $id, 'status', $st[ $next ] );
	}
	mincat_flow_back( $back );
}
add_action( 'admin_post_mincat_lamaran_action', 'mincat_handle_lamaran_action' );
