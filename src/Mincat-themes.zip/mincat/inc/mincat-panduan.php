<?php
/**
 * Isi panduan MINCAT: 7 panduan, masing-masing berisi beberapa bagian.
 * Dipakai oleh halaman /panduan/, panel Mincy, dan halaman panduan masing-masing.
 *
 * Setiap bagian: judul, isi (teks, opsional), langkah (daftar, opsional), catatan (opsional).
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mincat_panduan_topics() {
	return array(
		'mulai' => array(
			'judul'     => 'Mulai dan akun',
			'pengantar' => 'Apa itu MINCAT, kelebihannya, dan cara masuk.',
			'tombol'    => array( 'label' => 'Masuk', 'url' => mincat_url( 'masuk' ) ),
			'bagian'    => array(
				array( 'judul' => 'Tentang MINCAT', 'isi' => 'MINCAT membantu siswa SMK menampilkan karya nyata, mendapat review dari guru, dan melamar PKL yang sesuai dengan kemampuannya. MINCAT bekerja sama dengan SMKN 7 Kendal dan perusahaan mitra.' ),
				array( 'judul' => 'Kelebihan MINCAT', 'langkah' => array( 'Karya siswa diverifikasi guru, jadi bukti kemampuannya bisa dipercaya.', 'Portofolio bisa dilihat dan dibagikan dalam satu halaman.', 'Lowongan PKL dari mitra sekolah, dengan lamaran yang diteruskan guru pembimbing.', 'Gratis untuk siswa SMKN 7 Kendal.' ) ),
				array( 'judul' => 'Cara masuk dan memulai', 'langkah' => array( 'Tekan Masuk, lalu pilih Lanjut dengan Google.', 'Akun dibuat otomatis dengan status Visitor.', 'Lengkapi username dan password.', 'Kirim permintaan peran (siswa, guru, perusahaan, atau wali) di halaman Verifikasi.', 'Tunggu verifikasi admin. Setelah disetujui, peranmu aktif.' ), 'catatan' => 'Tidak perlu daftar terpisah. Satu akun Google, satu akun MINCAT.' ),
			),
		),
		'portofolio' => array(
			'judul'     => 'Portofolio siswa',
			'pengantar' => 'Membuat, mengisi, mengedit, dan menampilkan portofolio.',
			'tombol'    => array( 'label' => 'Portofolio saya', 'url' => add_query_arg( 'tab', 'karya', mincat_url( 'akun' ) ) ),
			'bagian'    => array(
				array( 'judul' => 'Cara membuat portofolio', 'langkah' => array( 'Buka Portofolio saya, lalu tekan Tambah karya.', 'Isi data dirimu dan karyamu.', 'Unggah foto diri (opsional).', 'Tekan Kirim ke review.' ), 'catatan' => 'Setiap siswa punya satu portofolio. Karyanya perlu di-ACC guru sebelum tampil.' ),
				array( 'judul' => 'Apa yang diisi', 'langkah' => array( 'Nama.', 'Kelas dan jurusan.', 'Minat.', 'Skill dan bakat, dipisah dengan koma.', 'Sertifikat dan penghargaan (foto, opsional).', 'Projek yang dimiliki (opsional).', 'Website portofolio sendiri (opsional).', 'Harapan kedepannya.' ), 'catatan' => 'Nama, kelas dan jurusan, skill, dan harapan wajib diisi.' ),
				array( 'judul' => 'Foto diri', 'isi' => 'Foto diri tampil besar di halaman detail karya. Formatnya JPG, PNG, atau WEBP, maksimal 8 MB, dan diperkecil otomatis. Kalau belum diunggah, halaman detail memakai foto profil. Kalau keduanya kosong, tampil inisial.' ),
				array( 'judul' => 'Arti status', 'langkah' => array( 'Menunggu Review: belum ditinjau guru.', 'Terverifikasi: sudah di-ACC guru.', 'Revisi: ada catatan dari guru yang perlu diperbaiki. Perbaiki lalu kirim ulang.' ) ),
				array( 'judul' => 'Edit portofolio', 'langkah' => array( 'Buka Portofolio saya.', 'Tekan Edit, ubah isian, lalu tekan Simpan perubahan.' ), 'catatan' => 'Karya yang sudah terverifikasi langsung tersimpan dan statusnya tetap Terverifikasi, tanpa verifikasi ulang.' ),
				array( 'judul' => 'Tampilkan di beranda', 'langkah' => array( 'Pastikan karya sudah Terverifikasi.', 'Buka Portofolio saya, lalu tekan Tampilkan di beranda.' ), 'catatan' => 'Yang tampil hanya inisial dan jurusan, tanpa nama lengkap. Bisa disembunyikan kapan saja.' ),
				array( 'judul' => 'Membagikan karya', 'langkah' => array( 'Buka Portofolio saya.', 'Pilih karya yang sudah terverifikasi.', 'Tekan Bagikan tautan.' ), 'catatan' => 'Fitur bagikan sedang disiapkan.' ),
			),
		),
		'lihat-karya' => array(
			'judul'     => 'Melihat karya dan detail',
			'pengantar' => 'Arti Terverifikasi, cara melihat detail karya, dan batas aksesnya.',
			'tombol'    => array( 'label' => 'Portofolio', 'url' => mincat_url( 'portfolio' ) ),
			'bagian'    => array(
				array( 'judul' => 'Arti Terverifikasi', 'isi' => 'Karya terverifikasi sudah ditinjau dan di-ACC oleh guru. Hanya karya terverifikasi yang tampil di halaman Portofolio dan bisa dibagikan.' ),
				array( 'judul' => 'Cara melihat detail', 'langkah' => array( 'Buka halaman Portofolio.', 'Tekan Lihat detail pada kartu karya.' ), 'catatan' => 'Halaman detail hanya bisa dibuka oleh siswa, guru, mentor, perusahaan, dan admin yang sudah masuk.' ),
				array( 'judul' => 'Kenapa tidak bisa dibuka', 'isi' => 'Akun visitor dan wali belum bisa membuka halaman detail. Masuk dengan akun yang perannya sudah disetujui admin.' ),
				array( 'judul' => 'Kembali ke Portofolio', 'langkah' => array( 'Tekan tautan Kembali ke Portofolio di bagian atas halaman detail.' ) ),
			),
		),
		'peluang' => array(
			'judul'     => 'Peluang PKL dan lamaran',
			'pengantar' => 'Cara melihat lowongan, melamar, dan memahami tenggat.',
			'tombol'    => array( 'label' => 'Peluang PKL', 'url' => mincat_url( 'opportunities' ) ),
			'bagian'    => array(
				array( 'judul' => 'Cara melihat peluang', 'langkah' => array( 'Buka menu Peluang PKL.', 'Gunakan pilihan bidang, lokasi, dan urutan tenggat.', 'Tekan Lihat detail pada lowongan. Detail hanya bisa dibuka setelah masuk.' ) ),
				array( 'judul' => 'Cara melamar', 'langkah' => array( 'Pilih lowongan.', 'Tekan Lamar sekarang.', 'Pantau statusnya di tab Lamaran.' ), 'catatan' => 'Status awal Menunggu Tinjauan. Guru pembimbing meneruskan lamaranmu ke perusahaan.' ),
				array( 'judul' => 'Arti tenggat', 'isi' => 'Warna tanggal batas daftar. Oranye berarti 3 hari lagi atau kurang. Merah berarti 1 hari lagi atau kurang.' ),
				array( 'judul' => 'Memfilter peluang', 'langkah' => array( 'Pilih bidang: TKJ, TSM, atau TJAT.', 'Pilih lokasi.', 'Pilih urutan tenggat.' ) ),
			),
		),
		'guru' => array(
			'judul'     => 'Guru dan mentor',
			'pengantar' => 'Cara meninjau karya siswa dan meneruskan lamaran.',
			'tombol'    => array( 'label' => 'Antrean review', 'url' => mincat_url( 'review' ) ),
			'bagian'    => array(
				array( 'judul' => 'Cara meninjau karya', 'langkah' => array( 'Buka Antrean review.', 'Periksa karya yang menunggu review.', 'Tekan ACC untuk menyetujui, atau tulis catatan lalu tekan Minta revisi.' ), 'catatan' => 'Hanya guru pembimbing yang bersangkutan dan admin yang bisa meninjau.' ),
				array( 'judul' => 'Cara ACC karya', 'isi' => 'Tekan ACC pada karya yang menunggu review. Karya langsung berstatus Terverifikasi.' ),
				array( 'judul' => 'Cara minta revisi', 'langkah' => array( 'Tulis catatan yang jelas, minimal 10 karakter.', 'Tekan Minta revisi.' ), 'catatan' => 'Siswa melihat catatanmu di Portofolio saya dan bisa mengirim ulang.' ),
				array( 'judul' => 'Cara meneruskan lamaran', 'langkah' => array( 'Buka Antrean review, bagian lamaran.', 'Tekan Teruskan ke perusahaan, atau Tolak.' ) ),
			),
		),
		'perusahaan' => array(
			'judul'     => 'Perusahaan',
			'pengantar' => 'Membuat lowongan dan memutuskan pelamar.',
			'tombol'    => array( 'label' => 'Buka Perusahaan', 'url' => add_query_arg( 'tab', 'lowongan', mincat_url( 'company' ) ) ),
			'bagian'    => array(
				array( 'judul' => 'Cara membuat lowongan', 'langkah' => array( 'Buka Perusahaan, lalu tab Lowongan saya.', 'Isi judul, lokasi, kuota, dan deskripsi.', 'Tekan Terbitkan lowongan.' ), 'catatan' => 'Lowongan langsung tampil di Peluang PKL.' ),
				array( 'judul' => 'Cara menerima atau menolak pelamar', 'langkah' => array( 'Buka tab Pelamar.', 'Pilih lamaran dengan status Diteruskan ke perusahaan.', 'Tekan Terima atau Tolak.' ), 'catatan' => 'Lamaran yang belum diteruskan guru tidak tampil untuk diputuskan.' ),
			),
		),
		'admin' => array(
			'judul'     => 'Admin sekolah',
			'pengantar' => 'Verifikasi akun dan impor daftar PKL.',
			'tombol'    => array( 'label' => 'Verifikasi akun', 'url' => mincat_url( 'akun' ) ),
			'bagian'    => array(
				array( 'judul' => 'Verifikasi akun', 'langkah' => array( 'Buka Verifikasi akun.', 'Periksa permintaan peran dan datanya.', 'Untuk siswa, pilih guru pembimbing sebelum menyetujui.', 'Tekan Setujui atau Tolak.' ), 'catatan' => 'Akun visitor tidak bisa memakai fitur sekolah sampai disetujui.' ),
				array( 'judul' => 'Impor daftar PKL', 'langkah' => array( 'Buka Verifikasi akun.', 'Di kartu Daftar PKL, tekan Impor daftar PKL.', 'Lihat pesan hasilnya.' ), 'catatan' => 'Data yang sudah ada tidak digandakan. Impor bisa dijalankan lagi dengan aman.' ),
			),
		),
	);
}

/** Tampilkan satu panduan sebagai halaman sendiri (dipakai page-panduan-{kunci}.php). */
function mincat_render_panduan( $key, $page_key ) {
	$topics = mincat_panduan_topics();
	$t      = isset( $topics[ $key ] ) ? $topics[ $key ] : null;
	set_query_var( 'mincat_page', $page_key );
	get_header();
	get_template_part( 'template-parts/shell', 'open' );
	if ( ! $t ) {
		echo mincat_title( 'Panduan tidak ditemukan', 'Lihat daftar panduan di halaman Panduan.' );
	} else {
		echo mincat_title( $t['judul'], $t['pengantar'] );
		foreach ( $t['bagian'] as $b ) {
			echo '<div class="panel" style="margin-top:12px"><b>' . esc_html( $b['judul'] ) . '</b>';
			if ( ! empty( $b['isi'] ) ) {
				echo '<p class="sub" style="margin:8px 0 0">' . esc_html( $b['isi'] ) . '</p>';
			}
			if ( ! empty( $b['langkah'] ) ) {
				echo '<ol style="margin:10px 0 0;padding-left:20px;line-height:1.7">';
				foreach ( $b['langkah'] as $l ) {
					echo '<li>' . esc_html( $l ) . '</li>';
				}
				echo '</ol>';
			}
			if ( ! empty( $b['catatan'] ) ) {
				echo '<p class="sub" style="margin:12px 0 0"><b>Catatan:</b> ' . esc_html( $b['catatan'] ) . '</p>';
			}
			echo '</div>';
		}
		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">';
		echo '<a class="btn primary small" href="' . esc_url( $t['tombol']['url'] ) . '">' . esc_html( $t['tombol']['label'] ) . ' ' . mincat_ic( 'arrow' ) . '</a>';
		echo '<a class="btn secondary small" href="' . esc_url( mincat_url( 'panduan' ) ) . '">Semua panduan</a>';
		echo '</div>';
	}
	get_template_part( 'template-parts/shell', 'close' );
	get_footer();
}
