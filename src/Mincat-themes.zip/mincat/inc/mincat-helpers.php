<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mincat_icons() {
	$icons = array(
		'jurnal' => '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>',
		'pin' => '<path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2"/>',
		'clock' => '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
		'wallet' => '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M16 12h2"/>',
		'bell' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
		'dashboard' => '<path d="M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z"/>',
		'portfolio' => '<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
		'opportunities' => '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.3-4.3"/>',
		'journey' => '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 6h6a4 4 0 0 1 0 8h-4a4 4 0 0 0 0 8h6"/>',
		'applications' => '<path d="M7 3h10v18l-5-3-5 3z"/>',
		'review' => '<path d="M4 12l5 5L20 6"/>',
		'company' => '<path d="M4 21V8l8-4 8 4v13"/><path d="M9 21v-6h6v6"/>',
		'settings' => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
		'home' => '<path d="M3 11l9-8 9 8v9h-6v-6H9v6H3z"/>',
		'check' => '<path d="M5 12l4 4L19 7"/>',
		'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'akun' => '<path d="M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z"/>',
		'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
		'heart' => '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
	);
	return $icons;
}

function mincat_role_label() {
	return array(
		'wali' => 'Wali siswa',
		'siswa' => 'Siswa SMK',
		'guru' => 'Guru pembimbing PKL',
		'mentor' => 'Mentor industri',
		'perusahaan' => 'HRD perusahaan',
		'visitor' => 'Visitor (menunggu verifikasi)',
		'admin' => 'Admin sekolah',
	);
}

function mincat_role_nav() {
	$nav = mincat_role_nav_base();
	foreach ( $nav as $r => $items ) {
		foreach ( array( array( 'opportunities', 'Peluang PKL' ), array( 'portfolio', 'Portofolio' ) ) as $add ) {
			$ada = false;
			foreach ( $items as $it ) {
				if ( $it[0] === $add[0] ) {
					$ada = true;
				}
			}
			if ( ! $ada ) {
				$nav[ $r ][] = $add;
			}
		}
	}
	return $nav;
}

function mincat_role_nav_base() {
	return array(
		'siswa' => array(
			array( 'akun', 'Dashboard' ),
			array( 'portfolio', 'Portofolio' ),
			array( 'opportunities', 'Peluang PKL' ),
			array( 'settings', 'Pengaturan' ),
		),
		'guru' => array(
			array( 'review', 'Antrean Review' ),
			array( 'settings', 'Pengaturan' ),
		),
		'mentor' => array(
			array( 'review', 'Jurnal mentor' ),
			array( 'settings', 'Pengaturan' ),
		),
		'perusahaan' => array(
			array( 'company', 'Perusahaan' ),
			array( 'pesan', 'Pesan' ),
			array( 'settings', 'Pengaturan' ),
		),
		'visitor' => array(
			array( 'akun', 'Akun saya' ),
			array( 'mitra', 'Mitra & lowongan' ),
		),
		'wali' => array(
			array( 'akun', 'Akun saya' ),
		),
		'admin' => array(
			array( 'admin', 'Verifikasi akun' ),
			array( 'review', 'Review' ),
			array( 'settings', 'Pengaturan' ),
		),
	);
}

function mincat_skill_taxonomy() {
	return array(
		'TKJ' => array( 'MikroTik', 'Konfigurasi VLAN', 'Troubleshooting jaringan', 'Cisco Packet Tracer', 'Linux Server', 'Instalasi kabel LAN' ),
		'TSM' => array( 'Servis berkala', 'Diagnosis kelistrikan', 'Sistem pengapian', 'Overhaul mesin', 'Sistem injeksi BBM' ),
		'TJAT' => array( 'Splicing fiber optik', 'OTDR', 'Instalasi kabel drop', 'Konfigurasi ONT', 'Pemasangan ODP' ),
	);
}

function mincat_skill_all() {
	$all = array();
	foreach ( mincat_skill_taxonomy() as $list ) {
		foreach ( $list as $s ) {
			$all[ $s ] = true;
		}
	}
	return array_keys( $all );
}

function mincat_norm_skill( $x ) {
	$x = trim( (string) $x );
	foreach ( mincat_skill_all() as $k ) {
		if ( mb_strtolower( $k ) === mb_strtolower( $x ) ) {
			return $k;
		}
	}
	return $x;
}

/* ===================== Markup helper (1:1 dengan JS) ===================== */

/** ic() */
function mincat_ic( $name, $class = '' ) {
	$icons = mincat_icons();
	return '<svg class="ic ' . esc_attr( $class ) . '" viewBox="0 0 24 24" aria-hidden="true">' . ( isset( $icons[ $name ] ) ? $icons[ $name ] : '' ) . '</svg>';
}

/** status() */
function mincat_status( $s, $k ) {
	return '<span class="status ' . esc_attr( $k ) . '">' . esc_html( $s ) . '</span>';
}

/** art() */
function mincat_art( $c = '' ) {
	return '<div class="thumb ' . esc_attr( $c ) . '"></div>';
}

/** emptyBox() */
function mincat_empty_box( $t, $sub ) {
	return '<div class="empty-box"><b>' . esc_html( $t ) . '</b><p class="tiny">' . esc_html( $sub ) . '</p></div>';
}

/** title(); $act adalah HTML tepercaya (tombol/tautan), bukan data pengguna. */
function mincat_title( $t, $sub, $act = '' ) {
	return '<div class="pagetitle"><div><h1>' . esc_html( $t ) . '</h1><p>' . esc_html( $sub ) . '</p></div>' . $act . '</div>';
}

/** name.split(' ').map(x=>x[0]).slice(0,2).join('') */
function mincat_initials( $name ) {
	$out = '';
	$n   = 0;
	foreach ( explode( ' ', (string) $name ) as $part ) {
		if ( $n >= 2 ) {
			break;
		}
		$out .= mb_substr( $part, 0, 1 );
		$n++;
	}
	return $out;
}

function mincat_mincy_center_button() {
	return '<button type="button" class="mc-center" onclick="mincyToggle(event)" aria-label="Buka Mincy, teman panduan MINCAT"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></button>';
}

/* ===================== Routing ===================== */

function mincat_page_slugs() {
	return array(
		'home'          => '',
		'opportunities' => 'peluang',
		'portfolio'     => 'portofolio',
		'portofolio-baru' => 'portofolio-baru',
		'portofolio-detail' => 'portofolio-detail',
		'kebijakan-privasi' => 'kebijakan-privasi',
		'syarat-layanan' => 'syarat-layanan',
		'panduan' => 'panduan',
		'panduan-mulai' => 'panduan-mulai',
		'panduan-portofolio' => 'panduan-portofolio',
		'panduan-lihat-karya' => 'panduan-lihat-karya',
		'panduan-peluang' => 'panduan-peluang',
		'panduan-guru' => 'panduan-guru',
		'panduan-perusahaan' => 'panduan-perusahaan',
		'panduan-admin' => 'panduan-admin',
		'pesan'         => 'pesan',
		'mitra'         => 'mitra',
		'about'         => 'about',
		'settings'      => 'settings',
		'masuk'         => 'masuk',
		'akun'          => 'akun',
		'dashboard'     => 'akun',
		'verifikasi'    => 'verifikasi',
		'lengkapi-akun' => 'lengkapi-akun',
		'jobdetail'     => 'detail-peluang',
		'review'        => 'review',
		'company'       => 'company',
		'admin'         => 'admin',
		'applications'  => 'lamaran',
		'journey'       => 'journey',
		'shared'        => 'bagikan',
	);
}

/** Pengganti go('halaman'): URL biasa untuk href. */
function mincat_url( $page ) {
	$slugs = mincat_page_slugs();
	$slug  = isset( $slugs[ $page ] ) ? $slugs[ $page ] : $page;
	return '' === $slug ? home_url( '/' ) : home_url( user_trailingslashit( $slug ) );
}

/** Halaman yang sedang aktif (S.page): diisi tiap template lewat set_query_var('mincat_page', ...). */
function mincat_is_page( $page ) {
	return (string) get_query_var( 'mincat_page', '' ) === (string) $page;
}

/** Penanda "active" ala render(): classList.toggle('active') + aria-current. */
function mincat_active_attrs( $page ) {
	return mincat_is_page( $page ) ? ' aria-current="page"' : '';
}

/* ===================== Bagian header & menu (render() + authHTML() + roleMobile()) ===================== */

/** Isi <nav class="nav"> yang ditulis ulang render(): Beranda + menu peran (tanpa Pengaturan) + Tentang. */
function mincat_header_nav_html() {
	$lg    = mincat_logged_in();
	$items = array( array( 'home', 'Beranda' ) );
	$siswa = $lg && 'siswa' === mincat_nav_role();
	if ( $lg && 'siswa' === mincat_role() ) {
		$nav = mincat_role_nav();
		foreach ( $nav['siswa'] as $it ) {
			if ( 'settings' !== $it[0] ) {
				$items[] = $it;
			}
		}
	} elseif ( $lg ) {
		$items[] = array( 'opportunities', 'Peluang PKL' );
		$items[] = array( 'portfolio', 'Portofolio' );
		$items[] = array( 'akun', 'Dashboard' );
	} else {
		$items[] = array( 'opportunities', 'Peluang PKL' );
		$items[] = array( 'portfolio', 'Portofolio' );
	}
	$items[] = array( 'about', 'Tentang' );
	$out     = '';
	foreach ( $items as $it ) {
		$href = mincat_url( $it[0] );
		$on   = mincat_is_page( $it[0] );
		if ( $siswa && 'pesan' === $it[0] ) {
			// Pesan untuk siswa adalah tab di dashboard (revisi).
			$href = add_query_arg( 'tab', 'pesan', mincat_url( 'akun' ) );
			$on   = mincat_is_page( 'akun' ) && isset( $_GET['tab'] ) && 'pesan' === $_GET['tab'];
		}
		$out .= '<a href="' . esc_url( $href ) . '" data-page="' . esc_attr( $it[0] ) . '"' . ( $on ? ' class="active" aria-current="page"' : '' ) . '>' . esc_html( $it[1] ) . '</a>';
	}
	return $out;
}

/** authHTML() */
function mincat_auth_html() {
	if ( mincat_logged_in() ) {
		$unread = mincat_unread_count();
		$p      = mincat_profile();
		$out    = '<button class="bell" aria-label="Notifikasi' . ( $unread ? esc_attr( ' belum dibaca: ' . $unread ) : '' ) . '" data-mincat-action="toggle-notif">' . mincat_ic( 'bell' ) . ( $unread ? '<span class="dot-n">' . (int) $unread . '</span>' : '' ) . '</button>';
		$out   .= '<a href="' . esc_url( mincat_url( 'akun' ) ) . '" class="acct-btn ' . ( mincat_is_page( 'akun' ) ? 'active' : '' ) . '" data-page="akun" aria-label="Akun saya" title="Akun saya"' . mincat_active_attrs( 'akun' ) . '>';
		$out   .= $p['photo'] ? '<img src="' . esc_url( $p['photo'] ) . '" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover">' : esc_html( mincat_initials( $p['name'] ) );
		$out   .= '</a>';
		$out   .= '<a class="auth-logout" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '" style="color:#ef4444;font-weight:700;font-size:13px;margin-left:10px;text-decoration:none">Keluar</a>';
		return $out;
	}
	return '<a class="btn secondary small" href="' . esc_url( mincat_url( 'masuk' ) ) . '">Masuk</a> <a class="btn primary small" href="' . esc_url( mincat_url( 'masuk' ) ) . '">Daftar</a>';
}

/** roleMobile() */
function mincat_role_mobile() {
	$lg = mincat_logged_in();
	$r  = mincat_role();
	if ( $lg && 'siswa' === $r ) {
		return array( array( 'home', 'Beranda' ), array( 'akun', 'Dashboard' ), array( 'opportunities', 'Peluang' ), array( 'portfolio', 'Portofolio' ) );
	}
	if ( ! $lg || ! $r || 'visitor' === $r ) {
		return array( array( 'home', 'Beranda' ), array( 'opportunities', 'Peluang' ), array( 'portfolio', 'Portofolio' ), array( 'akun', 'Dashboard' ) );
	}
	$nav = mincat_role_nav();
	if ( ! isset( $nav[ $r ] ) ) {
		return array( array( 'home', 'Beranda' ), array( 'opportunities', 'Peluang' ), array( 'portfolio', 'Portofolio' ), array( 'akun', 'Dashboard' ) );
	}
	return array( array( 'home', 'Beranda' ), array( 'opportunities', 'Peluang' ), array( 'portfolio', 'Portofolio' ), array( 'akun', 'Dashboard' ) );
}

/** Isi <nav class="mobile" id="mnav"> (bagian dari render()). */
function mincat_mobile_nav_html() {
	$items = array();
	foreach ( mincat_role_mobile() as $it ) {
		$items[] = '<a href="' . esc_url( mincat_url( $it[0] ) ) . '" data-page="' . esc_attr( $it[0] ) . '"' . ( mincat_is_page( $it[0] ) ? ' class="active" aria-current="page"' : '' ) . '>' . mincat_ic( $it[0] ) . '<span>' . esc_html( $it[1] ) . '</span></a>';
	}
	$mid = (int) ceil( count( $items ) / 2 );
	return implode( '', array_slice( $items, 0, $mid ) ) . mincat_mincy_center_button() . implode( '', array_slice( $items, $mid ) );
}

/* ===================== Tanggal, tenggat, kecocokan ===================== */

/** daysLeft(): parseInt(j[6]) atau null. */
function mincat_days_left( $j ) {
	if ( preg_match( '/^\s*([+-]?\d+)/', (string) $j[6], $m ) ) {
		return (int) $m[1];
	}
	return null;
}

/** deadlineTag() */
function mincat_deadline_tag( $j ) {
	$n = mincat_days_left( $j );
	if ( null === $n ) {
		return '<div class="tiny muted">' . esc_html( $j[6] ) . '</div>';
	}
	$cls = $n <= 1 ? 'hot' : ( $n <= 3 ? 'warn' : '' );
	return '<div class="tiny ' . $cls . '">' . ( $n <= 0 ? 'Tenggat sudah lewat' : 'Tenggat ' . $n . ' hari lagi' ) . '</div>';
}

/** studentSkills() */
function mincat_student_skills() {
	$set = array();
	foreach ( mincat_projects() as $p ) {
		foreach ( $p['tools'] as $t ) {
			$set[ mb_strtolower( mincat_norm_skill( $t ) ) ] = true;
		}
	}
	return $set;
}

/** Bidang siswa (TKJ, TSM, TJAT) diambil dari kelas/jurusannya. */
function mincat_student_bidang() {
	$cands = array();
	foreach ( mincat_projects() as $p ) {
		$cands[] = (string) $p['c'];
	}
	$cands[] = (string) get_user_meta( get_current_user_id(), 'mincat_jurusan', true );
	$tax     = mincat_skill_taxonomy();
	foreach ( $cands as $c ) {
		$c = strtoupper( $c );
		foreach ( array_keys( $tax ) as $b ) {
			if ( false !== strpos( $c, $b ) ) {
				return $b;
			}
		}
	}
	return '';
}

/** matchJob() */
function mincat_match_job( $j ) {
	$raw = isset( $j[8] ) ? (array) $j[8] : array();
	$tax = mincat_skill_taxonomy();
	if ( ! $raw && isset( $j[3] ) && isset( $tax[ $j[3] ] ) ) {
		$raw = $tax[ $j[3] ]; // lowongan tanpa skill: pakai skill default bidangnya
	}
	$skills = array();
	foreach ( $raw as $x ) {
		$skills[] = mincat_norm_skill( $x );
	}
	$have  = mincat_student_skills();
	$cocok = array();
	$belum = array();
	foreach ( $skills as $x ) {
		if ( isset( $have[ mb_strtolower( $x ) ] ) ) {
			$cocok[] = $x;
		} else {
			$belum[] = $x;
		}
	}
	$sb        = mincat_student_bidang();
	$bidang_ok = '' !== $sb && isset( $j[3] ) && $sb === $j[3];
	$ratio = count( $skills ) ? count( $cocok ) / count( $skills ) : 0;
	$pct   = (int) round( 100 * ( 0.7 * $ratio + 0.3 * ( $bidang_ok ? 1 : 0 ) ) );
	return array(
		'pct'      => $pct,
		'cocok'    => $cocok,
		'belum'    => $belum,
		'bidangOK' => $bidang_ok,
	);
}

/** matchPill() */
function mincat_match_pill( $m ) {
	$cls = $m['pct'] >= 70 ? 'hi' : ( $m['pct'] >= 40 ? 'mid' : 'lo' );
	return '<span class="match ' . $cls . '">' . (int) $m['pct'] . '% cocok</span>';
}

/** matchReasons() */
function mincat_match_reasons( $m ) {
	$c = count( $m['cocok'] ) ? 'Cocok: ' . implode( ', ', $m['cocok'] ) : 'Belum ada skill yang cocok';
	$b = count( $m['belum'] ) ? ' · Belum: ' . implode( ', ', $m['belum'] ) : '';
	return '<p class="tiny muted" style="margin:6px 0 0">' . esc_html( $c . $b ) . '</p>';
}

/** Object.entries(r.data).filter(([k])=>k!=='nama').map(([k,x])=>k+': '+x).join(' · ')||'-' */
function mincat_req_data_line( $data ) {
	$parts = array();
	foreach ( (array) $data as $k => $x ) {
		if ( 'nama' !== $k ) {
			$parts[] = $k . ': ' . $x;
		}
	}
	return $parts ? implode( ' · ', $parts ) : '-';
}

/** Menu fitur peran yang dipindah dari navbar ke dashboard (Review, Pesan, Pengaturan, Perusahaan, Mitra). */
function mincat_role_menu_links() {
	$nav = mincat_role_nav();
	$r   = mincat_role();
	$out = array();
	if ( ! $r || ! isset( $nav[ $r ] ) ) {
		return $out;
	}
	foreach ( $nav[ $r ] as $it ) {
		if ( ! in_array( $it[0], array( 'home', 'akun', 'admin', 'opportunities', 'portfolio' ), true ) ) {
			$out[] = $it;
		}
	}
	return $out;
}

/** Alamat rumah siswa dan tautan rute ke tempat PKL. Hanya dipanggil di halaman perusahaan, guru, dan admin. */
function mincat_lamaran_alamat_html( $lamaran_id ) {
	$lamaran_id = (int) $lamaran_id;
	if ( ! $lamaran_id ) {
		return '';
	}
	$uid    = (int) get_post_field( 'post_author', $lamaran_id );
	$alamat = trim( (string) get_user_meta( $uid, 'mincat_alamat', true ) );
	$koord  = trim( (string) get_user_meta( $uid, 'mincat_koord', true ) );
	if ( '' === $alamat && '' === $koord ) {
		return '';
	}
	$job  = (int) get_post_meta( $lamaran_id, 'job', true );
	$dest = $job ? (string) get_post_meta( $job, 'lokasi', true ) : '';
	$orig = '' !== $koord ? $koord : $alamat;
	$out  = '<p class="tiny muted" style="margin:4px 0 0">Alamat rumah: ' . esc_html( '' !== $alamat ? $alamat : 'koordinat tersimpan' ) . '</p>';
	if ( '' !== $dest ) {
		$url  = 'https://www.google.com/maps/dir/?api=1&origin=' . rawurlencode( $orig ) . '&destination=' . rawurlencode( $dest ) . '&travelmode=driving';
		$out .= '<a class="tiny" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">Lihat rute ke tempat PKL</a>';
	}
	return $out;
}

