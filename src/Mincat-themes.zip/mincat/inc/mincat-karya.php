<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Portofolio milik siswa (satu), atau null. */
function mincat_my_karya( $uid ) {
	$r = get_posts(
		array(
			'post_type'   => 'mincat_karya',
			'author'      => (int) $uid,
			'numberposts' => 1,
			'post_status' => 'publish',
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);
	return $r ? $r[0] : null;
}

function mincat_karya_fields( $id, $pending = false ) {
	$post = get_post( $id );
	$pend = get_post_meta( $id, 'pending', true );
	if ( $pending && is_array( $pend ) ) {
		return array(
			'title'   => (string) $pend['title'],
			'content' => (string) $pend['content'],
			'c'       => (string) $pend['c'],
			'tools'   => (array) $pend['tools'],
			'pf'      => (array) $pend['profil_form'],
		);
	}
	return array(
		'title'   => $post ? (string) $post->post_title : '',
		'content' => $post ? (string) $post->post_content : '',
		'c'       => (string) get_post_meta( $id, 'c', true ),
		'tools'   => (array) get_post_meta( $id, 'tools', true ),
		'pf'      => (array) get_post_meta( $id, 'profil_form', true ),
	);
}

function mincat_handle_add_karya() {
	if ( ! is_user_logged_in() || 'siswa' !== mincat_role() ) {
		wp_die( 'Hanya siswa yang bisa menambah karya.' );
	}
	check_admin_referer( 'mincat_add_karya' );

	$uid   = get_current_user_id();
	$back  = mincat_url( 'portofolio-baru' );
	$own   = mincat_my_karya( $uid );
	$tab_k = add_query_arg( 'tab', 'karya', mincat_url( 'akun' ) );
	$live_verified = $own && 'verified' === (string) get_post_meta( $own->ID, 'k', true );

	$get = function ( $k ) {
		return isset( $_POST[ $k ] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ) : '';
	};
	$nama    = $get( 'nama' );
	$kelas   = $get( 'kelas' );
	$minat   = $get( 'minat' );
	$skill   = $get( 'skill' );
	$sertif  = $get( 'sertifikat_keterangan' );
	$project = $get( 'project' );
	$pengalaman = $get( 'pengalaman' );
	$website = esc_url_raw( $get( 'website' ) );
	$harapan = $get( 'harapan' );

	if ( mb_strlen( $nama ) < 3 ) {
		mincat_flow_back( $back, 'Nama minimal 3 huruf.' );
	}
	if ( '' === $kelas ) {
		mincat_flow_back( $back, 'Isi kelas dan jurusan.' );
	}
	if ( '' === $skill ) {
		mincat_flow_back( $back, 'Isi skill dan bakatmu.' );
	}
	if ( '' === $harapan ) {
		mincat_flow_back( $back, 'Isi harapan kedepannya.' );
	}
	if ( '' !== $website && ! wp_http_validate_url( $website ) ) {
		mincat_flow_back( $back, 'Alamat website belum valid. Contoh: https://namamu.com' );
	}
	$tools = array_values( array_filter( array_map( 'trim', preg_split( '/[,\n]+/', $skill ) ) ) );

	// Foto sertifikat: JPG, PNG, WEBP, maksimal 5 foto, 2 MB per foto. Kalau tidak ada upload baru, foto sebelumnya dipakai.
	$fotos = array();
	if ( ! empty( $_FILES['sertifikat']['name'] ) && is_array( $_FILES['sertifikat']['name'] ) ) {
		$n = count( $_FILES['sertifikat']['name'] );
		if ( $n > 5 ) {
			mincat_flow_back( $back, 'Maksimal 5 foto sertifikat.' );
		}
		for ( $i = 0; $i < $n; $i++ ) {
			if ( UPLOAD_ERR_NO_FILE === (int) $_FILES['sertifikat']['error'][ $i ] ) {
				continue;
			}
			if ( UPLOAD_ERR_OK !== (int) $_FILES['sertifikat']['error'][ $i ] || (int) $_FILES['sertifikat']['size'][ $i ] > 2 * 1024 * 1024 ) {
				mincat_flow_back( $back, 'Foto sertifikat harus JPG, PNG, atau WEBP, maksimal 2 MB per foto.' );
			}
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		for ( $i = 0; $i < $n; $i++ ) {
			if ( UPLOAD_ERR_NO_FILE === (int) $_FILES['sertifikat']['error'][ $i ] ) {
				continue;
			}
			$file = array(
				'name'     => sanitize_file_name( wp_unslash( $_FILES['sertifikat']['name'][ $i ] ) ),
				'type'     => $_FILES['sertifikat']['type'][ $i ],
				'tmp_name' => $_FILES['sertifikat']['tmp_name'][ $i ],
				'error'    => 0,
				'size'     => (int) $_FILES['sertifikat']['size'][ $i ],
			);
			$res = wp_handle_upload(
				$file,
				array(
					'test_form' => false,
					'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ),
				)
			);
			if ( isset( $res['error'] ) ) {
				mincat_flow_back( $back, 'Foto sertifikat gagal diunggah: ' . $res['error'] );
			}
			$fotos[] = $res['url'];
		}
	}
	if ( ! $fotos && $own ) {
		$base  = mincat_karya_fields( $own->ID, (bool) get_post_meta( $own->ID, 'pending_k', true ) );
		$fotos = isset( $base['pf']['sertifikat_foto'] ) ? (array) $base['pf']['sertifikat_foto'] : array();
	}

	// Background banner: bawaan (preset) atau upload sendiri. Maksimal 500 KB, ditolak langsung kalau lebih.
	$presets = mincat_banner_presets();
	$prev_pf = array();
	if ( $own ) {
		if ( get_post_meta( $own->ID, 'pending_k', true ) ) {
			$pend    = get_post_meta( $own->ID, 'pending', true );
			$prev_pf = is_array( $pend ) && isset( $pend['profil_form'] ) ? (array) $pend['profil_form'] : array();
		} else {
			$prev_pf = (array) get_post_meta( $own->ID, 'profil_form', true );
		}
	}
	$prev_b = isset( $prev_pf['banner'] ) ? (array) $prev_pf['banner'] : array();
	$bmode  = isset( $_POST['banner_mode'] ) ? sanitize_key( wp_unslash( $_POST['banner_mode'] ) ) : 'preset';
	$banner = array( 'type' => 'preset', 'value' => 'navy' );

	if ( 'upload' === $bmode ) {
		$bf  = isset( $_FILES['banner_file'] ) ? $_FILES['banner_file'] : array();
		$err = isset( $bf['error'] ) ? (int) $bf['error'] : UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_NO_FILE === $err ) {
			if ( isset( $prev_b['type'] ) && 'upload' === $prev_b['type'] ) {
				$banner = $prev_b;
			} else {
				mincat_flow_back( $back, 'Pilih file background dulu (JPG, PNG, atau WEBP, maksimal 500 KB).' );
			}
		} elseif ( UPLOAD_ERR_OK !== $err || (int) $bf['size'] > 500 * 1024 ) {
			mincat_flow_back( $back, 'Background ditolak. Ukurannya maksimal 500 KB. Kecilkan fotomu lalu coba lagi.' );
		} else {
			$ext = strtolower( pathinfo( (string) $bf['name'], PATHINFO_EXTENSION ) );
			if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) {
				mincat_flow_back( $back, 'Background harus berformat JPG, PNG, atau WEBP.' );
			}
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$upload_file = array(
				'name'     => sanitize_file_name( wp_unslash( $bf['name'] ) ),
				'type'     => isset( $bf['type'] ) ? (string) $bf['type'] : '',
				'tmp_name' => $bf['tmp_name'],
				'error'    => 0,
				'size'     => (int) $bf['size'],
			);
			$res = wp_handle_upload(
				$upload_file,
				array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) )
			);
			if ( ! is_array( $res ) || isset( $res['error'] ) || empty( $res['url'] ) ) {
				mincat_flow_back( $back, 'Background gagal disimpan di server. Coba foto lain, atau hubungi admin.' );
			}
			$banner = array( 'type' => 'upload', 'value' => $res['url'] );
		}
	} else {
		$pk     = isset( $_POST['banner_preset'] ) ? sanitize_key( wp_unslash( $_POST['banner_preset'] ) ) : 'navy';
		$banner = array( 'type' => 'preset', 'value' => isset( $presets[ $pk ] ) ? $pk : 'navy' );
	}
	// Foto diri (untuk halaman detail): JPG, PNG, WEBP, maksimal 8 MB, diperkecil ke 800 x 1000 px.
	$fd_url = $own ? (string) ( mincat_karya_fields( $own->ID, (bool) get_post_meta( $own->ID, 'pending_k', true ) )['pf']['foto_diri'] ?? '' ) : '';
	$fd     = isset( $_FILES['foto_diri'] ) ? $_FILES['foto_diri'] : array();
	$fd_err = isset( $fd['error'] ) ? (int) $fd['error'] : UPLOAD_ERR_NO_FILE;
	if ( UPLOAD_ERR_NO_FILE !== $fd_err ) {
		if ( UPLOAD_ERR_OK !== $fd_err || (int) $fd['size'] > 8 * 1024 * 1024 ) {
			mincat_flow_back( $back, 'Foto diri harus JPG, PNG, atau WEBP, maksimal 8 MB.' );
		}
		$fd_ext = strtolower( pathinfo( (string) $fd['name'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $fd_ext, array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) {
			mincat_flow_back( $back, 'Foto diri harus JPG, PNG, atau WEBP.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$upload_fd = array(
			'name'     => sanitize_file_name( wp_unslash( $fd['name'] ) ),
			'type'     => isset( $fd['type'] ) ? (string) $fd['type'] : '',
			'tmp_name' => $fd['tmp_name'],
			'error'    => 0,
			'size'     => (int) $fd['size'],
		);
		$res = wp_handle_upload(
			$upload_fd,
			array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) )
		);
		if ( ! is_array( $res ) || isset( $res['error'] ) || empty( $res['url'] ) ) {
			mincat_flow_back( $back, 'Foto diri gagal disimpan. Coba foto lain.' );
		}
		$editor = wp_get_image_editor( $res['file'] );
		if ( ! is_wp_error( $editor ) ) {
			$editor->resize( 800, 1000, true );
			$editor->set_quality( 82 );
			$editor->save( $res['file'] );
		}
		$fd_url = $res['url'];
	}

	$profil = array(
		'nama'            => $nama,
		'kelas'           => $kelas,
		'minat'           => $minat,
		'skill'           => $skill,
		'sertifikat'      => $sertif,
		'sertifikat_foto' => $fotos,
		'project'         => $project,
		'pengalaman' => $pengalaman,
		'foto_diri' => $fd_url,
		'website'         => $website,
		'harapan'         => $harapan,
		'banner'          => $banner,
	);
	$t = current_time( 'd M Y H:i' );

	if ( $own ) {
		$id   = $own->ID;
		wp_update_post( array( 'ID' => $id, 'post_title' => $nama, 'post_content' => $harapan ) );
		$hist = (array) get_post_meta( $id, 'hist', true );
	} else {
		$id   = wp_insert_post(
			array(
				'post_type'    => 'mincat_karya',
				'post_status'  => 'publish',
				'post_author'  => $uid,
				'post_title'   => $nama,
				'post_content' => $harapan,
			)
		);
		$hist = array();
	}
	if ( $id && ! is_wp_error( $id ) ) {
		$hist[] = array( 's' => $live_verified ? 'Terverifikasi' : 'Menunggu Review', 'fb' => '', 't' => $t );
		update_post_meta( $id, 'c', $kelas );
		if ( ! $live_verified ) {
			update_post_meta( $id, 's', 'Menunggu Review' );
			update_post_meta( $id, 'k', 'review' );
			update_post_meta( $id, 'fb', '' );
		}
		update_post_meta( $id, 'art', '' );
		update_post_meta( $id, 'tools', $tools );
		update_post_meta( $id, 'profil_form', $profil );
		update_post_meta( $id, 'hist', $hist );
		update_post_meta( $id, 'showcase', 0 );
	}
	wp_safe_redirect( add_query_arg( 'ok', '1', $tab_k ) );
	exit;
}
add_action( 'admin_post_mincat_add_karya', function () {
		mincat_safe_run( 'mincat_handle_add_karya', mincat_url( 'portofolio-baru' ) );
	} );

function mincat_handle_karya_review() {
	$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	check_admin_referer( 'mincat_review_' . $id );

	$post = get_post( $id );
	if ( ! is_user_logged_in() || ! $post || 'mincat_karya' !== $post->post_type ) {
		wp_die( 'Karya tidak ditemukan.' );
	}
	$boleh = current_user_can( 'manage_options' )
	|| ( 'guru' === mincat_role() && (int) get_user_meta( $post->post_author, 'mincat_guru', true ) === get_current_user_id() );
	if ( ! $boleh ) {
		wp_die( 'Kamu tidak berhak meninjau karya ini.' );
	}

	$back    = mincat_url( 'review' );
	$pending = 'review' === (string) get_post_meta( $id, 'pending_k', true );
	if ( ! $pending && 'review' !== (string) get_post_meta( $id, 'k', true ) ) {
		mincat_flow_back( $back, 'Karya ini tidak sedang menunggu review.' );
	}
	$act  = isset( $_POST['act'] ) ? sanitize_key( wp_unslash( $_POST['act'] ) ) : '';
	$hist = (array) get_post_meta( $id, 'hist', true );
	$t    = current_time( 'd M Y H:i' );

	if ( 'acc' === $act ) {
		if ( $pending ) {
			$p = (array) get_post_meta( $id, 'pending', true );
			wp_update_post( array( 'ID' => $id, 'post_title' => $p['title'], 'post_content' => $p['content'] ) );
			update_post_meta( $id, 'c', $p['c'] );
			update_post_meta( $id, 'tools', $p['tools'] );
			update_post_meta( $id, 'profil_form', $p['profil_form'] );
			delete_post_meta( $id, 'pending' );
			delete_post_meta( $id, 'pending_k' );
			delete_post_meta( $id, 'pending_fb' );
		} else {
			update_post_meta( $id, 'k', 'verified' );
			update_post_meta( $id, 's', 'Terverifikasi' );
			update_post_meta( $id, 'fb', '' );
		}
		$hist[] = array( 's' => 'Terverifikasi', 'fb' => '', 't' => $t );
	} elseif ( 'revisi' === $act ) {
		$cat = isset( $_POST['catatan'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['catatan'] ) ) ) : '';
		if ( mb_strlen( $cat ) < 10 ) {
			mincat_flow_back( $back, 'Tulis catatan revisi minimal 10 karakter.' );
		}
		if ( $pending ) {
			update_post_meta( $id, 'pending_k', 'revision' );
			update_post_meta( $id, 'pending_fb', $cat );
		} else {
			update_post_meta( $id, 'k', 'revision' );
			update_post_meta( $id, 's', 'Revisi' );
			update_post_meta( $id, 'fb', $cat );
		}
		$hist[] = array( 's' => 'Revisi', 'fb' => $cat, 't' => $t );
	} else {
		mincat_flow_back( $back );
	}
	update_post_meta( $id, 'hist', $hist );
	mincat_flow_back( $back );
}
add_action( 'admin_post_mincat_karya_review', function () {
		mincat_safe_run( 'mincat_handle_karya_review', mincat_url( 'review' ) );
	} );

/** Background banner bawaan (gradasi). Bisa ditambah di sini. */
function mincat_banner_presets() {
	$base = get_template_directory_uri() . '/assets/img/';
	return array(
		'navy'   => array( 'Biru', "url('" . $base . "banner-navy.webp') center / cover no-repeat" ),
		'teal'   => array( 'Teal', "url('" . $base . "banner-teal.webp') center / cover no-repeat" ),
		'sunset' => array( 'Oranye', "url('" . $base . "banner-sunset.webp') center / cover no-repeat" ),
		'welcome' => array( 'Malam', "url('" . $base . "banner-welcome.webp') center / cover no-repeat" ),
		'laut'    => array( 'Laut', "url('" . $base . "banner-laut.webp') center / cover no-repeat" ),
		'kucing'  => array( 'Kucing laut', "url('" . $base . "banner-laut-cats.webp') center / cover no-repeat" ),
	);
}

/** Banner karya: background pilihan siswa, atau banner default (mincat_art) kalau belum memilih. */
function mincat_karya_banner( $id, $pending = false ) {
	$f = mincat_karya_fields( $id, $pending );
	$b = isset( $f['pf']['banner'] ) ? (array) $f['pf']['banner'] : array();
	$presets = mincat_banner_presets();
	$bg = '';
	if ( isset( $b['type'] ) && 'preset' === $b['type'] && isset( $presets[ $b['value'] ] ) ) {
		$bg = $presets[ $b['value'] ][1];
	} elseif ( isset( $b['type'] ) && 'upload' === $b['type'] && ! empty( $b['value'] ) ) {
		$bg = 'url(' . esc_url( $b['value'] ) . ') center / cover no-repeat';
	}
	if ( '' === $bg ) {
		return mincat_art( (string) get_post_meta( $id, 'art', true ) );
	}
	return '<div class="karya-banner" style="background:' . esc_attr( $bg ) . '"></div>';
}

/**
 * Menjalankan handler dengan pengaman: error PHP yang tertangkap dicatat ke error log server
 * dan ditampilkan sebagai pesan di form, tidak lagi halaman "critical error".
 * Error fatal yang tidak bisa ditangkap PHP (misalnya kehabisan memori) tetap tidak tertangkap.
 */
function mincat_safe_run( $handler, $back ) {
	try {
		call_user_func( $handler );
	} catch ( Throwable $e ) {
		error_log( 'MINCAT ' . $handler . ': ' . $e->getMessage() . ' di ' . $e->getFile() . ':' . $e->getLine() );
		mincat_flow_back( $back, 'Ada gangguan di server: ' . $e->getMessage() . ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')' );
	}
}

/** admin-post.php?action=mincat_toggle_showcase: siswa memilih menampilkan karya terverifikasi di beranda. */
function mincat_handle_toggle_showcase() {
	if ( ! is_user_logged_in() || 'siswa' !== mincat_role() ) {
		wp_die( 'Hanya siswa yang bisa mengatur tampilan karyanya.' );
	}
	$id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	check_admin_referer( 'mincat_showcase_' . $id );
	$tab  = add_query_arg( 'tab', 'karya', mincat_url( 'akun' ) );
	$post = get_post( $id );
	if ( ! $post || 'mincat_karya' !== $post->post_type || (int) $post->post_author !== get_current_user_id() ) {
		wp_die( 'Karya tidak ditemukan.' );
	}
	if ( 'verified' !== (string) get_post_meta( $id, 'k', true ) ) {
		mincat_flow_back( $tab, 'Hanya karya yang sudah terverifikasi yang bisa ditampilkan di beranda.' );
	}
	$on = ( isset( $_POST['on'] ) && '1' === (string) $_POST['on'] ) ? 1 : 0;
	update_post_meta( $id, 'showcase', $on );
	wp_safe_redirect( add_query_arg( 'ok', 'showcase', $tab ) );
	exit;
}
add_action( 'admin_post_mincat_toggle_showcase', function () {
		mincat_safe_run( 'mincat_handle_toggle_showcase', add_query_arg( 'tab', 'karya', mincat_url( 'akun' ) ) );
	} );
