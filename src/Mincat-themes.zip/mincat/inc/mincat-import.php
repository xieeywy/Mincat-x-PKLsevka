<?php
/**
 * Impor daftar IDUKA / bengkel (assets/data/iduka-pkl.csv) sebagai lowongan PKL yang tersedia.
 * Hanya admin. Data yang sudah ada (kunci bidang+nomor) tidak diduplikasi.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** admin-post.php?action=mincat_import_pkl */
function mincat_handle_import_pkl() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Hanya admin yang bisa mengimpor daftar PKL.' );
	}
	check_admin_referer( 'mincat_import_pkl' );

	$file = get_template_directory() . '/assets/data/iduka-pkl.csv';
	if ( ! is_readable( $file ) ) {
		mincat_flow_back( mincat_url( 'akun' ), 'File daftar PKL tidak ditemukan di tema.' );
	}
	$label = array( 'TKJ' => 'Teknik Komputer dan Jaringan', 'TSM' => 'Teknik Sepeda Motor' );
	$h     = fopen( $file, 'r' );
	fgetcsv( $h ); // lewati baris judul
	$tambah = 0;
	$lewati = 0;
	while ( ( $row = fgetcsv( $h ) ) !== false ) {
		if ( count( $row ) < 4 ) {
			continue;
		}
		list( $bidang, $no, $nama, $alamat ) = array_map( 'trim', $row );
		if ( ! isset( $label[ $bidang ] ) ) {
			continue;
		}
		$key = 'pkl-' . $bidang . '-' . $no;
		$ada = get_posts(
			array(
				'post_type'   => 'mincat_peluang',
				'post_status' => 'any',
				'numberposts' => 1,
				'meta_key'    => 'import_key',
				'meta_value'  => $key,
				'fields'      => 'ids',
			)
		);
		if ( $ada ) {
			// Sudah ada: pastikan statusnya disetujui supaya tampil di Peluang PKL.
			update_post_meta( $ada[0], 'status', 'disetujui' );
			++$lewati;
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'   => 'mincat_peluang',
				'post_status' => 'publish',
				'post_author' => get_current_user_id(),
				'post_title'  => 'Magang ' . $label[ $bidang ] . ' di ' . $nama,
				'post_content'=> 'Tempat PKL ' . $label[ $bidang ] . '. Alamat: ' . $alamat . '.',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'perusahaan', $nama );
			update_post_meta( $id, 'lokasi', $alamat );
			update_post_meta( $id, 'kuota', 1 );
			update_post_meta( $id, 'status', 'disetujui' );
			update_post_meta( $id, 'bidang', $bidang );
			update_post_meta( $id, 'import_key', $key );
			++$tambah;
		}
	}
	fclose( $h );
	wp_safe_redirect( add_query_arg( array( 'impor' => 1, 'tambah' => $tambah, 'lewati' => $lewati ), mincat_url( 'akun' ) ) );
	exit;
}
add_action( 'admin_post_mincat_import_pkl', function () {
		mincat_safe_run( 'mincat_handle_import_pkl', mincat_url( 'akun' ) );
	} );
