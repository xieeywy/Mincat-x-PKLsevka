<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'opportunities' );
$mincat_bidangs = array( 'Semua', 'TKJ', 'TSM', 'TJAT' );
$mincat_lokasis = array( 'Semua Lokasi', 'Jakarta', 'Bandung', 'Yogyakarta' );
$mincat_urutan  = array( 'Tenggat terdekat', 'Judul A-Z', 'Kecocokan tertinggi' );
$mincat_q       = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
$mincat_bidang  = isset( $_GET['bidang'] ) && in_array( wp_unslash( $_GET['bidang'] ), $mincat_bidangs, true ) ? wp_unslash( $_GET['bidang'] ) : 'Semua';
$mincat_lokasi  = isset( $_GET['lokasi'] ) && in_array( wp_unslash( $_GET['lokasi'] ), $mincat_lokasis, true ) ? wp_unslash( $_GET['lokasi'] ) : 'Semua Lokasi';
$mincat_sort    = isset( $_GET['urut'] ) && in_array( wp_unslash( $_GET['urut'] ), $mincat_urutan, true ) ? wp_unslash( $_GET['urut'] ) : 'Tenggat terdekat';

// Filter: bidang, lokasi (awalan), kata kunci (seluruh isi baris, seperti j.join(' ') di JS).
$mincat_dec = array();
foreach ( mincat_approved_jobs() as $i => $j ) {
	if ( 'Semua' !== $mincat_bidang && $j[3] !== $mincat_bidang ) {
		continue;
	}
	if ( 'Semua Lokasi' !== $mincat_lokasi && 0 !== strpos( $j[2], $mincat_lokasi ) ) {
		continue;
	}
	$flat = array();
	for ( $k = 0; $k <= 9; $k++ ) {
		$flat[] = is_array( $j[ $k ] ) ? implode( ',', $j[ $k ] ) : $j[ $k ];
	}
	if ( '' !== $mincat_q && false === mb_stripos( implode( ' ', $flat ), $mincat_q ) ) {
		continue;
	}
	$mincat_dec[] = array( $i, $j );
}

// Urutkan (stabil, seperti Array.sort di JS).
usort(
	$mincat_dec,
	function ( $a, $b ) use ( $mincat_sort ) {
		if ( 'Judul A-Z' === $mincat_sort ) {
			$c = strcasecmp( $a[1][0], $b[1][0] );
		} elseif ( 'Kecocokan tertinggi' === $mincat_sort ) {
			$ma = mincat_match_job( $a[1] );
			$mb = mincat_match_job( $b[1] );
			$c  = $mb['pct'] - $ma['pct'];
		} else {
			$x = mincat_days_left( $a[1] );
			$y = mincat_days_left( $b[1] );
			$c = ( null === $x || null === $y ) ? 0 : $x - $y;
		}
		return 0 !== $c ? $c : $a[0] - $b[0];
	}
);
$mincat_list = array();
foreach ( $mincat_dec as $d ) {
	$mincat_list[] = $d[1];
}
set_query_var( 'mincat_page', 'opportunities' );
get_header();
get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Temukan Peluang PKL', 'Jelajahi kesempatan untuk mengembangkan diri dan menambah pengalaman.' ); ?>
<form id="mincat-filter" method="get" hidden>
</form>
<div class="search">
	<input id="q" aria-label="Cari peluang" placeholder="Cari posisi, perusahaan, atau kata kunci" name="q" form="mincat-filter" value="<?php echo esc_attr( $mincat_q ); ?>"><button class="btn primary" type="submit" form="mincat-filter">Cari</button>
</div>
<div class="filters">
	<select aria-label="Bidang" name="bidang" form="mincat-filter"><?php foreach ( $mincat_bidangs as $v ) { ?><option <?php echo $mincat_bidang === $v ? 'selected' : ''; ?>><?php echo esc_html( $v ); ?></option><?php } ?></select>
	<select aria-label="Lokasi" name="lokasi" form="mincat-filter"><?php foreach ( $mincat_lokasis as $v ) { ?><option <?php echo $mincat_lokasi === $v ? 'selected' : ''; ?>><?php echo esc_html( $v ); ?></option><?php } ?></select>
	<select aria-label="Urutkan" name="urut" form="mincat-filter"><?php foreach ( $mincat_urutan as $v ) { ?><option <?php echo $mincat_sort === $v ? 'selected' : ''; ?>><?php echo esc_html( $v ); ?></option><?php } ?></select>
</div>
<div class="joblist">
	<?php if ( $mincat_list ) { foreach ( $mincat_list as $j ) { $m = mincat_match_job( $j ); ?>
			<article class="job">
				<div class="logo logo-mincat">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/mincat-badge.webp' ); ?>" alt="MINCAT" width="32" height="32" style="width:100%;height:100%;object-fit:contain;display:block">
				</div>
				<div class="grow">
					<h3>
						<?php echo esc_html( $j[0] ); ?> <?php if ( mincat_logged_in() ) { echo mincat_match_pill( $m ); } else { ?><a class="tiny" href="<?php echo esc_url( mincat_url( 'masuk' ) ); ?>">Masuk untuk lihat kecocokanmu</a><?php } ?>
					</h3>
					<p>
						<?php echo esc_html( $j[1] ); ?>
					</p>
					<?php echo mincat_match_reasons( $m ); ?>
					<div class="meta">
						<span><?php echo mincat_ic( 'pin' ); ?> <?php echo esc_html( $j[2] ); ?></span><span><?php echo mincat_ic( 'clock' ); ?> <?php echo esc_html( $j[4] ); ?></span><span><?php echo mincat_ic( 'wallet' ); ?> <?php echo esc_html( $j[5] ); ?></span>
					</div>
					<div class="filters">
						<span class="pill"><?php echo esc_html( $j[3] ); ?></span><span class="pill">PKL</span>
					</div>
				</div>
				<div class="job-side">
					<?php echo mincat_deadline_tag( $j ); ?><a class="btn primary small" href="<?php echo esc_url( add_query_arg( 'job', (int) $j['id'], mincat_url( 'jobdetail' ) ) ); ?>">Lihat detail</a>
				</div>
			</article>
		<?php } } else { echo mincat_empty_box( 'Tidak ada peluang yang cocok.', 'Coba ubah bidang, lokasi, atau kata kunci.' ); } ?>
</div>
<p class="tiny muted" style="margin-top:14px">
	
</p>
<?php get_template_part( 'template-parts/shell', 'close' ); get_footer();
