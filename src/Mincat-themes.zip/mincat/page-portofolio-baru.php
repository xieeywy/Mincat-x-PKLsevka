<?php
/**
 * Portofolio siswa: buat (kalau belum ada) atau edit (kalau sudah ada dan belum terverifikasi).
 * Maksimal satu portofolio per siswa. Pemetaan field ada di inc/mincat-karya.php.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}
if ( 'siswa' !== mincat_role() ) {
	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}

$mincat_err  = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
$mincat_user = wp_get_current_user();
$mincat_own  = mincat_my_karya( $mincat_user->ID );
$mincat_k    = $mincat_own ? (string) get_post_meta( $mincat_own->ID, 'k', true ) : '';
$mincat_pk   = $mincat_own ? (string) get_post_meta( $mincat_own->ID, 'pending_k', true ) : '';
$mincat_src  = $mincat_own ? mincat_karya_fields( $mincat_own->ID, 'review' === $mincat_pk ) : array( 'pf' => array() );
$mincat_pf   = isset( $mincat_src['pf'] ) ? $mincat_src['pf'] : array();
$mincat_fb   = $mincat_own ? ( 'revision' === $mincat_pk ? (string) get_post_meta( $mincat_own->ID, 'pending_fb', true ) : ( 'revision' === $mincat_k ? (string) get_post_meta( $mincat_own->ID, 'fb', true ) : '' ) ) : '';
$mincat_fb_k = $mincat_own && '' !== $mincat_fb ? 'revision' : '';

$mincat_val = function ( $k, $default = '' ) use ( $mincat_pf ) {
	return isset( $mincat_pf[ $k ] ) ? (string) $mincat_pf[ $k ] : $default;
};
$mincat_lbl = 'display:block;font-weight:600;margin:0 0 6px';
$mincat_in  = 'display:block;width:100%;box-sizing:border-box;margin:0';
$mincat_row = 'margin:0 0 16px';

$mincat_title = $mincat_own ? 'Edit portofolio' : 'Tambah karya';
$mincat_btn   = 'verified' === $mincat_k ? 'Simpan perubahan' : ( 'revision' === $mincat_k || 'revision' === $mincat_pk ? 'Kirim ulang ke review' : 'Kirim ke review' );

set_query_var( 'mincat_page', 'portofolio-baru' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
echo mincat_title( $mincat_title, $mincat_own ? 'Perbarui portofoliomu. Perubahan dikirim lagi ke review guru.' : 'Isi data dirimu dan karya yang kamu miliki. Karya baru masuk antrean review guru.', '<form method="get" action="' . esc_url( mincat_url( 'akun' ) ) . '" style="margin:0"><input type="hidden" name="tab" value="karya"><button class="btn secondary small" type="submit">Kembali</button></form>' );
?>
<?php if ( $mincat_err ) : ?>
<p class="err">
	<?php echo esc_html( $mincat_err ); ?>
</p>
<?php endif; ?>

<?php if ( 'review' === $mincat_pk ) : ?>
<div class="panel" style="max-width:650px;border-left:4px solid #2463ad;margin-bottom:16px">
	<b>Perubahanmu menunggu konfirmasi guru</b>
	<p class="tiny muted" style="margin:6px 0 0">
		Portofolio yang tampil tetap versi terverifikasi sampai perubahan ini disetujui.
	</p>
</div>
<?php endif; ?>

<?php if ( '' !== $mincat_fb ) : ?>
<div class="panel" style="max-width:650px;border-left:4px solid #b97623;margin-bottom:16px">
	<b>Catatan revisi dari guru</b>
	<p style="margin:6px 0 0">
		<?php echo esc_html( $mincat_fb ); ?>
	</p>
</div>
<?php endif; ?>

<form class="panel" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:650px" novalidate>
	<input type="hidden" name="action" value="mincat_add_karya">
	<?php wp_nonce_field( 'mincat_add_karya' ); ?>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-foto" style="<?php echo esc_attr( $mincat_lbl ); ?>">Foto diri <span class="tiny muted">(untuk halaman detail, opsional)</span></label>
		<input id="f-foto" name="foto_diri" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<p class="tiny muted" style="margin:6px 0 0">JPG, PNG, atau WEBP, maksimal 8 MB. Foto diperkecil otomatis. Hanya tampil untuk akun yang sudah login.<?php echo ! empty( $mincat_pf['foto_diri'] ) ? ' Foto yang sekarang tetap dipakai kalau tidak diganti.' : ''; ?></p>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-nama" style="<?php echo esc_attr( $mincat_lbl ); ?>">Nama</label>
		<input id="f-nama" name="nama" value="<?php echo esc_attr( $mincat_val( 'nama', $mincat_user->display_name ) ); ?>" style="<?php echo esc_attr( $mincat_in ); ?>" required>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-kelas" style="<?php echo esc_attr( $mincat_lbl ); ?>">Kelas dan jurusan</label>
		<input id="f-kelas" name="kelas" value="<?php echo esc_attr( $mincat_val( 'kelas', (string) get_user_meta( $mincat_user->ID, 'mincat_jurusan', true ) ) ); ?>" placeholder="contoh: XII TKJ 1" style="<?php echo esc_attr( $mincat_in ); ?>" required>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-minat" style="<?php echo esc_attr( $mincat_lbl ); ?>">Minat</label>
		<input id="f-minat" name="minat" value="<?php echo esc_attr( $mincat_val( 'minat' ) ); ?>" style="<?php echo esc_attr( $mincat_in ); ?>">
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-skill" style="<?php echo esc_attr( $mincat_lbl ); ?>">Skill dan bakat</label>
		<textarea id="f-skill" name="skill" rows="3" placeholder="tulis sendiri, pisahkan dengan koma" style="<?php echo esc_attr( $mincat_in ); ?>" required><?php echo esc_textarea( $mincat_val( 'skill' ) ); ?></textarea>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-sertif" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat dan penghargaan</label>
		<label for="f-sertif-1" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat 1 <span class="tiny muted">(opsional)</span></label>
		<input id="f-sertif-1" name="sertifikat[]" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<label for="f-sertif-2" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat 2 <span class="tiny muted">(opsional)</span></label>
		<input id="f-sertif-2" name="sertifikat[]" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<label for="f-sertif-3" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat 3 <span class="tiny muted">(opsional)</span></label>
		<input id="f-sertif-3" name="sertifikat[]" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<label for="f-sertif-4" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat 4 <span class="tiny muted">(opsional)</span></label>
		<input id="f-sertif-4" name="sertifikat[]" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<label for="f-sertif-5" style="<?php echo esc_attr( $mincat_lbl ); ?>">Sertifikat 5 <span class="tiny muted">(opsional)</span></label>
		<input id="f-sertif-5" name="sertifikat[]" type="file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<p class="tiny muted" style="margin:6px 0 0">
			Foto JPG, PNG, atau WEBP. Maksimal 5 foto, 2 MB per foto. (opsional)<?php echo ! empty( $mincat_pf['sertifikat_foto'] ) ? ' Upload baru menggantikan foto yang sekarang.' : ''; ?>
		</p>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-project" style="<?php echo esc_attr( $mincat_lbl ); ?>">Projek yang dimiliki <span class="tiny muted">(jika punya)</span></label>
		<textarea id="f-project" name="project" rows="3" style="<?php echo esc_attr( $mincat_in ); ?>"><?php echo esc_textarea( $mincat_val( 'project' ) ); ?></textarea>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-pengalaman" style="<?php echo esc_attr( $mincat_lbl ); ?>">Pengalaman <span class="tiny muted">(opsional, satu per baris)</span></label>
		<textarea id="f-pengalaman" name="pengalaman" rows="3" style="<?php echo esc_attr( $mincat_in ); ?>"><?php echo esc_textarea( $mincat_val( 'pengalaman' ) ); ?></textarea>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-web" style="<?php echo esc_attr( $mincat_lbl ); ?>">Website portofolio sendiri <span class="tiny muted">(jika punya)</span></label>
		<input id="f-web" name="website" type="url" placeholder="https://" value="<?php echo esc_attr( $mincat_val( 'website' ) ); ?>" style="<?php echo esc_attr( $mincat_in ); ?>">
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label for="f-harapan" style="<?php echo esc_attr( $mincat_lbl ); ?>">Harapan kedepannya</label>
		<textarea id="f-harapan" name="harapan" rows="3" style="<?php echo esc_attr( $mincat_in ); ?>" required><?php echo esc_textarea( $mincat_val( 'harapan' ) ); ?></textarea>
	</div>

	<div style="<?php echo esc_attr( $mincat_row ); ?>">
		<label style="<?php echo esc_attr( $mincat_lbl ); ?>">Background banner</label>
		<?php $mincat_bcur = isset( $mincat_pf['banner'] ) ? (array) $mincat_pf['banner'] : array(); $mincat_bmode = isset( $mincat_bcur['type'] ) ? $mincat_bcur['type'] : 'preset'; ?>
		<label style="display:block;margin:0 0 6px"><input type="radio" name="banner_mode" value="preset" <?php checked( 'preset', $mincat_bmode ); ?>> Pilih background bawaan</label>
		<select name="banner_preset" style="<?php echo esc_attr( $mincat_in ); ?>;margin:0 0 10px"><?php foreach ( mincat_banner_presets() as $bk => $bv ) : ?><option value="<?php echo esc_attr( $bk ); ?>" <?php selected( isset( $mincat_bcur['value'] ) ? $mincat_bcur['value'] : '', $bk ); ?>><?php echo esc_html( $bv[0] ); ?></option><?php endforeach; ?></select>
		<label style="display:block;margin:0 0 6px"><input type="radio" name="banner_mode" value="upload" <?php checked( 'upload', $mincat_bmode ); ?>> Upload background sendiri</label>
		<input type="file" name="banner_file" accept="image/jpeg,image/png,image/webp" style="<?php echo esc_attr( $mincat_in ); ?>">
		<p class="tiny muted" style="margin:6px 0 0">
			JPG, PNG, atau WEBP, maksimal 500 KB.
		</p>
	</div>

	<button class="btn primary small" type="submit"><?php echo esc_html( $mincat_btn ); ?></button>
</form>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
