<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_p      = mincat_profile();
$mincat_labels = mincat_role_label();
$mincat_rl     = mincat_nav_role();
?>
<div class="layout" style="display:block">
	<section class="main">