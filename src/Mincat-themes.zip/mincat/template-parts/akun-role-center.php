<?php
/**
 * Pusat dashboard untuk guru, mentor, dan perusahaan: sapaan, ringkasan, dan daftar terbaru.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( isset( $_GET['tab'] ) && 'profil' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
	get_template_part( 'template-parts/akun-role', 'profil' );
	return;
}
$mc_role  = mincat_role();
$mc_uid   = get_current_user_id();
$mc_user  = wp_get_current_user();
$mc_first = trim( explode( ' ', trim( $mc_user->display_name ) )[0] );
$mc_st    = mincat_status_labels();

if ( 'perusahaan' === $mc_role ) {
	$mc_jobs   = mincat_my_jobs();
	$mc_apps   = mincat_lamaran_list( wp_list_pluck( $mc_jobs, 'ID' ) );
	$mc_terima = count( array_filter( $mc_apps, function ( $a ) use ( $mc_st ) {
		return $mc_st['diterima'] === $a['status'];
	} ) );
	$mc_stats = array(
		array( 'Lowongan saya', count( $mc_jobs ) ),
		array( 'Pelamar', count( $mc_apps ) ),
		array( 'Diterima', $mc_terima ),
	);
} else {
	$mc_queue = array();
	foreach ( get_posts(
		array(
			'post_type'   => 'mincat_karya',
			'numberposts' => -1,
			'post_status' => 'publish',
			'meta_query'  => array(
				'relation' => 'OR',
				array( 'key' => 'k', 'value' => 'review' ),
				array( 'key' => 'pending_k', 'value' => 'review' ),
			),
			'orderby'     => 'date',
			'order'       => 'ASC',
		)
	) as $mc_k ) {
		if ( 'admin' === $mc_role || (int) get_user_meta( $mc_k->post_author, 'mincat_guru', true ) === $mc_uid ) {
			$mc_queue[] = $mc_k;
		}
	}
	$mc_lamaran = mincat_lamaran_list( null, 'menunggu' );
	$mc_stats   = array(
		array( 'Karya menunggu review', count( $mc_queue ) ),
		array( 'Lamaran menunggu', count( $mc_lamaran ) ),
	);
}
?>
<div class="card section">
	<div class="sec-head"><h2>Halo, <?php echo esc_html( $mc_first ); ?></h2></div>
	<p class="sub" style="margin:0">Ringkasan tugasmu hari ini.</p>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-top:12px">
<?php foreach ( $mc_stats as $mc_s ) : ?>
	<div class="card section" style="margin:0">
		<p class="tiny muted" style="margin:0;text-transform:uppercase;letter-spacing:.06em"><?php echo esc_html( $mc_s[0] ); ?></p>
		<strong style="display:block;font-size:28px;margin-top:6px"><?php echo (int) $mc_s[1]; ?></strong>
	</div>
<?php endforeach; ?>
</div>
<div class="card section" style="margin-top:12px">
<?php if ( 'perusahaan' === $mc_role ) : ?>
	<div class="sec-head"><h2>Lowongan terbaru</h2><a class="link" href="<?php echo esc_url( mincat_url( 'company' ) ); ?>">Lihat semua &rsaquo;</a></div>
	<?php if ( $mc_jobs ) : foreach ( array_slice( $mc_jobs, 0, 5 ) as $mc_j ) : ?>
		<div class="nxd-hist__r"><strong><?php echo esc_html( $mc_j->post_title ); ?></strong><small><?php echo esc_html( (string) get_post_meta( $mc_j->ID, 'lokasi', true ) ); ?></small></div>
	<?php endforeach; else : ?>
		<p class="sub" style="margin:0">Belum ada lowongan. Buat lowongan dari menu Perusahaan.</p>
	<?php endif; ?>
<?php else : ?>
	<div class="sec-head"><h2>Antrean review</h2><a class="link" href="<?php echo esc_url( mincat_url( 'review' ) ); ?>">Lihat semua &rsaquo;</a></div>
	<?php if ( $mc_queue ) : foreach ( array_slice( $mc_queue, 0, 5 ) as $mc_k ) : ?>
		<div class="nxd-hist__r"><strong><?php echo esc_html( $mc_k->post_title ); ?></strong><small><?php echo esc_html( get_the_author_meta( 'display_name', $mc_k->post_author ) ); ?></small></div>
	<?php endforeach; else : ?>
		<p class="sub" style="margin:0">Tidak ada karya yang menunggu review.</p>
	<?php endif; ?>
<?php endif; ?>
</div>
<div class="mob-spacer" aria-hidden="true"></div>
