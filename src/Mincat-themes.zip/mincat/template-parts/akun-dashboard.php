<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
?>
<template shadowrootmode="open">
	<style><?php readfile( get_template_directory() . '/assets/css/mincat-akun.css' ); ?></style>
	<style><?php readfile( get_template_directory() . '/assets/css/mincat-akun-links.css' ); ?></style>
	<div id="akun">
		<div class="wrap">
			<?php if ( 'siswa' === mincat_role() ) { ?>
				<aside class="card side">
					<?php get_template_part( 'template-parts/akun-siswa', 'right' ); ?>
					<nav class="nav">
						<a href="<?php echo esc_url( add_query_arg( 'tab', 'dashboard', mincat_url( 'akun' ) ) ); ?>" data-tab="dashboard" class="<?php echo 'dashboard' === $mincat_tab ? 'on' : ''; ?>"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg></span>Dashboard</a>
						<a href="<?php echo esc_url( add_query_arg( 'tab', 'karya', mincat_url( 'akun' ) ) ); ?>" data-tab="karya" class="<?php echo 'karya' === $mincat_tab ? 'on' : ''; ?>"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg></span>Portofolio saya</a>
						<a href="<?php echo esc_url( add_query_arg( 'tab', 'lamaran', mincat_url( 'akun' ) ) ); ?>" data-tab="lamaran" class="<?php echo 'lamaran' === $mincat_tab ? 'on' : ''; ?>"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M7 3h10v18l-5-3-5 3z"/></svg></span>Lamaran</a>
						<a href="<?php echo esc_url( add_query_arg( 'tab', 'pesan', mincat_url( 'akun' ) ) ); ?>" data-tab="pesan" class="<?php echo 'pesan' === $mincat_tab ? 'on' : ''; ?>"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></span>Pesan</a>
						<a href="<?php echo esc_url( add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) ) ); ?>" data-tab="profil" class="<?php echo 'profil' === $mincat_tab ? 'on' : ''; ?>"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>Profil</a>
						<a href="<?php echo esc_url( wp_logout_url( mincat_url( 'home' ) ) ); ?>" data-logout="1"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.9"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg></span>Keluar</a>
					</nav>
					<div class="help">
						<div class="ph">
							<svg viewBox="0 0 150 150"><circle cx="75" cy="60" r="34" fill="#B3CDE0"/><rect x="40" y="96" width="70" height="40" rx="18" fill="#2B5C92"/><circle cx="62" cy="58" r="5" fill="#0C1446"/><circle cx="88" cy="58" r="5" fill="#0C1446"/></svg>
						</div>
						<strong>Butuh bantuan?</strong>
						<p class="sub">
							Tim MINCAT siap membantu kamu kapan saja.
						</p>
						<a class="btn sm" href="<?php echo esc_url( mincat_url( 'home' ) ); ?>" data-page="home">Hubungi kami</a>
					</div>
				</aside>
			<?php } elseif ( in_array( mincat_role(), array( 'guru', 'mentor', 'perusahaan' ), true ) ) { get_template_part( 'template-parts/akun-role', 'side' ); } ?>
			<section class="center" id="center">
				<?php
				if ( 'siswa' === mincat_role() ) {
					get_template_part( 'template-parts/akun-siswa', 'center' );
				} elseif ( in_array( mincat_role(), array( 'guru', 'mentor', 'perusahaan' ), true ) ) {
					get_template_part( 'template-parts/akun-role', 'center' );
				} else { ?>
					<div class="nxd-empty">
						<strong>Dashboard <?php echo esc_html( mincat_role_label()[ mincat_role() ] ?? mincat_role() ); ?></strong><small>Fitur peranmu ada di sini.</small>
					</div>
					<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
						<?php foreach ( mincat_role_menu_links() as $mincat_m ) { ?><a href="<?php echo esc_url( mincat_url( $mincat_m[0] ) ); ?>" style="display:inline-block;padding:9px 14px;border:1px solid #dfe7f1;border-radius:10px;color:#0b1734;text-decoration:none;font-weight:600;font-size:13px;background:#fff"><?php echo esc_html( $mincat_m[1] ); ?></a><?php } ?>
					</div>
				<?php } ?>
			</section>
			
		</div>
	</div>
</template>