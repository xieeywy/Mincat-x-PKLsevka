<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_own = mincat_my_karya( get_current_user_id() );
$mincat_new = mincat_url( 'portofolio-baru' );
$mincat_ok  = isset( $_GET['ok'] ) ? sanitize_key( wp_unslash( $_GET['ok'] ) ) : '';
if ( $mincat_own ) {
	$mincat_s    = (string) get_post_meta( $mincat_own->ID, 's', true );
	$mincat_k    = (string) get_post_meta( $mincat_own->ID, 'k', true );
	$mincat_fb   = (string) get_post_meta( $mincat_own->ID, 'fb', true );
	$mincat_pk   = (string) get_post_meta( $mincat_own->ID, 'pending_k', true );
	$mincat_pfb  = (string) get_post_meta( $mincat_own->ID, 'pending_fb', true );
	$mincat_jur  = (string) get_post_meta( $mincat_own->ID, 'c', true );
}
?>
<div class="sec-head">
	<h2>
		Portofolio saya
	</h2>
	<?php if ( ! $mincat_own ) { ?><a class="btn primary small" href="<?php echo esc_url( $mincat_new ); ?>">Tambah karya</a><?php } else { ?>
		<form method="get" action="<?php echo esc_url( $mincat_new ); ?>" style="margin:0">
			<button class="btn secondary small" type="submit">Edit</button>
		</form>
	<?php } ?>
</div>

<?php if ( 'pending' === $mincat_ok ) : ?>
<p class="tiny" style="color:#0C7A4B;margin:0 0 12px">
	Perubahan dikirim. Menunggu konfirmasi guru. Portofoliomu yang tampil tetap versi sebelumnya.
</p>
<?php endif; ?>

<?php if ( 'showcase' === $mincat_ok ) : ?>
<p class="tiny" style="color:#0C7A4B;margin:0 0 12px">
	Pengaturan beranda diperbarui.
</p>
<?php endif; ?>
<?php if ( ! $mincat_own ) : ?>
<?php echo mincat_empty_box( 'Belum ada portofolio.', 'Tambahkan satu portofolio. Setelah diverifikasi guru, portofoliomu tampil di halaman Portofolio.' ); ?>
<?php else : ?>
<article class="project">
	<?php echo mincat_karya_banner( (int) $mincat_own->ID ); ?>
	<h3>
		<?php echo esc_html( $mincat_own->post_title ); ?>
	</h3>
	<p class="tiny muted">
		<?php echo esc_html( $mincat_jur ); ?>
	</p>
	<p>
		<?php echo esc_html( $mincat_own->post_content ); ?>
	</p>
	<div class="bottom">
		<?php echo mincat_status( $mincat_s, $mincat_k ); ?>
	</div>
</article>

<?php if ( 'revision' === $mincat_k && '' !== $mincat_fb ) : ?>
<div class="panel" style="border-left:4px solid #b97623;margin-top:12px">
	<b>Catatan revisi dari guru</b>
	<p style="margin:6px 0 0">
		<?php echo esc_html( $mincat_fb ); ?>
	</p>
</div>
<?php endif; ?>

<?php if ( 'review' === $mincat_pk ) : ?>
<div class="panel" style="border-left:4px solid #2463ad;margin-top:12px">
	<b>Perubahanmu menunggu konfirmasi guru</b>
	<p class="tiny muted" style="margin:6px 0 0">
		Portofolio yang tampil tetap versi terverifikasi sampai perubahan ini disetujui.
	</p>
</div>
<?php elseif ( 'revision' === $mincat_pk ) : ?>
<div class="panel" style="border-left:4px solid #b97623;margin-top:12px">
	<b>Perubahanmu perlu direvisi</b>
	<p style="margin:6px 0 0">
		<?php echo esc_html( $mincat_pfb ); ?>
	</p>
	<p class="tiny muted" style="margin:6px 0 0">
		Klik Edit untuk memperbaiki perubahan, lalu kirim ulang.
	</p>
</div>
<?php endif; ?>
<?php endif; ?>

<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:16px 0 0">
	<?php if ( $mincat_own ) : ?>
	<a class="btn secondary small port-detail" href="<?php echo esc_url( add_query_arg( 'karya', (int) $mincat_own->ID, mincat_url( 'portofolio-detail' ) ) ); ?>">Lihat detail</a>
	<?php if ( 'verified' === $mincat_k ) :
		$mincat_sc = (int) get_post_meta( $mincat_own->ID, 'showcase', true ); ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
		<input type="hidden" name="action" value="mincat_toggle_showcase">
		<input type="hidden" name="id" value="<?php echo (int) $mincat_own->ID; ?>">
		<input type="hidden" name="on" value="<?php echo $mincat_sc ? '0' : '1'; ?>">
		<?php wp_nonce_field( 'mincat_showcase_' . $mincat_own->ID, '_wpnonce', false ); ?>
		<button class="btn primary small" type="submit"><?php echo $mincat_sc ? 'Sembunyikan dari beranda' : 'Tampilkan di beranda'; ?></button>
	</form>
	<?php endif; ?>
	<?php endif; ?>
	<button class="btn secondary small" data-mincat-action="share-portfolio" data-id="<?php echo (int) $mincat_own->ID; ?>">Bagikan tautan</button>
	<button class="btn secondary small" data-mincat-action="print-portfolio" data-id="<?php echo (int) $mincat_own->ID; ?>">Unduh PDF</button>
</div>
<?php if ( $mincat_own && 'verified' === $mincat_k ) : ?>
<p class="tiny muted" style="margin:8px 0 0">Tampil di beranda memakai inisial dan jurusan, tanpa nama lengkap.</p>
<?php endif; ?>
<div class="mob-spacer" aria-hidden="true"></div>
