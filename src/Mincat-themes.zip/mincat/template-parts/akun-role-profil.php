<?php
/**
 * Tab Profil untuk guru, mentor, dan perusahaan: foto profil, data saya, dan edit profil.
 * Blok disalin dari tab Profil siswa (tanpa kolom alamat rumah).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_user  = wp_get_current_user();
$mincat_uid   = $mincat_user->ID;
$mincat_phone = (string) get_user_meta( $mincat_uid, 'mincat_phone', true );
$mincat_photo = (string) get_user_meta( $mincat_uid, 'mincat_photo', true );
$mincat_init  = mincat_initials( $mincat_user->display_name );
$mincat_pesan_err = array();
$mincat_pesan_ok  = array();
$mincat_tab       = 'profil';
$mincat_err       = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
?>
<div class="card section">
	<div class="sec-head">
		<h2>
			Foto Profil
		</h2>
	</div>
	<div class="ak-photo">
		<div class="ak-photo-img">
			<?php if ( $mincat_photo ) : ?><img src="<?php echo esc_url( $mincat_photo ); ?>" alt="Foto profil"><?php else : ?><span><?php echo esc_html( $mincat_init ); ?></span><?php endif; ?>
		</div>
		<div>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
				<input type="hidden" name="action" value="mincat_upload_photo">
				<?php wp_nonce_field( 'mincat_upload_photo' ); ?>
				<input type="file" name="foto" accept="image/jpeg,image/png,image/webp" required style="display:block;margin:0 0 8px;width:100%">
				<p class="sub" style="margin:0 0 8px">
					JPG, PNG, atau WEBP, maksimal 8 MB. Foto akan diperkecil otomatis.
				</p>
				<button class="btn primary small" type="submit">Simpan foto</button>
			</form>
		</div>
	</div>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Data saya
		</h2>
	</div>
	<p class="tiny muted">
		Kamu berhak melihat, mengunduh, dan menghapus data akunmu. Penghapusan juga mencabut tautan bagikan yang aktif.
	</p>
	<div class="app-acts">
		<button class="btn secondary small" data-mincat-action="download-my-data">Unduh data saya (JSON)</button><button class="btn danger small" data-mincat-action="confirm-delete">Hapus akun dan data</button>
	</div>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Edit Profil
		</h2>
	</div>
	<?php
	$mincat_pesan_err = array( 'name' => 'Nama minimal 3 huruf.', 'email' => 'Format email belum benar, atau email sudah dipakai akun lain.', 'phone' => 'Isi nomor telepon yang valid, contoh 081234567890.', 'foto' => 'Foto harus JPG, PNG, atau WEBP, maksimal 8 MB. Foto akan diperkecil otomatis.', 'gagal' => 'Perubahan gagal disimpan. Coba lagi.' );
	if ( $mincat_err ) : ?>
	<p class="err">
		<?php echo esc_html( isset( $mincat_pesan_err[ $mincat_err ] ) ? $mincat_pesan_err[ $mincat_err ] : $mincat_err ); ?>
	</p>
	<?php endif;
	if ( isset( $_GET['ok'] ) ) : ?>
	<p class="sub" style="color:#0C7A4B">
		Perubahan tersimpan.
	</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
		<input type="hidden" name="action" value="mincat_update_profil">
		<?php wp_nonce_field( 'mincat_update_profil', 'mincat_nonce' ); ?>
		<div class="field">
			<label for="an">Nama lengkap</label><input id="an" name="name" value="<?php echo esc_attr( $mincat_user->display_name ); ?>">
		</div>
		<div class="field">
			<label for="au">Username</label><input id="au" value="<?php echo esc_attr( $mincat_user->user_login ); ?>" readonly>
			<p class="tiny muted">
				Username tidak bisa diubah.
			</p>
		</div>
		<div class="field">
			<label for="ae">Email</label><input id="ae" name="email" type="email" value="<?php echo esc_attr( $mincat_user->user_email ); ?>">
		</div>
		<div class="field">
			<label for="ap">Nomor telepon (WhatsApp)</label><input id="ap" name="phone" type="tel" inputmode="tel" placeholder="contoh: 081234567890" value="<?php echo esc_attr( $mincat_phone ? mincat_phone_display( $mincat_phone ) : '' ); ?>" required>
			<p class="tiny muted">
				Hanya kamu dan admin yang bisa melihat. Perusahaan menerimanya hanya kalau kamu setuju.
			</p>
		</div>
				<button class="btn sm" type="submit">Simpan perubahan</button>
	</form>
</div>
<div class="mob-spacer" aria-hidden="true"></div>
