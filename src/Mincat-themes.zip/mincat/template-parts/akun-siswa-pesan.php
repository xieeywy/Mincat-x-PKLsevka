<?php
/**
 * Tab Pesan di dashboard siswa (revisi: dipindah dari halaman Pesan). Dipanggil dari akun-siswa-center.
 * @package mincat
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_mine = mincat_pesan();
?>
<div class="sec-head">
	<h2>
		Pesan dari perusahaan
	</h2>
</div>
<p class="tiny muted">
	Pesan masuk lewat MINCAT. Kontakmu hanya dibagikan kalau kamu setuju.
</p>
<?php if ( $mincat_mine ) { foreach ( $mincat_mine as $p ) { ?>
		<div class="panel" style="margin-bottom:10px">
			<div class="ak-card-head">
				<b><?php echo esc_html( $p['dari'] ); ?></b><?php echo mincat_status( 'menunggu' === $p['status'] ? 'Menunggu' : ( 'kontak' === $p['status'] ? 'Kontak dibagikan' : 'Ditolak' ), 'kontak' === $p['status'] ? 'verified' : ( 'ditolak' === $p['status'] ? 'revision' : 'review' ) ); ?>
			</div>
			<p class="tiny muted">
				Lamaran: <?php echo esc_html( $p['lamaran'] ); ?> · <?php echo esc_html( $p['t'] ); ?>
			</p>
			<p>
				<?php echo esc_html( $p['isi'] ); ?>
			</p>
			<?php if ( 'menunggu' === $p['status'] ) { ?>
				<div class="app-acts">
					<button class="btn primary small" data-mincat-action="bagikan-kontak" data-id="<?php echo (int) $p['id']; ?>">Bagikan kontakku</button><button class="btn secondary small" data-mincat-action="tolak-pesan" data-id="<?php echo (int) $p['id']; ?>">Tolak</button>
				</div>
			<?php } ?>
		</div>
	<?php } } else { echo mincat_empty_box( 'Belum ada pesan.', 'Pesan dari perusahaan yang tertarik akan muncul di sini.' ); } ?>
