<?php
/**
 * Kolom tengah dashboard siswa (?tab=...).
 * Beranda (dashboard): tambah portofolio, daftar karya, dan rekomendasi PKL saja (revisi).
 * Tab lain: karya, lamaran, profil, pesan.
 *
 * @package mincat
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_tab   = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
$mincat_uid   = get_current_user_id();
$mincat_user  = wp_get_current_user();
$mincat_photo = (string) get_user_meta( $mincat_uid, 'mincat_photo', true );
$mincat_init  = mincat_initials( $mincat_user->display_name );
$mincat_lamar = mincat_apps();
$mincat_rekom = array_slice( mincat_jobs(), 0, 3 );

$mincat_pill = function ( $k ) {
	$m = array(
		'verified' => 'Terverifikasi', 'review' => 'Menunggu review', 'revision' => 'Perlu revisi', 'draft' => 'Draft',
		'Menunggu Tinjauan' => 'Menunggu tinjauan', 'Ditinjau' => 'Ditinjau', 'Diterima' => 'Diterima', 'Ditolak' => 'Ditolak',
	);
	return isset( $m[ $k ] ) ? $m[ $k ] : $k;
};
$mincat_page = function ( $key ) {
	return esc_url( mincat_url( $key ) );
};
$mincat_err = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
?>
<?php if ( 'karya' === $mincat_tab ) : ?>
<div class="card section">
	<?php get_template_part( 'template-parts/akun-siswa', 'portofolio' ); ?>
</div>

<?php elseif ( 'lamaran' === $mincat_tab ) : ?>
<div class="card section">
	<div class="sec-head">
		<h2>
			Lamaran saya
		</h2>
		<a href="<?php echo $mincat_page( 'opportunities' ); ?>">Cari peluang</a>
	</div>
	<?php if ( $mincat_lamar ) : foreach ( $mincat_lamar as $l ) : ?>
	<div class="nxd-hist__r">
		<div>
			<strong><?php echo esc_html( $l[0] ); ?></strong><small><?php echo esc_html( $l[1] ); ?></small>
		</div>
		<span class="nxd-lb"><?php echo esc_html( $mincat_pill( $l[2] ) ); ?></span>
	</div>
	<?php endforeach; else : ?>
	<div class="nxd-empty">
		<strong>Belum ada lamaran</strong><small>Cari peluang PKL lalu ajukan lamaranmu.</small>
	</div>
	<?php endif; ?>
</div>

<?php elseif ( 'profil' === $mincat_tab ) : ?>
<?php
$mincat_phone = (string) get_user_meta( $mincat_uid, 'mincat_phone', true );
$mincat_miss  = array();
if ( '' === $mincat_user->user_email ) {
	$mincat_miss[] = 'email';
}
if ( '' === $mincat_phone ) {
	$mincat_miss[] = 'nomor telepon';
}
if ( $mincat_miss ) : ?>
<div class="card section" style="border-left:4px solid #d97706">
	<b>Lengkapi akun kamu</b>
	<p class="tiny muted" style="margin:6px 0 0">
		Isi <?php echo esc_html( implode( ' dan ', $mincat_miss ) ); ?> dulu. Nomor hanya dibagikan ke perusahaan kalau kamu setuju.
	</p>
</div>
<?php endif; ?>
<div class="card section">
	<div class="sec-head">
		<h2>
			Info Profil
		</h2>
	</div>
	<dl class="nxd-dl">
		<div>
			<dt>
				Nama lengkap
			</dt>
			<dd>
				<?php echo esc_html( $mincat_user->display_name ); ?>
			</dd>
		</div>
		<div>
			<dt>
				Username
			</dt>
			<dd>
				@<?php echo esc_html( $mincat_user->user_login ); ?>
			</dd>
		</div>
		<div>
			<dt>
				Email
			</dt>
			<dd>
				<?php echo esc_html( $mincat_user->user_email ); ?>
			</dd>
		</div>
		<div>
			<dt>
				Nomor telepon
			</dt>
			<dd>
				<?php echo $mincat_phone ? esc_html( mincat_phone_display( $mincat_phone ) ) : 'Belum diisi'; ?>
			</dd>
		</div>
		<div>
			<dt>Alamat rumah</dt>
			<dd><?php $mc_al = (string) get_user_meta( get_current_user_id(), 'mincat_alamat', true ); echo '' !== $mc_al ? esc_html( $mc_al ) : 'Belum diisi'; ?></dd>
		</div>
		<div>
			<dt>
				Peran
			</dt>
			<dd>
				<?php echo esc_html( mincat_role_label()[ mincat_role() ] ?? mincat_role() ); ?>
			</dd>
		</div>
	</dl>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Foto Profil
		</h2>
	</div>
	<div class="ak-photo">
		<div class="ak-photo-img">
			<?php if ( $mincat_photo ) : ?><img src="<?php echo esc_url( $mincat_photo ); ?>" alt="Foto profil"><?php else : ?><span><?php echo esc_html( $mincat_init ); ?></span><?php endif; ?>
		</div>
		<div>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
				<input type="hidden" name="action" value="mincat_upload_photo">
				<?php wp_nonce_field( 'mincat_upload_photo' ); ?>
				<input type="file" name="foto" accept="image/jpeg,image/png,image/webp" required style="display:block;margin:0 0 8px;width:100%">
				<p class="sub" style="margin:0 0 8px">
					JPG, PNG, atau WEBP, maksimal 8 MB. Foto akan diperkecil otomatis.
				</p>
				<button class="btn primary small" type="submit">Simpan foto</button>
			</form>
		</div>
	</div>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Data saya
		</h2>
	</div>
	<p class="tiny muted">
		Kamu berhak melihat, mengunduh, dan menghapus data akunmu. Penghapusan juga mencabut tautan bagikan yang aktif.
	</p>
	<div class="app-acts">
		<button class="btn secondary small" data-mincat-action="download-my-data">Unduh data saya (JSON)</button><button class="btn danger small" data-mincat-action="confirm-delete">Hapus akun dan data</button>
	</div>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Edit Profil
		</h2>
	</div>
	<?php
	$mincat_pesan_err = array( 'name' => 'Nama minimal 3 huruf.', 'email' => 'Format email belum benar, atau email sudah dipakai akun lain.', 'phone' => 'Isi nomor telepon yang valid, contoh 081234567890.', 'foto' => 'Foto harus JPG, PNG, atau WEBP, maksimal 8 MB. Foto akan diperkecil otomatis.', 'gagal' => 'Perubahan gagal disimpan. Coba lagi.' );
	if ( $mincat_err ) : ?>
	<p class="err">
		<?php echo esc_html( isset( $mincat_pesan_err[ $mincat_err ] ) ? $mincat_pesan_err[ $mincat_err ] : $mincat_err ); ?>
	</p>
	<?php endif;
	if ( isset( $_GET['ok'] ) ) : ?>
	<p class="sub" style="color:#0C7A4B">
		Perubahan tersimpan.
	</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
		<input type="hidden" name="action" value="mincat_update_profil">
		<?php wp_nonce_field( 'mincat_update_profil', 'mincat_nonce' ); ?>
		<div class="field">
			<label for="an">Nama lengkap</label><input id="an" name="name" value="<?php echo esc_attr( $mincat_user->display_name ); ?>">
		</div>
		<div class="field">
			<label for="au">Username</label><input id="au" value="<?php echo esc_attr( $mincat_user->user_login ); ?>" readonly>
			<p class="tiny muted">
				Username tidak bisa diubah.
			</p>
		</div>
		<div class="field">
			<label for="ae">Email</label><input id="ae" name="email" type="email" value="<?php echo esc_attr( $mincat_user->user_email ); ?>">
		</div>
		<div class="field">
			<label for="ap">Nomor telepon (WhatsApp)</label><input id="ap" name="phone" type="tel" inputmode="tel" placeholder="contoh: 081234567890" value="<?php echo esc_attr( $mincat_phone ? mincat_phone_display( $mincat_phone ) : '' ); ?>" required>
			<p class="tiny muted">
				Hanya kamu dan admin yang bisa melihat. Perusahaan menerimanya hanya kalau kamu setuju.
			</p>
		</div>
		<div class="field"><label for="aa">Alamat rumah (opsional)</label><textarea id="aa" name="alamat" rows="2" placeholder="Jalan, desa, kecamatan" style="width:100%"><?php echo esc_textarea( (string) get_user_meta( get_current_user_id(), 'mincat_alamat', true ) ); ?></textarea><input type="hidden" name="lat" value=""><input type="hidden" name="lng" value=""><p class="tiny muted">Dipakai untuk melihat rute dari rumah ke tempat PKL. Hanya guru, mentor, perusahaan, dan admin yang bisa melihat alamat lengkapmu. Wali dan siswa lain tidak bisa melihatnya. Opsional.</p><button type="button" class="btn secondary small" onclick="mcGeo(this)">Ambil lokasi saat ini</button></div>
		<button class="btn sm" type="submit">Simpan perubahan</button>
	</form>
</div>

<?php elseif ( 'pesan' === $mincat_tab ) : ?>
<div class="card section">
	<?php get_template_part( 'template-parts/akun-siswa', 'pesan' ); ?>
</div>

<?php else : ?>
<?php
$mincat_own    = mincat_projects();
$mincat_nkarya = count( $mincat_own );
$mincat_nverif = count( array_filter( $mincat_own, function ( $p ) { return 'verified' === $p['k']; } ) );
$mincat_nlamar = count( $mincat_lamar );
$mincat_tab_url = function ( $t ) {
	return esc_url( add_query_arg( 'tab', $t, mincat_url( 'akun' ) ) );
};
if ( 0 === $mincat_nkarya ) {
	$mincat_next = array( 'Buat karya pertamamu', 'Tambahkan karya ke portofolio, lalu kirim untuk direview.', $mincat_tab_url( 'karya' ) );
} elseif ( 0 === $mincat_nverif ) {
	$mincat_next = array( 'Minta review guru', 'Kirim karya yang sudah lengkap agar guru bisa memberi masukan.', $mincat_tab_url( 'karya' ) );
} elseif ( 0 === $mincat_nlamar ) {
	$mincat_next = array( 'Temukan peluang PKL', 'Lihat lowongan yang sesuai bidang dan tenggatnya.', mincat_url( 'opportunities' ) );
} else {
	$mincat_next = array( 'Semua tahap selesai', 'Pantau status lamaranmu di tab Lamaran.', $mincat_tab_url( 'lamaran' ) );
}
$mincat_stats = array(
	array( 'Karya saya', $mincat_nkarya, 'Lihat karya', $mincat_tab_url( 'karya' ) ),
	array( 'Terverifikasi', $mincat_nverif, 'Sudah ditinjau guru', $mincat_tab_url( 'karya' ) ),
	array( 'Lamaran sesi ini', $mincat_nlamar, 'Lihat lamaran', $mincat_tab_url( 'lamaran' ) ),
);
?>
<div class="card section" style="background:#f5f7fc">
	<p class="tiny muted" style="margin:0">
		Halo, <?php echo esc_html( mincat_first_name() ); ?>
	</p>
	<h2 style="margin:6px 0">
		<?php echo esc_html( $mincat_next[0] ); ?>
	</h2>
	<p class="sub" style="margin:0 0 12px">
		<?php echo esc_html( $mincat_next[1] ); ?>
	</p>
	<a class="btn primary small" href="<?php echo esc_url( $mincat_next[2] ); ?>">Lanjutkan</a>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px">
	<?php foreach ( $mincat_stats as $st ) : ?>
	<div class="card section" style="margin:0">
		<p class="tiny muted" style="margin:0;text-transform:uppercase;letter-spacing:.06em">
			<?php echo esc_html( $st[0] ); ?>
		</p>
		<strong style="font-size:28px;display:block;margin:4px 0"><?php echo (int) $st[1]; ?></strong>
		<a class="link" href="<?php echo esc_url( $st[3] ); ?>"><?php echo esc_html( $st[2] ); ?> &rsaquo;</a>
	</div>
	<?php endforeach; ?>
</div>
<div class="card section">
	<div class="sec-head">
		<h2>
			Rekomendasi PKL
		</h2>
		<a href="<?php echo $mincat_page( 'opportunities' ); ?>">Lihat semua</a>
	</div>
	<?php if ( $mincat_rekom ) : foreach ( $mincat_rekom as $j ) : ?>
	<div class="nxd-hist__r">
		<div>
			<strong><?php echo esc_html( $j[0] ); ?></strong><small><?php echo esc_html( $j[1] . ' · ' . $j[2] ); ?></small>
		</div>
		<a class="btn secondary small" href="<?php echo esc_url( add_query_arg( 'job', (int) $j['id'], mincat_url( 'jobdetail' ) ) ); ?>">Lihat</a>
	</div>
	<?php endforeach; else : ?>
	<div class="nxd-empty">
		<strong>Belum ada lowongan</strong><small>Lowongan PKL yang tersedia akan muncul di sini.</small>
	</div>
	<?php endif; ?>
</div>
<?php endif; ?>
<div class="mob-spacer" aria-hidden="true"></div>
