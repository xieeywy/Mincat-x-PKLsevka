<?php
/**
 * Sidebar dashboard untuk guru, mentor, dan perusahaan (gaya sama dengan siswa).
 * Menu hanya berisi fitur milik peran itu.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_role  = mincat_role();
$mc_user  = wp_get_current_user();
$mc_photo = (string) get_user_meta( $mc_user->ID, 'mincat_photo', true );
$mc_init  = mincat_initials( $mc_user->display_name );
$mc_label = mincat_role_label()[ $mc_role ] ?? $mc_role;
$mc_icon  = array(
	'dashboard' => '<span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg></span>',
	'karya' => '<span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg></span>',
	'lamaran' => '<span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M7 3h10v18l-5-3-5 3z"/></svg></span>',
	'pesan' => '<span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></span>',
	'profil' => '<span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>',
);
$mc_tab   = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
$mc_menu  = array(
	array( 'tab' => 'dashboard', 'label' => 'Dashboard', 'url' => mincat_url( 'akun' ), 'icon' => 'dashboard' ),
	array( 'tab' => 'profil', 'label' => 'Profil', 'url' => add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) ), 'icon' => 'profil' ),
);
foreach ( mincat_role_menu_links() as $mc_m ) {
	if ( 'settings' === $mc_m[0] ) {
		continue;
	}
	$mc_ic = 'profil';
	if ( 'review' === $mc_m[0] ) { $mc_ic = 'karya'; }
	if ( 'company' === $mc_m[0] ) { $mc_ic = 'lamaran'; }
	if ( 'pesan' === $mc_m[0] ) { $mc_ic = 'pesan'; }
	$mc_menu[] = array( 'tab' => $mc_m[0], 'label' => $mc_m[1], 'url' => mincat_url( $mc_m[0] ), 'icon' => $mc_ic );
}
?>
<aside class="card side">
	<div class="card who">
		<div class="who-top">
			<div class="who-avatar">
				<?php if ( $mc_photo ) : ?><img src="<?php echo esc_url( $mc_photo ); ?>" alt=""><?php else : ?><span class="ava"><?php echo esc_html( $mc_init ); ?></span><?php endif; ?>
			</div>
			<div>
				<strong><?php echo esc_html( $mc_user->display_name ); ?></strong><small>@<?php echo esc_html( $mc_user->user_login ); ?> · <?php echo esc_html( $mc_label ); ?></small>
			</div>
		</div>
	</div>
	<nav class="nav">
	<?php foreach ( $mc_menu as $mc_it ) : ?>
		<a href="<?php echo esc_url( $mc_it['url'] ); ?>" data-tab="<?php echo esc_attr( $mc_it['tab'] ); ?>" class="<?php echo $mc_it['tab'] === $mc_tab ? 'on' : ''; ?>"><?php echo $mc_icon[ $mc_it['icon'] ]; ?><?php echo esc_html( $mc_it['label'] ); ?></a>
	<?php endforeach; ?>
		<a href="<?php echo esc_url( wp_logout_url( mincat_url( 'home' ) ) ); ?>" data-logout="1"><span class="i"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.9"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg></span>Keluar</a>
	</nav>
<div class="help">
						<div class="ph">
							<svg viewBox="0 0 150 150"><circle cx="75" cy="60" r="34" fill="#B3CDE0"/><rect x="40" y="96" width="70" height="40" rx="18" fill="#2B5C92"/><circle cx="62" cy="58" r="5" fill="#0C1446"/><circle cx="88" cy="58" r="5" fill="#0C1446"/></svg>
						</div>
						<strong>Butuh bantuan?</strong>
						<p class="sub">
							Tim MINCAT siap membantu kamu kapan saja.
						</p>
						<a class="btn sm" href="<?php echo esc_url( mincat_url( 'home' ) ); ?>" data-page="home">Hubungi kami</a>
					</div>
</aside>
