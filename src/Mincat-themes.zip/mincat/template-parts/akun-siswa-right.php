<?php
/** Kolom kanan dashboard siswa: kartu profil saja (kalender dan pengingat dihapus pada revisi). */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_uid   = get_current_user_id();
$mincat_user  = wp_get_current_user();
$mincat_photo = (string) get_user_meta( $mincat_uid, 'mincat_photo', true );
$mincat_jur   = (string) get_user_meta( $mincat_uid, 'mincat_jurusan', true );
$mincat_init  = mincat_initials( $mincat_user->display_name );
?>
<div class="card who">
	<div class="who-top">
		<div class="who-avatar">
			<?php if ( $mincat_photo ) : ?><img src="<?php echo esc_url( $mincat_photo ); ?>" alt=""><?php else : ?><span class="ava"><?php echo esc_html( $mincat_init ); ?></span><?php endif; ?>
		</div>
		<div>
			<strong><?php echo esc_html( $mincat_user->display_name ); ?></strong><small>@<?php echo esc_html( $mincat_user->user_login ); ?> · Siswa SMK<?php echo $mincat_jur ? ' · ' . esc_html( $mincat_jur ) : ''; ?></small>
		</div>
	</div>
</div>
