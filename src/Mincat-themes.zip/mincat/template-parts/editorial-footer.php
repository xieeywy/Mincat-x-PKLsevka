<?php
/**
 * Footer MINCAT (gelap): merek, tiga kolom tautan, dan baris bawah.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<footer class="editorial-footer mf">
	<div class="mf-brand">
		<a class="brand" href="<?php echo esc_url( mincat_url( 'home' ) ); ?>"><img class="mf-logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mincat-logo.webp" alt="MINCAT" width="140" height="37"></a>
		<p>Platform PKL untuk siswa SMK. Small Steps, Big Future.</p>
		<p class="mf-sub">MINCAT x PKLsevka</p>
	</div>
	<div class="mf-grid">
		<div>
			<h4>Jelajahi</h4>
			<a href="<?php echo esc_url( mincat_url( 'home' ) ); ?>">Beranda</a>
			<a href="<?php echo esc_url( mincat_url( 'opportunities' ) ); ?>">Peluang PKL</a>
			<a href="<?php echo esc_url( mincat_url( 'portfolio' ) ); ?>">Portofolio</a>
			<a href="<?php echo esc_url( mincat_url( 'about' ) ); ?>">Tentang MINCAT</a>
		</div>
		<div>
			<h4>Bantuan</h4>
			<a href="https://wa.me/6282226086154" target="_blank" rel="noopener">WhatsApp Admin</a>
			<a href="https://smkn7kendal.sch.id" target="_blank" rel="noopener">SMKN 7 Kendal</a>
		</div>
		<div>
			<h4>Legal</h4>
			<a href="<?php echo esc_url( mincat_url( 'kebijakan-privasi' ) ); ?>">Kebijakan Privasi</a>
			<a href="<?php echo esc_url( mincat_url( 'syarat-layanan' ) ); ?>">Syarat Layanan</a>
		</div>
	</div>
	<div class="mf-bottom">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> MINCAT</span>
		<span>Dikembangkan untuk SMKN 7 Kendal</span>
	</div>
</footer>
