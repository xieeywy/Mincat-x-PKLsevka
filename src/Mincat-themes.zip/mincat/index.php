<?php
/**
 * Fallback wajib tema WordPress. Semua halaman MINCAT memakai template sendiri
 * (front-page.php dan page-*.php); file ini hanya meneruskan ke beranda.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require get_template_directory() . '/front-page.php';
