<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_dash = (bool) get_query_var( 'mincat_dash', false );
if ( mincat_is_page( 'home' ) ) {
	get_template_part( 'template-parts/editorial-footer' );
}
?>
</main>
<nav class="mobile" id="mnav" aria-label="Navigasi utama">
<?php echo mincat_mobile_nav_html(); ?>
</nav>
<div id="notifPanel" class="notif-panel" hidden>
</div>
<div id="modal">
</div>
<div id="printArea">
</div>
<button type="button" class="mc-fab" onclick="mincyToggle(event)" aria-label="Buka Mincy, teman panduan MINCAT"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></button>
<div id="mincyPanel" class="mc-panel" role="dialog" aria-label="Mincy, teman panduan MINCAT">
  <div class="mc-head"><span class="mc-mark"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mincy.webp" alt="Mincy" width="40" height="40"></span><div><b>Mincy</b><small>Teman panduan MINCAT</small></div><button type="button" class="mc-x" onclick="mincyToggle()" aria-label="Tutup">&times;</button></div>
  <div class="mc-body">
    <p class="mc-q">Panduan MINCAT</p>
    <div class="mc-list">
      <a class="mc-card" href="<?php echo esc_url( mincat_url( 'about' ) ); ?>"><b>Tentang MINCAT</b><small>Apa itu MINCAT, visi, misi, dan tim</small></a>
      <?php foreach ( mincat_panduan_topics() as $mc_k => $mc_t ) : ?>
        <a class="mc-card" href="<?php echo esc_url( mincat_url( 'panduan-' . $mc_k ) ); ?>"><b><?php echo esc_html( $mc_t['judul'] ); ?></b><small><?php echo esc_html( $mc_t['pengantar'] ); ?></small></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="mc-foot"><a class="mc-wa" href="https://wa.me/6282226086154" target="_blank" rel="noopener">Chat WhatsApp Admin &rarr;</a></div>
</div>
<div id="toast" class="toast">
</div>
<div id="akunHost"<?php echo $mincat_dash ? ' class="page-in"' : ' hidden'; ?>>
<?php
if ( $mincat_dash ) {
	get_template_part( 'template-parts/akun-dashboard' );
}
?>
</div>
<?php wp_footer(); ?>

</body>
</html>
