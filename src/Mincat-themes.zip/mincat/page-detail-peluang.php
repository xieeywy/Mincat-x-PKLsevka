<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'jobdetail' );
$mincat_all = mincat_jobs();
$mincat_id  = isset( $_GET['job'] ) ? absint( $_GET['job'] ) : 0;
$j          = $mincat_all ? $mincat_all[0] : null;
foreach ( $mincat_all as $mincat_cand ) {
	if ( (int) $mincat_cand['id'] === $mincat_id ) {
		$j = $mincat_cand;
		break;
	}
}
if ( ! $j ) {
	wp_safe_redirect( mincat_url( 'opportunities' ) );
	exit;
}
$mincat_saved   = in_array( $j[0], mincat_saved(), true );
$mincat_applied = false;
foreach ( mincat_apps() as $mincat_a ) {
	if ( $mincat_a[0] === $j[0] ) {
		$mincat_applied = true;
	}
}
$m = mincat_match_job( $j );
set_query_var( 'mincat_page', 'jobdetail' );
get_header();
get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Detail Peluang', 'Baca informasi dan persyaratan sebelum mengajukan lamaran.', '<a class="btn secondary small" href="' . esc_url( mincat_url( 'opportunities' ) ) . '" data-page="opportunities">← Kembali</a>' ); ?>

<div class="detailgrid">
	<div>
		<div class="detailhero">
			<span class="pill">Peluang PKL</span>
			<h2>
				<?php echo esc_html( $j[0] ); ?>
			</h2>
			<p>
				<?php echo esc_html( $j[1] ); ?> · <?php echo esc_html( $j[2] ); ?>
			</p>
			<div class="meta">
				<span><?php echo mincat_ic( 'clock' ); ?> <?php echo esc_html( $j[4] ); ?></span><span><?php echo mincat_ic( 'wallet' ); ?> <?php echo esc_html( $j[5] ); ?></span><span><?php echo mincat_ic( 'clock' ); ?> <?php echo esc_html( $j[6] ); ?></span>
			</div>
		</div>
		<div class="panel" style="margin-top:12px">
			<div class="content">
				<h3>
					Deskripsi
				</h3>
				<p>
					Kesempatan untuk belajar bersama tim, mengembangkan keterampilan, dan berkontribusi pada proyek nyata sesuai bidang yang dipelajari.
				</p>
			</div>
			<div class="content">
				<h3>
					Kualifikasi
				</h3>
				<ul>
					<li>
						Siswa aktif sesuai persyaratan program.
					</li>
					<li>
						Memiliki minat pada bidang <?php echo esc_html( $j[3] ); ?>.
					</li>
					<li>
						Bersedia belajar, berkolaborasi, dan menerima feedback.
					</li>
					<li>
						Melampirkan portofolio relevan jika tersedia.
					</li>
				</ul>
			</div>
			<div class="content" style="border:0">
				<h3>
					Proses seleksi
				</h3>
				<p>
					Pengajuan lamaran → peninjauan portofolio → informasi lanjutan dari perusahaan.
				</p>
			</div>
		</div>
	</div>
	<aside class="sidebox">
		<h3>
			Ringkasan peluang
		</h3>
		<div class="line">
			<span>Bidang</span><b><?php echo esc_html( $j[3] ); ?></b>
		</div>
		<div class="line">
			<span>Lokasi</span><b><?php echo esc_html( $j[2] ); ?></b>
		</div>
		<div class="line">
			<span>Durasi</span><b><?php echo esc_html( $j[4] ); ?></b>
		</div>
		<div class="line">
			<span>Uang saku</span><b><?php echo esc_html( $j[5] ); ?></b>
		</div>
		<div class="line">
			<span>Tenggat</span><b><?php echo esc_html( $j[6] ); ?></b>
		</div>
		<div class="match-box">
			<b>Kecocokan dengan karyamu: <?php echo (int) $m['pct']; ?>%</b><?php echo mincat_match_reasons( $m ); ?>
		</div>
		<?php if ( ! mincat_logged_in() ) { ?><a class="btn primary" href="<?php echo esc_url( mincat_url( 'masuk' ) ); ?>">Masuk untuk melamar</a><?php } elseif ( 'siswa' !== mincat_role() ) { ?><?php } elseif ( $mincat_applied ) { ?><button class="btn secondary" disabled>Sudah dilamar</button><?php } else { ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="mincat_apply"><input type="hidden" name="job" value="<?php echo (int) $j['id']; ?>"><?php wp_nonce_field( 'mincat_apply_' . (int) $j['id'], '_wpnonce', false ); ?><button class="btn primary" type="submit">Lamar sekarang <?php echo mincat_ic( 'arrow' ); ?></button>
			</form>
		<?php } ?>

		<button class="btn secondary" data-mincat-action="toggle-save" data-job="<?php echo (int) $j['id']; ?>"><?php echo mincat_ic( 'heart' ); ?> <?php echo $mincat_saved ? 'Tersimpan' : 'Simpan peluang'; ?></button>
		<p class="tiny muted">
			Pengajuan tidak dikirim ke perusahaan sungguhan. Penyimpanan hanya berlaku selama sesi ini.
		</p>
	</aside>
</div>
<?php get_template_part( 'template-parts/shell', 'close' ); get_footer();
