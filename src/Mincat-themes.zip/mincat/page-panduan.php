<?php
/**
 * Halaman Panduan: daftar 7 panduan. Setiap panduan punya halaman sendiri.
 * Tautan lama ?topik=kunci dialihkan ke halaman panduan yang sesuai.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_topics = mincat_panduan_topics();
$mincat_old    = isset( $_GET['topik'] ) ? sanitize_key( wp_unslash( $_GET['topik'] ) ) : '';
if ( $mincat_old && isset( $mincat_topics[ $mincat_old ] ) ) {
	wp_safe_redirect( mincat_url( 'panduan-' . $mincat_old ) );
	exit;
}

set_query_var( 'mincat_page', 'panduan' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
echo mincat_title( 'Panduan', 'Pilih panduan yang ingin kamu pelajari.' );
?>
<div class="panel" style="margin-top:12px">
	<?php foreach ( $mincat_topics as $mincat_k => $mincat_row ) : ?>
		<p style="margin:0 0 6px"><a class="link" href="<?php echo esc_url( mincat_url( 'panduan-' . $mincat_k ) ); ?>"><?php echo esc_html( $mincat_row['judul'] ); ?></a></p>
		<p class="tiny muted" style="margin:0 0 14px"><?php echo esc_html( $mincat_row['pengantar'] ); ?></p>
	<?php endforeach; ?>
</div>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
