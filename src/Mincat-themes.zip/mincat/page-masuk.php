<?php

if ( is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}

$mincat_google = mincat_google_login_url();

get_header();
?>
<section class="auth-stage">
	<div class="auth-dark">
		<a class="auth-close" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Tutup">&times;</a>
		<div class="auth-logo">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/mincat-logo.webp' ); ?>" alt="MINCAT" width="150" height="40">
		</div>
		<h1 class="auth-title">
			Masuk
		</h1>
		<p class="auth-sub">
			Akun baru otomatis berstatus Visitor sampai diverifikasi.
		</p>

		<?php if ( $mincat_google ) : ?>
		<a class="auth-google" href="<?php echo esc_url( $mincat_google ); ?>"><span class="auth-g">G</span> Lanjut dengan Google</a>
		<div class="auth-or">
			<span>atau</span>
		</div>
		<?php endif; ?>
		<p class="auth-sub">
			Belum punya akun? Cukup masuk dengan Google, akun dibuat otomatis.
		</p>

		<form class="auth-form" method="post" action="<?php echo esc_url( wp_login_url() ); ?>" novalidate>
			<label for="auth-log">Email atau username</label>
			<input id="auth-log" name="log" type="text" autocomplete="username" required>

			<label for="auth-pwd">Password</label>
			<input id="auth-pwd" name="pwd" type="password" autocomplete="current-password" required>

			<input type="hidden" name="redirect_to" value="<?php echo esc_url( mincat_url( 'akun' ) ); ?>">
			<input type="hidden" name="rememberme" value="forever">
			<button class="auth-submit" type="submit" name="wp-submit">Masuk</button>
		</form>

		<p class="auth-links">
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Lupa password?</a>
			<span aria-hidden="true">·</span>
			<a href="<?php echo esc_url( mincat_url( 'about' ) ); ?>">Tidak bisa masuk?</a>
		</p>
	</div>
</section>
<?php get_footer(); ?>
