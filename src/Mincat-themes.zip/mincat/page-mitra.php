<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'mitra' );
$mincat_jobs  = mincat_approved_jobs();
$mincat_mitra = mincat_mitra();
set_query_var( 'mincat_page', 'mitra' );
get_header();
get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Mitra dan lowongan', 'Lihat perusahaan mitra sekolah dan lowongan PKL yang sudah disetujui admin.' ); ?>

<div class="panel" style="margin-bottom:14px">
	<b>Perusahaan yang ingin melihat portofolio siswa?</b>
	<p class="tiny muted">
		Perusahaan bisa minta akses lewat akun. Admin sekolah memeriksa dulu sebelum data siswa dibuka.
	</p>
	<a class="btn primary small" href="<?php echo esc_url( mincat_url( 'akun' ) ); ?>">Minta akses sebagai perusahaan</a>
</div>
<div class="sec-head" style="margin:0 0 8px">
	<b>Mitra sekolah</b>
</div>
<div class="showcase">
	<?php foreach ( $mincat_mitra as $m ) { ?>
		<article class="showcase-card">
			<div class="showcase-head">
				<span class="avatar"><?php echo esc_html( mincat_initials( $m['nama'] ) ); ?></span>
				<div>
					<b><?php echo esc_html( $m['nama'] ); ?></b><small><?php echo esc_html( $m['kota'] ); ?> · <?php echo esc_html( $m['bidang'] ); ?></small>
				</div>
			</div>
			<div style="margin-top:12px">
				<?php echo mincat_status( 'Terverifikasi sekolah', 'verified' ); ?>
			</div>
		</article>
	<?php } ?>
</div>
<div class="sec-head" style="margin:20px 0 8px">
	<b>Lowongan PKL aktif</b>
</div>
<?php if ( $mincat_jobs ) { ?>
	<div class="rows">
		<?php foreach ( $mincat_jobs as $j ) { ?>
			<div class="panel row">
				<div class="main">
					<b><?php echo esc_html( $j[0] ); ?></b>
					<p class="tiny muted">
						<?php echo esc_html( $j[1] ); ?> · <?php echo esc_html( $j[2] ); ?> · <?php echo esc_html( $j[3] ); ?> · batas <?php echo esc_html( $j[6] ); ?>
					</p>
				</div>
			</div>
		<?php } ?>
	</div>
<?php } else { echo mincat_empty_box( 'Belum ada lowongan aktif.', 'Lowongan yang disetujui admin akan tampil di sini.' ); } ?>

<p class="data-note">
	Data siswa tidak ditampilkan di halaman ini. Untuk melamar, minta akses dulu lewat akunmu.
</p>
<?php get_template_part( 'template-parts/shell', 'close' ); get_footer();
