<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}
$mincat_role = mincat_role();
if ( 'perusahaan' !== $mincat_role ) {
	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}

$mincat_tab   = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
$mincat_err   = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
$mincat_jobs  = mincat_my_jobs();
$mincat_jobid = wp_list_pluck( $mincat_jobs, 'ID' );
$mincat_apps  = mincat_lamaran_list( $mincat_jobid );
$mincat_st    = mincat_status_labels();
$mincat_diterima = count( array_filter( $mincat_apps, function ( $a ) use ( $mincat_st ) { return $mincat_st['diterima'] === $a['status']; } ) );
$mincat_teruskan = count( array_filter( $mincat_apps, function ( $a ) use ( $mincat_st ) { return $mincat_st['teruskan'] === $a['status']; } ) );

set_query_var( 'mincat_page', 'company' );
get_header();
get_template_part( 'template-parts/shell', 'open' );

echo mincat_title( 'Perusahaan', 'Buat lowongan dan terima atau tolak pelamar yang diteruskan guru pembimbing.' );
?>
<nav class="tabs" style="margin:0 0 16px;display:flex;gap:12px;flex-wrap:wrap">
	<a href="<?php echo esc_url( add_query_arg( 'tab', 'dashboard', mincat_url( 'company' ) ) ); ?>">Dashboard</a>
	<a href="<?php echo esc_url( add_query_arg( 'tab', 'lowongan', mincat_url( 'company' ) ) ); ?>">Lowongan saya</a>
	<a href="<?php echo esc_url( add_query_arg( 'tab', 'pelamar', mincat_url( 'company' ) ) ); ?>">Pelamar</a>
</nav>

<?php if ( 'lowongan' === $mincat_tab ) : ?>
<div class="panel">
	<b>Buat lowongan baru</b>
	<?php if ( $mincat_err ) : ?>
	<p class="err">
		<?php echo esc_html( $mincat_err ); ?>
	</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
		<input type="hidden" name="action" value="mincat_create_job">
		<?php wp_nonce_field( 'mincat_create_job' ); ?>
		<div class="field">
			<label for="jj">Judul lowongan</label><input id="jj" name="judul" placeholder="contoh: Magang Teknisi Jaringan">
		</div>
		<div class="field">
			<label for="jl">Lokasi</label><input id="jl" name="lokasi" placeholder="contoh: Bandung">
		</div>
		<div class="field">
			<label for="jb">Bidang</label>
			<select id="jb" name="bidang"><option value="TKJ">TKJ (Teknik Komputer dan Jaringan)</option><option value="TSM">TSM (Teknik Sepeda Motor)</option><option value="TJAT">TJAT (Teknik Jaringan Akses Telekomunikasi)</option></select>
		</div>
		<div class="field">
			<label for="jk">Kuota siswa</label><input id="jk" name="kuota" type="number" min="1" value="1">
		</div>
		<div class="field">
			<label for="jd">Deskripsi</label>
			<textarea id="jd" name="deskripsi" rows="4"></textarea>
		</div>
		<button class="btn primary small" type="submit">Terbitkan lowongan</button>
	</form>
</div>
<div class="panel" style="margin-top:16px">
	<b>Lowongan aktif</b>
	<?php if ( $mincat_jobs ) : foreach ( $mincat_jobs as $j ) : ?>
	<div class="nxd-hist__r">
		<div>
			<strong><?php echo esc_html( get_the_title( $j ) ); ?></strong><small><?php echo esc_html( (string) get_post_meta( $j->ID, 'lokasi', true ) ); ?></small>
		</div>
		<span class="nxd-lb"><?php echo count( array_filter( $mincat_apps, function ( $a ) use ( $j ) { return (int) $a['job'] === (int) $j->ID; } ) ); ?> pelamar</span>
	</div>
	<?php endforeach; else : ?>
	<p class="sub">
		Belum ada lowongan. Buat lowongan pertamamu di atas.
	</p>
	<?php endif; ?>
</div>

<?php elseif ( 'pelamar' === $mincat_tab ) : ?>
<div class="panel">
	<b>Pelamar</b>
	<p class="tiny muted">
		Hanya lamaran yang sudah diteruskan guru pembimbing yang bisa kamu putuskan.
	</p>
	<?php if ( $mincat_apps ) : foreach ( $mincat_apps as $a ) : ?>
	<div class="nxd-hist__r">
		<div>
			<strong><?php echo esc_html( $a['title'] ); ?></strong><small><?php echo esc_html( $a['student'] ); ?> · <?php echo esc_html( $a['status'] ); ?></small><?php echo mincat_lamaran_alamat_html( isset( $a['id'] ) ? $a['id'] : 0 ); ?>
		</div>
		<?php if ( $mincat_st['teruskan'] === $a['status'] ) : ?>
		<div class="act">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="mincat_lamaran_action"><input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>"><input type="hidden" name="act" value="terima"><?php wp_nonce_field( 'mincat_lamaran_' . $a['id'], '_wpnonce', false ); ?><button class="btn primary small" type="submit">Terima</button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="mincat_lamaran_action"><input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>"><input type="hidden" name="act" value="tolak"><?php wp_nonce_field( 'mincat_lamaran_' . $a['id'], '_wpnonce', false ); ?><button class="btn secondary small" type="submit">Tolak</button>
			</form>
		</div>
		<?php else : ?>
		<span class="nxd-lb"><?php echo esc_html( $a['status'] ); ?></span>
		<?php endif; ?>
	</div>
	<?php endforeach; else : ?>
	<p class="sub">
		Belum ada pelamar.
	</p>
	<?php endif; ?>
</div>

<?php else : ?>
<div class="panel">
	<b>Ringkasan</b>
	<dl class="nxd-dl">
		<div>
			<dt>
				Lowongan aktif
			</dt>
			<dd>
				<?php echo count( $mincat_jobs ); ?>
			</dd>
		</div>
		<div>
			<dt>
				Lamaran masuk
			</dt>
			<dd>
				<?php echo count( $mincat_apps ); ?>
			</dd>
		</div>
		<div>
			<dt>
				Menunggu keputusanmu
			</dt>
			<dd>
				<?php echo (int) $mincat_teruskan; ?>
			</dd>
		</div>
		<div>
			<dt>
				Diterima
			</dt>
			<dd>
				<?php echo (int) $mincat_diterima; ?>
			</dd>
		</div>
	</dl>
</div>
<?php endif; ?>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
