<?php
/**
 * Kebijakan privasi (draf awal). Perlu ditinjau pihak sekolah sebelum dianggap resmi.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
set_query_var( 'mincat_page', 'kebijakan-privasi' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
echo mincat_title( 'Kebijakan privasi', 'Bagaimana MINCAT menyimpan dan memakai data kamu.' );
?>
	<div class="panel" style="margin-bottom:12px"><b>Data yang kami kumpulkan</b>
		<p class="sub" style="margin:8px 0 0">Nama, username, email, dan nomor telepon (WhatsApp) saat kamu membuat akun.</p>
		<p class="sub" style="margin:8px 0 0">Kelas dan jurusan, minat, skill, sertifikat, projek, pengalaman, dan harapan yang kamu isi di portofolio.</p>
		<p class="sub" style="margin:8px 0 0">Foto profil dan foto diri, jika kamu mengunggahnya. Banner karya juga disimpan.</p>
		<p class="sub" style="margin:8px 0 0">Lamaran yang kamu kirim ke lowongan PKL, dan status review dari guru.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Untuk apa data dipakai</b>
		<p class="sub" style="margin:8px 0 0">Membuat akun, memverifikasi peran (siswa, guru, mentor, perusahaan), dan menampilkan portofolio.</p>
		<p class="sub" style="margin:8px 0 0">Meneruskan lamaran ke perusahaan melalui guru pembimbing.</p>
		<p class="sub" style="margin:8px 0 0">Mengirim informasi terkait PKL. Kami tidak menjual data kamu.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Siapa yang bisa melihat</b>
		<p class="sub" style="margin:8px 0 0">Email dan nomor telepon hanya bisa dilihat kamu dan admin.</p>
		<p class="sub" style="margin:8px 0 0">Nomor telepon hanya dibagikan ke perusahaan jika kamu setuju.</p>
		<p class="sub" style="margin:8px 0 0">Karya yang sudah terverifikasi bisa tampil di beranda dengan inisial dan jurusan, tanpa nama lengkap, jika kamu memilihnya.</p>
		<p class="sub" style="margin:8px 0 0">Halaman detail karya hanya bisa dibuka akun siswa, guru, mentor, perusahaan, dan admin yang sudah login.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Hak kamu</b>
		<p class="sub" style="margin:8px 0 0">Melihat dan memperbaiki data di tab Profil.</p>
		<p class="sub" style="margin:8px 0 0">Meminta data kamu diunduh atau dihapus. Hubungi admin lewat WhatsApp.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Pengguna di bawah umur</b>
		<p class="sub" style="margin:8px 0 0">Sebagian besar pengguna adalah siswa. Sebaiknya beri tahu orang tua atau wali tentang data yang kamu isi.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Keamanan dan perubahan</b>
		<p class="sub" style="margin:8px 0 0">Kami berusaha menjaga data dengan baik, tetapi tidak ada sistem yang sepenuhnya aman.</p>
		<p class="sub" style="margin:8px 0 0">Kebijakan ini dapat diperbarui. Perubahan penting akan diumumkan di situs.</p>
	</div>
<p class="tiny muted" style="margin-top:12px">Draf awal. Perlu ditinjau pihak sekolah sebelum dianggap resmi. Pertanyaan: WhatsApp admin 082226086154.</p>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
