<?php
/**
 * Syarat layanan (draf awal). Perlu ditinjau pihak sekolah sebelum dianggap resmi.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
set_query_var( 'mincat_page', 'syarat-layanan' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
echo mincat_title( 'Syarat layanan', 'Aturan penggunaan MINCAT.' );
?>
	<div class="panel" style="margin-bottom:12px"><b>Penggunaan</b>
		<p class="sub" style="margin:8px 0 0">MINCAT dipakai untuk kegiatan PKL siswa SMKN 7 Kendal, bersama guru, mentor, dan perusahaan mitra.</p>
		<p class="sub" style="margin:8px 0 0">Kamu bertanggung jawab atas akun dan data yang kamu isi. Jaga kerahasiaan akunmu.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Karya dan portofolio</b>
		<p class="sub" style="margin:8px 0 0">Karya yang kamu unggah harus milikmu atau kamu punya izin untuk memakainya.</p>
		<p class="sub" style="margin:8px 0 0">Dilarang mengunggah konten yang menyesatkan, menyinggung SARA, atau melanggar hukum.</p>
		<p class="sub" style="margin:8px 0 0">Guru atau admin dapat meminta revisi atau menolak karya yang tidak sesuai.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Lamaran PKL</b>
		<p class="sub" style="margin:8px 0 0">Isi lamaran dengan data yang benar.</p>
		<p class="sub" style="margin:8px 0 0">Perusahaan berhak menerima atau menolak lamaran sesuai kebijakan mereka.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Larangan</b>
		<p class="sub" style="margin:8px 0 0">Mengambil atau menyalahgunakan data pengguna lain, termasuk nomor telepon.</p>
		<p class="sub" style="margin:8px 0 0">Mengirim spam, membuat akun palsu, atau mengganggu pengguna lain.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Penangguhan akun</b>
		<p class="sub" style="margin:8px 0 0">Akun yang melanggar syarat ini dapat ditangguhkan atau dihapus oleh pengelola.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Batas tanggung jawab</b>
		<p class="sub" style="margin:8px 0 0">MINCAT membantu mempertemukan siswa dan perusahaan, tetapi tidak menjamin hasil atau penerimaan PKL.</p>
	</div>
	<div class="panel" style="margin-bottom:12px"><b>Perubahan dan hukum</b>
		<p class="sub" style="margin:8px 0 0">Syarat ini dapat diperbarui sewaktu-waktu. Penggunaan berkelanjutan berarti kamu menerima perubahannya.</p>
		<p class="sub" style="margin:8px 0 0">Syarat ini tunduk pada hukum Republik Indonesia.</p>
	</div>
<p class="tiny muted" style="margin-top:12px">Draf awal. Perlu ditinjau pihak sekolah sebelum dianggap resmi. Pertanyaan: WhatsApp admin 082226086154.</p>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
