<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}
$mincat_is_admin = current_user_can( 'manage_options' );
if ( 'guru' !== mincat_role() && ! $mincat_is_admin ) {
	wp_safe_redirect( mincat_url( 'akun' ) );
	exit;
}

$mincat_err   = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
$mincat_queue = mincat_lamaran_list( null, 'menunggu' );

// Admin melihat semua, guru hanya siswa bimbingannya.
$mincat_karya = array();
foreach ( get_posts(
		array(
			'post_type'   => 'mincat_karya',
			'numberposts' => -1,
			'post_status' => 'publish',
			'meta_query'  => array(
				'relation' => 'OR',
				array( 'key' => 'k', 'value' => 'review' ),
				array( 'key' => 'pending_k', 'value' => 'review' ),
			),
			'orderby'     => 'date',
			'order'       => 'ASC',
		)
	) as $k ) {
	if ( $mincat_is_admin || (int) get_user_meta( $k->post_author, 'mincat_guru', true ) === get_current_user_id() ) {
		$mincat_karya[] = $k;
	}
}

set_query_var( 'mincat_page', 'review' );
get_header();
get_template_part( 'template-parts/shell', 'open' );

echo mincat_title( 'Antrean review', 'Tinjau karya siswa, lalu ACC atau minta revisi. Lamaran diteruskan ke perusahaan.' );
?>
<?php if ( $mincat_err ) : ?>
<p class="err">
	<?php echo esc_html( $mincat_err ); ?>
</p>
<?php endif; ?>

<div class="panel" style="margin-bottom:16px">
	<b>Karya menunggu review (<?php echo count( $mincat_karya ); ?>)</b>
	<?php if ( $mincat_karya ) : foreach ( $mincat_karya as $k ) :
	$mincat_pending = 'review' === (string) get_post_meta( $k->ID, 'pending_k', true );
	$mincat_fields  = mincat_karya_fields( $k->ID, $mincat_pending );
	$mincat_pf      = $mincat_fields['pf'];
	$mincat_fotos   = isset( $mincat_pf['sertifikat_foto'] ) ? (array) $mincat_pf['sertifikat_foto'] : array();
	$mincat_web     = isset( $mincat_pf['website'] ) ? (string) $mincat_pf['website'] : '';
	?>
	<div class="panel" style="margin:12px 0 0">
		<b><?php echo esc_html( $mincat_fields['title'] ); ?></b>
		<p class="tiny muted" style="margin:2px 0 10px">
			<?php echo esc_html( $mincat_pending ? 'Perubahan pada portofolio terverifikasi' : 'Pengajuan baru' ); ?> · <?php echo esc_html( $mincat_fields['c'] ); ?>
		</p>
		<dl style="margin:0 0 12px">
			<?php foreach ( array(
					'Minat'                => isset( $mincat_pf['minat'] ) ? $mincat_pf['minat'] : '',
					'Skill dan bakat'      => isset( $mincat_pf['skill'] ) ? $mincat_pf['skill'] : '',
					'Projek yang dimiliki' => isset( $mincat_pf['project'] ) ? $mincat_pf['project'] : '',
					'Harapan kedepannya'   => $mincat_fields['content'],
				) as $lbl => $val ) : ?>
			<div style="margin:0 0 8px">
				<dt class="tiny muted">
					<?php echo esc_html( $lbl ); ?>
				</dt>
				<dd style="margin:2px 0 0">
					<?php echo '' !== trim( (string) $val ) ? esc_html( $val ) : '&mdash;'; ?>
				</dd>
			</div>
			<?php endforeach; ?>
			<div style="margin:0 0 8px">
				<dt class="tiny muted">
					Website
				</dt>
				<dd style="margin:2px 0 0">
					<?php echo '' !== $mincat_web ? '<a href="' . esc_url( $mincat_web ) . '" target="_blank" rel="noopener">' . esc_html( $mincat_web ) . '</a>' : '&mdash;'; ?>
				</dd>
			</div>
			<div style="margin:0 0 8px">
				<dt class="tiny muted">
					Sertifikat dan penghargaan
				</dt>
				<dd style="margin:2px 0 0">
					<?php if ( $mincat_fotos ) : foreach ( $mincat_fotos as $u ) : ?><a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( $u ); ?>" alt="Sertifikat" style="width:90px;max-width:100%;border-radius:8px;margin:4px 6px 0 0"></a><?php endforeach; else : ?>&mdash;<?php endif; ?>
				</dd>
			</div>
		</dl>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:10px">
			<input type="hidden" name="action" value="mincat_karya_review">
			<input type="hidden" name="id" value="<?php echo (int) $k->ID; ?>">
			<input type="hidden" name="act" value="acc">
			<?php wp_nonce_field( 'mincat_review_' . $k->ID, '_wpnonce', false ); ?>
			<button class="btn primary small" type="submit">ACC</button>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="mincat_karya_review">
			<input type="hidden" name="id" value="<?php echo (int) $k->ID; ?>">
			<input type="hidden" name="act" value="revisi">
			<?php wp_nonce_field( 'mincat_review_' . $k->ID, '_wpnonce', false ); ?>
			<label style="display:block;font-weight:600;margin:0 0 6px">Catatan revisi</label>
			<textarea name="catatan" rows="3" required placeholder="minimal 10 karakter" style="display:block;width:100%;box-sizing:border-box;margin:0 0 8px"></textarea>
			<button class="btn secondary small" type="submit">Minta revisi</button>
		</form>
	</div>
	<?php endforeach; else : ?>
	<p class="sub">
		Tidak ada karya yang menunggu review.
	</p>
	<?php endif; ?>
</div>

<div class="panel">
	<b>Lamaran menunggu tinjauan (<?php echo count( $mincat_queue ); ?>)</b>
	<?php if ( $mincat_queue ) : foreach ( $mincat_queue as $a ) : ?>
	<div class="nxd-hist__r">
		<div>
			<strong><?php echo esc_html( $a['student'] ); ?></strong><small><?php echo esc_html( $a['title'] ); ?> · <?php echo esc_html( $a['perusahaan'] ); ?></small><?php echo mincat_lamaran_alamat_html( isset( $a['id'] ) ? $a['id'] : 0 ); ?>
		</div>
		<div class="act">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="mincat_lamaran_action"><input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>"><input type="hidden" name="act" value="teruskan"><?php wp_nonce_field( 'mincat_lamaran_' . $a['id'], '_wpnonce', false ); ?><button class="btn primary small" type="submit">Teruskan</button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="mincat_lamaran_action"><input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>"><input type="hidden" name="act" value="tolak"><?php wp_nonce_field( 'mincat_lamaran_' . $a['id'], '_wpnonce', false ); ?><button class="btn secondary small" type="submit">Tolak</button>
			</form>
		</div>
	</div>
	<?php endforeach; else : ?>
	<p class="sub">
		Tidak ada lamaran yang menunggu tinjauan.
	</p>
	<?php endif; ?>
</div>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
