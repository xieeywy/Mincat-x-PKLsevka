<?php
/**
 * Portofolio global: karya dari seluruh siswa yang sudah diunggah.
 * Karya milik sendiri ada di Portofolio saya (page-portofolio-saya.php).
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'portfolio' );

$mincat_states = array( 'Semua', 'Terverifikasi', 'Menunggu Review', 'Revisi' );
$mincat_pq     = isset( $_GET['pq'] ) ? sanitize_text_field( wp_unslash( $_GET['pq'] ) ) : '';
$mincat_ps     = isset( $_GET['ps'] ) && in_array( wp_unslash( $_GET['ps'] ), $mincat_states, true ) ? wp_unslash( $_GET['ps'] ) : 'Semua';
$mincat_base   = mincat_url( 'portfolio' );
$mincat_plist  = array();
foreach ( mincat_projects_all() as $p ) {
	if ( 'Semua' !== $mincat_ps && $p['s'] !== $mincat_ps ) {
		continue;
	}
	if ( '' !== $mincat_pq && false === mb_stripos( $p['t'] . $p['d'] . $p['siswa'], $mincat_pq ) ) {
		continue;
	}
	$mincat_plist[] = $p;
}

set_query_var( 'mincat_page', 'portfolio' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
echo mincat_title( 'Portofolio', 'Karya dari seluruh siswa yang sudah diunggah.' );
?>
<form method="get" action="<?php echo esc_url( $mincat_base ); ?>" class="search">
	<input type="hidden" name="ps" value="<?php echo esc_attr( $mincat_ps ); ?>">
	<input aria-label="Cari karya" placeholder="Cari karya atau nama siswa..." name="pq" value="<?php echo esc_attr( $mincat_pq ); ?>">
</form>
<div class="portfolio">
	<?php if ( $mincat_plist ) { foreach ( $mincat_plist as $p ) { ?>
			<article class="project">
				<?php echo mincat_karya_banner( (int) $p['id'] ); ?>
				<h3>
					<?php echo esc_html( $p['t'] ); ?>
				</h3>
				<p class="tiny muted">
					<?php echo esc_html( 'Diupload oleh ' . $p['username'] . ' · ' . $p['c'] ); ?>
				</p>
				<p>
					<?php echo esc_html( $p['d'] ); ?>
				</p>
				<div class="bottom">
					<?php echo mincat_status( $p['s'], $p['k'] ); ?>
				</div>
				<a class="btn secondary small port-detail" href="<?php echo esc_url( mincat_logged_in() ? add_query_arg( 'karya', (int) $p['id'], mincat_url( 'portofolio-detail' ) ) : mincat_url( 'masuk' ) ); ?>"><?php echo mincat_logged_in() ? 'Lihat detail' : 'Masuk untuk lihat detail'; ?></a>
			</article>
		<?php } } else { echo mincat_empty_box( 'Belum ada karya.', 'Karya dari siswa akan muncul di sini setelah diunggah.' ); } ?>
</div>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
