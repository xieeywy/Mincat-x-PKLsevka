<?php
/**
 * MINCAT: bootstrap tema.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MINCAT_VERSION', '0.2.122' );

require_once get_template_directory() . '/inc/mincat-helpers.php';
require_once get_template_directory() . '/inc/mincat-data.php';
require_once get_template_directory() . '/inc/mincat-auth.php';
require_once get_template_directory() . '/inc/mincat-flow.php';
require_once get_template_directory() . '/inc/mincat-karya.php';
require_once get_template_directory() . '/inc/mincat-import.php';
require_once get_template_directory() . '/inc/mincat-panduan.php';
require_once get_template_directory() . '/inc/mincat-actions.php';

function mincat_enqueue_assets() {
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'mincat', $uri . '/assets/css/mincat.css', array(), MINCAT_VERSION );
	wp_enqueue_style( 'mincat-links', $uri . '/assets/css/mincat-links.css', array( 'mincat' ), MINCAT_VERSION );
	wp_enqueue_style( 'mincat-auth', $uri . '/assets/css/mincat-auth.css', array( 'mincat' ), MINCAT_VERSION );
	wp_enqueue_script( 'mincat-geo', $uri . '/assets/js/mincat-geo.js', array(), MINCAT_VERSION, true );
	wp_enqueue_script( 'mincat-actions', $uri . '/assets/js/mincat-actions.js', array(), MINCAT_VERSION, true );
	wp_localize_script( 'mincat-actions', 'MINCAT_ACT', array( 'ajax' => admin_url( 'admin-post.php' ), 'nonce' => wp_create_nonce( 'mincat_act' ), 'detail' => mincat_url( 'portofolio-detail' ) ) );
	wp_enqueue_script( 'mincy', $uri . '/assets/js/mincy.js', array(), MINCAT_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'mincat_enqueue_assets' );

/**
 * Buat otomatis semua halaman MINCAT yang punya file template (page-{slug}.php).
 * Dijalankan saat tema diaktifkan dan sekali setelah tema diperbarui.
 * Halaman yang sudah ada tidak dibuat ulang, hanya dipastikan berstatus Published.
 */
function mincat_ensure_pages() {
	if ( get_option( 'mincat_pages_version' ) === MINCAT_VERSION ) {
		return;
	}
	$titles = array(
		'masuk'         => 'Masuk',
		'akun'          => 'Akun Saya',
		'opportunities' => 'Peluang PKL',
		'peluang'       => 'Peluang PKL',
		'portofolio'    => 'Portofolio',
		'portofolio-baru' => 'Tambah karya',
		'portofolio-detail' => 'Detail portofolio',
		'kebijakan-privasi' => 'Kebijakan privasi',
		'syarat-layanan' => 'Syarat layanan',
		'panduan' => 'Panduan',
		'panduan-mulai' => 'Mulai dan akun',
		'panduan-portofolio' => 'Portofolio siswa',
		'panduan-lihat-karya' => 'Melihat karya dan detail',
		'panduan-peluang' => 'Peluang PKL dan lamaran',
		'panduan-guru' => 'Guru dan mentor',
		'panduan-perusahaan' => 'Perusahaan',
		'panduan-admin' => 'Admin sekolah',
		'jurnal'        => 'Jurnal PKL',
		'pesan'         => 'Pesan',
		'mitra'         => 'Mitra dan lowongan',
		'about'         => 'Tentang MINCAT',
		'settings'      => 'Pengaturan',
		'verifikasi'    => 'Verifikasi akun',
		'lengkapi-akun' => 'Lengkapi akun',
		'detail-peluang'=> 'Detail peluang',
	);
	$slugs = array_unique( array_filter( array_values( mincat_page_slugs() ) ) );
	foreach ( $slugs as $slug ) {
		if ( ! file_exists( get_template_directory() . '/page-' . $slug . '.php' ) ) {
			continue;
		}
		$title = isset( $titles[ $slug ] ) ? $titles[ $slug ] : ucwords( str_replace( '-', ' ', $slug ) );
		$page  = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $page ) {
			if ( 'publish' !== $page->post_status ) {
				wp_update_post( array( 'ID' => $page->ID, 'post_status' => 'publish' ) );
			}
			continue;
		}
		wp_insert_post( array(
				'post_title'  => $title,
				'post_name'   => $slug,
				'post_status' => 'publish',
				'post_type'   => 'page',
				'post_content' => '',
			) );
	}
	update_option( 'mincat_pages_version', MINCAT_VERSION );
}
add_action( 'after_switch_theme', 'mincat_ensure_pages' );
add_action( 'init', 'mincat_ensure_pages', 20 );

add_filter( 'show_admin_bar', '__return_false' );
