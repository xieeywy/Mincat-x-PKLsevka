<?php
/**
 * Detail karya sebagai halaman terpisah (hanya untuk akun yang sudah login).
 * Dipanggil dengan ?karya=ID. Foto besar memakai foto profil siswa.
 * Gaya tampilan ada di assets/css/mincat-links.css (kelas .pd-*).
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_share_ok = false;
if ( isset( $_GET['karya'], $_GET['t'] ) ) {
	$mincat_sid = absint( wp_unslash( $_GET['karya'] ) );
	$mincat_stok = sanitize_text_field( wp_unslash( $_GET['t'] ) );
	$mincat_real = $mincat_sid ? (string) get_post_meta( $mincat_sid, 'share_token', true ) : '';
	$mincat_share_ok = '' !== $mincat_real && hash_equals( $mincat_real, $mincat_stok ) && 'verified' === get_post_meta( $mincat_sid, 'k', true );
}
if ( ! is_user_logged_in() && ! $mincat_share_ok ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}

$mincat_id   = isset( $_GET['karya'] ) ? absint( wp_unslash( $_GET['karya'] ) ) : 0;
$mincat_post = $mincat_id ? get_post( $mincat_id ) : null;
$mincat_ok   = $mincat_post && 'mincat_karya' === $mincat_post->post_type && 'publish' === $mincat_post->post_status;
$mincat_boleh = false;
if ( $mincat_ok ) {
	$mincat_k   = (string) get_post_meta( $mincat_id, 'k', true );
	$mincat_peran = mincat_role();
	$mincat_boleh = in_array( $mincat_peran, array( 'siswa', 'guru', 'mentor', 'perusahaan', 'admin' ), true );
	$mincat_can = $mincat_boleh && ( 'verified' === $mincat_k
		|| (int) $mincat_post->post_author === get_current_user_id()
		|| current_user_can( 'manage_options' )
		|| 'guru' === $mincat_peran );
	$mincat_ok  = $mincat_can;
if ( $mincat_share_ok && $mincat_post && 'mincat_karya' === $mincat_post->post_type && $mincat_post->ID === $mincat_sid ) {
	$mincat_boleh = true;
	$mincat_can   = true;
	$mincat_ok    = true;
}
}

set_query_var( 'mincat_page', 'portofolio-detail' );
get_header();
get_template_part( 'template-parts/shell', 'open' );

if ( ! $mincat_ok && ! $mincat_boleh ) {
	echo mincat_empty_box( 'Halaman ini hanya untuk siswa, guru, mentor, dan perusahaan.', 'Masuk dengan akun sekolah atau perusahaan untuk melihat detail karya.' );
} elseif ( ! $mincat_ok ) {
	echo mincat_empty_box( 'Karya tidak ditemukan.', 'Karya ini belum tersedia untuk dilihat.' );
} else {
	$mincat_f    = mincat_karya_fields( $mincat_id, false );
	$mincat_pf   = $mincat_f['pf'];
	$mincat_au   = get_userdata( (int) $mincat_post->post_author );
	$mincat_foto = isset( $mincat_pf['foto_diri'] ) && '' !== (string) $mincat_pf['foto_diri'] ? (string) $mincat_pf['foto_diri'] : ( $mincat_au ? (string) get_user_meta( $mincat_au->ID, 'mincat_photo', true ) : '' );
	$mincat_ini  = $mincat_au ? mincat_initials( $mincat_au->display_name ) : '';
	$mincat_nama = ! empty( $mincat_pf['nama'] ) ? $mincat_pf['nama'] : $mincat_f['title'];
	$mincat_kls  = ! empty( $mincat_pf['kelas'] ) ? $mincat_pf['kelas'] : $mincat_f['c'];
	$mincat_min  = isset( $mincat_pf['minat'] ) ? (string) $mincat_pf['minat'] : '';
	$mincat_skl  = (array) $mincat_f['tools'];
	$mincat_fts  = isset( $mincat_pf['sertifikat_foto'] ) ? (array) $mincat_pf['sertifikat_foto'] : array();
	$mincat_prj  = isset( $mincat_pf['project'] ) ? (string) $mincat_pf['project'] : '';
	$mincat_peng = isset( $mincat_pf['pengalaman'] ) ? (string) $mincat_pf['pengalaman'] : '';
	$mincat_har  = '' !== trim( (string) $mincat_f['content'] ) ? (string) $mincat_f['content'] : ( isset( $mincat_pf['harapan'] ) ? (string) $mincat_pf['harapan'] : '' );
	$mincat_web  = isset( $mincat_pf['website'] ) ? (string) $mincat_pf['website'] : '';
	$mincat_pl   = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $mincat_peng ) ) ) );
	$mincat_kal  = 'Nama saya ' . $mincat_nama . ', siswa ' . $mincat_kls . '.';
	if ( '' !== $mincat_min ) {
		$mincat_kal .= ' Minat saya ' . $mincat_min . '.';
	}
	?>
<div class="pd-wrap">
  <p class="tiny"><a class="link" href="<?php echo esc_url( mincat_url( 'portfolio' ) ); ?>">&larr; Kembali ke Portofolio</a></p>

  <div class="pd-layout">
    <div class="pd-left"><div class="pd-foto">
      <?php if ( $mincat_foto ) : ?><img src="<?php echo esc_url( $mincat_foto ); ?>" alt="Foto <?php echo esc_attr( $mincat_nama ); ?>"><?php else : ?><div class="pd-ini"><?php echo esc_html( $mincat_ini ); ?></div><?php endif; ?>
    </div>
      <div class="pd-sec">
        <h2>Sertifikat &amp; penghargaan</h2>
        <div class="pd-imgs"><?php if ( $mincat_fts ) : foreach ( $mincat_fts as $u ) : ?><a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( $u ); ?>" alt="Sertifikat"></a><?php endforeach; else : ?><span class="tiny muted">Belum ada</span><?php endif; ?></div>
      </div>
    </div>

    <div class="pd-mid">
      <h1 class="pd-halo">Halo!</h1>
      <p class="pd-intro"><?php echo esc_html( $mincat_kal ); ?></p>
      <p class="pd-intro">Terima kasih sudah melihat portofolio saya!</p>

      <div class="pd-sec">
        <h2>Profil</h2>
        <p class="pd-lbl">Nama:</p><p class="pd-val"><?php echo esc_html( $mincat_nama ); ?></p>
        <p class="pd-lbl">Kelas dan Jurusan:</p><p class="pd-val"><?php echo esc_html( $mincat_kls ); ?></p>
        <?php if ( '' !== $mincat_min ) : ?><p class="pd-lbl">Minat:</p><p class="pd-val"><?php echo esc_html( $mincat_min ); ?></p><?php endif; ?>
      </div>
    </div>

    <div class="pd-side">
      <div class="pd-sec">
        <h2>Skill &amp; bakat</h2>
        <div><?php if ( $mincat_skl ) : foreach ( $mincat_skl as $sk ) : ?><span class="pd-tag"><?php echo esc_html( $sk ); ?></span><?php endforeach; else : ?><span class="tiny muted">Belum diisi</span><?php endif; ?></div>
      </div>

      <div class="pd-sec">
        <h2>Portofolio</h2>
        <p class="pd-lbl">Projek yang dimiliki:</p><p class="pd-text"><?php echo '' !== trim( $mincat_prj ) ? esc_html( $mincat_prj ) : '<span class="tiny muted">Belum ada</span>'; ?></p>
        <p class="pd-lbl">Pengalaman:</p><?php if ( $mincat_pl ) : foreach ( $mincat_pl as $ln ) : ?><p class="pd-text"><?php echo esc_html( $ln ); ?></p><?php endforeach; else : ?><p class="tiny muted" style="margin:0 0 14px">Belum ada</p><?php endif; ?>
        <p class="pd-lbl">Harapan kedepannya:</p><p class="pd-text"><?php echo '' !== trim( $mincat_har ) ? esc_html( $mincat_har ) : '<span class="tiny muted">Belum diisi</span>'; ?></p>
        <p class="pd-lbl">Website:</p><p class="pd-text"><?php echo '' !== $mincat_web ? '<a href="' . esc_url( $mincat_web ) . '" target="_blank" rel="noopener">' . esc_html( $mincat_web ) . '</a>' : '&mdash;'; ?></p>
      </div>

      
    </div>
  </div>
</div>
<?php
}

if ( isset( $_GET['cetak'] ) ) {
	echo '<script>window.addEventListener("load",function(){window.print();});</script>';
}
get_template_part( 'template-parts/shell', 'close' );
get_footer();
