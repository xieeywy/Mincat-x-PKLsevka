<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'pesan' );
if ( 'siswa' === mincat_role() ) {
	wp_safe_redirect( add_query_arg( 'tab', 'pesan', mincat_url( 'akun' ) ) );
	exit;
}
$mincat_mine = mincat_pesan();
$mincat_role = mincat_role();
set_query_var( 'mincat_page', 'pesan' );
get_header();
<?php if ( 'siswa' === $mincat_role ) { get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Pesan dari perusahaan', 'Pesan masuk lewat MINCAT. Kontakmu hanya dibagikan kalau kamu setuju.' ); ?>

	<?php if ( $mincat_mine ) { foreach ( $mincat_mine as $p ) { ?>
			<div class="panel" style="margin-bottom:10px">
				<div class="ak-card-head">
					<b><?php echo esc_html( $p['dari'] ); ?></b><?php echo mincat_status( 'menunggu' === $p['status'] ? 'Menunggu' : ( 'kontak' === $p['status'] ? 'Kontak dibagikan' : 'Ditolak' ), 'kontak' === $p['status'] ? 'verified' : ( 'ditolak' === $p['status'] ? 'revision' : 'review' ) ); ?>
				</div>
				<p class="tiny muted">
					Lamaran: <?php echo esc_html( $p['lamaran'] ); ?> · <?php echo esc_html( $p['t'] ); ?>
				</p>
				<p>
					<?php echo esc_html( $p['isi'] ); ?>
				</p>
				<?php if ( 'menunggu' === $p['status'] ) { ?>
					<div class="app-acts">
						<button class="btn primary small" data-mincat-action="bagikan-kontak" data-id="<?php echo (int) $p['id']; ?>">Bagikan kontakku</button><button class="btn secondary small" data-mincat-action="tolak-pesan" data-id="<?php echo (int) $p['id']; ?>">Tolak</button>
					</div>
				<?php } ?>
			</div>
		<?php } } else { echo mincat_empty_box( 'Belum ada pesan.', 'Pesan dari perusahaan yang tertarik akan muncul di sini.' ); } ?><?php } else { get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Pesan terkirim', 'Status pesanmu ke pelamar. Kontak siswa hanya tampil jika siswa sudah setuju.' ); ?>

	<?php if ( $mincat_mine ) { foreach ( $mincat_mine as $p ) { ?>
			<div class="panel" style="margin-bottom:10px">
				<b><?php echo esc_html( $p['untuk'] ); ?></b>
				<p class="tiny muted">
					Lamaran: <?php echo esc_html( $p['lamaran'] ); ?> · <?php echo esc_html( $p['t'] ); ?>
				</p>
				<p>
					<?php echo esc_html( $p['isi'] ); ?>
				</p>
				<?php echo mincat_status( 'menunggu' === $p['status'] ? 'Menunggu balasan' : ( 'kontak' === $p['status'] ? 'Kontak dibagikan' : 'Ditolak' ), 'kontak' === $p['status'] ? 'verified' : ( 'ditolak' === $p['status'] ? 'revision' : 'review' ) ); ?><?php if ( 'kontak' === $p['status'] ) { ?>
					<p class="tiny" style="margin-top:8px">
						<b>Kontak siswa:</b> <?php echo esc_html( $p['kontak'] ); ?>
					</p>
				<?php } ?>
			</div>
		<?php } } else { echo mincat_empty_box( 'Belum ada pesan terkirim.', 'Hubungi pelamar dari bagian Lamaran masuk.' ); } ?><?php }
get_template_part( 'template-parts/shell', 'close' );
get_footer();
