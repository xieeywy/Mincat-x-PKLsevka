<?php
/**
 * Tentang MINCAT: disusun dari rancangan referensi, memakai gaya dan kelas MINCAT.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
set_query_var( 'mincat_page', 'about' );
get_header();
get_template_part( 'template-parts/shell', 'open' );
$mincat_cta = is_user_logged_in() ? mincat_url( 'akun' ) : mincat_url( 'masuk' );
?>
<section class="ab-sec">
	<p class="ab-eyebrow">Tentang MINCAT</p>
	<h1 class="ab-h2">Setiap karya punya cerita. Setiap langkah punya peluang.</h1>
	<div class="ab-body">
		<p>MINCAT adalah platform portofolio dan pencarian Praktik Kerja Lapangan (PKL) yang membantu siswa menampilkan karya dan keterampilan mereka, menemukan peluang PKL, serta memantau status lamaran dalam satu tempat.</p>
		<p>MINCAT juga membantu guru memverifikasi portofolio siswa dan memudahkan perusahaan menemukan calon peserta PKL berdasarkan karya serta kemampuan mereka.</p>
		<p>Dimulai dari lingkungan sekolah kami, MINCAT hadir untuk menjembatani siswa dengan dunia profesional.</p>
	</div>
	<div class="ab-rule"></div>
	<p class="ab-tagline">Small Steps, Big Future.</p>
	<p style="margin-top:22px"><a class="btn primary" href="<?php echo esc_url( $mincat_cta ); ?>">Mulai perjalanan <?php echo mincat_ic( 'arrow' ); ?></a></p>
</section>

<section class="ab-sec ab-band">
	<p class="ab-eyebrow">Visi &amp; Misi</p>
	<h2 class="ab-h2">Arah yang ingin dicapai</h2>
	<div class="ab-vm">
		<div class="ab-vmcol">
			<div class="ab-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></div>
			<div>
				<h3>Visi</h3>
				<p>Membantu siswa mengembangkan potensi dan mempersiapkan masa depan melalui karya, kompetensi, dan kesempatan belajar.</p>
			</div>
		</div>
		<div class="ab-vmcol">
			<div class="ab-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/></svg></div>
			<div>
				<h3>Misi</h3>
				<ol class="ab-mission">
					<li>Mendorong siswa mendokumentasikan karya dan keterampilannya.</li>
					<li>Mempermudah akses terhadap informasi peluang PKL.</li>
					<li>Mendukung proses peninjauan dan verifikasi portofolio.</li>
					<li>Mendorong hubungan yang lebih baik antara siswa, sekolah, dan perusahaan.</li>
				</ol>
			</div>
		</div>
	</div>
</section>

<section class="ab-sec">
	<p class="ab-eyebrow">Tim Pengembang</p>
	<h2 class="ab-h2">Smitty Werberjagermanjensen</h2>
	<p class="ab-school">SMK Negeri 7 Kendal</p>
	<ul class="ab-team">
		<li class="ab-card">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/tim-fallen.webp" width="239" height="550" loading="lazy" style="object-position:center 18%" alt="Foto Fallen Pradita">
			<div>
				<h3>Fallen Pradita</h3>
				<p class="ab-role">Full-Stack Developer</p>
				<div class="ab-bar"></div>
				<p>Bertanggung jawab atas pengembangan teknis MINCAT secara menyeluruh, mulai dari perancangan UI/UX dan mockup, pengembangan frontend dan backend, hingga penerapan keamanan aplikasi. Turut menangani konfigurasi domain, hosting, serta integrasi dan pengelolaan komponen website agar platform dapat berjalan dengan baik.</p>
			</div>
		</li>
		<li class="ab-card">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/tim-ahmad.webp" width="309" height="550" loading="lazy" style="object-position:center 46%" alt="Foto Ahmad Syahrul Gunawan">
			<div>
				<h3>Ahmad Syahrul Gunawan</h3>
				<p class="ab-role">Project Documentation &amp; Research</p>
				<div class="ab-bar"></div>
				<p>Bertanggung jawab atas pengelolaan repositori GitHub dan dokumentasi proyek, penyusunan proposal, serta pelaksanaan survei untuk mengumpulkan masukan dari calon pengguna. Turut mengolah data hasil survei menjadi ringkasan dan informasi serta membantu revisi yang diperlukan sebagai bahan evaluasi dan dasar pengembangan MINCAT.</p>
			</div>
		</li>
	</ul>
</section>

<section class="ab-sec ab-band">
	<p class="ab-eyebrow">Nilai Utama</p>
	<h2 class="ab-h2">Lebih dari sekadar platform</h2>
	<p class="ab-lead">MINCAT dibangun dengan nilai-nilai yang mendorong pertumbuhan dan kesempatan bagi setiap penggunanya.</p>
	<div class="ab-values">
		<div class="ab-value">
			<svg viewBox="0 0 24 24"><path d="M12 21V11"/><path d="M12 11C12 6.5 9 4 4 4c0 4.5 3 7 8 7z"/><path d="M12 14c0-3.5 2.5-6 7-6 0 3.5-2.5 6-7 6z"/></svg>
			<h3>Growth</h3>
			<p>Perkembangan kompetensi secara bertahap.</p>
		</div>
		<div class="ab-value">
			<svg viewBox="0 0 24 24"><path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3.1-5.4 3.1 1.2-6L3.3 9.3l6.1-.7z"/></svg>
			<h3>Opportunity</h3>
			<p>Akses terhadap peluang belajar dan PKL.</p>
		</div>
		<div class="ab-value">
			<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="M21 17l-5-5-6 6"/></svg>
			<h3>Showcase</h3>
			<p>Ruang untuk menunjukkan karya.</p>
		</div>
		<div class="ab-value">
			<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c2.6.2 5 2.2 5 5"/></svg>
			<h3>Connection</h3>
			<p>Hubungan antara siswa, guru, dan perusahaan.</p>
		</div>
	</div>
</section>
<?php
get_template_part( 'template-parts/shell', 'close' );
get_footer();
