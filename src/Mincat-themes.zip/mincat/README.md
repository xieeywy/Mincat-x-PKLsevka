# MINCAT

Platform portofolio dan Praktik Kerja Lapangan (PKL) untuk siswa SMK. Siswa menampilkan karya yang sudah diverifikasi guru, melihat peluang PKL, dan melamar. Guru meninjau karya dan meneruskan lamaran, perusahaan membuat lowongan dan memutuskan pelamar, dan admin mengelola akun.

Dibangun sebagai tema WordPress untuk SMKN 7 Kendal.

## Daftar isi

- [Fitur](#fitur)
- [Peran pengguna](#peran-pengguna)
- [Halaman](#halaman)
- [Persyaratan](#persyaratan)
- [Pemasangan](#pemasangan)
- [Konfigurasi](#konfigurasi)
- [Alur penggunaan](#alur-penggunaan)
- [Privasi dan keamanan](#privasi-dan-keamanan)
- [Struktur kode](#struktur-kode)
- [Pengembangan](#pengembangan)
- [Batasan saat ini](#batasan-saat-ini)

## Fitur

- **Akun dan peran.** Login dengan Google (plugin Nextend Social Login). Akun baru berperan Visitor sampai admin menyetujui permintaan peran.
- **Portofolio siswa.** Satu portofolio per siswa, berisi profil, minat, skill dan bakat, sertifikat (hingga 5 foto), projek, pengalaman, harapan, dan website. Ada foto diri untuk halaman detail.
- **Status karya.** Menunggu Review, Terverifikasi, atau Revisi. Karya terverifikasi tidak perlu verifikasi ulang saat diedit.
- **Peluang PKL.** Lowongan per bidang (TKJ, TSM, TJAT) dengan persentase kecocokan skill dan bidang. Lowongan tanpa skill memakai skill default bidangnya.
- **Lamaran.** Siswa melamar, guru meneruskan ke perusahaan, perusahaan menerima atau menolak.
- **Alamat rumah (opsional).** Siswa dapat mengisi alamat dan mengambil koordinat dari perangkat. Alamat dipakai untuk tautan rute ke tempat PKL di Google Maps.
- **Berbagi karya.** Karya terverifikasi bisa dibagikan lewat tautan yang tidak memerlukan login. Tautan bisa dicabut dengan menghapus token.
- **Unduh PDF.** Halaman detail karya bisa dicetak sebagai PDF lewat dialog cetak browser.
- **Panduan.** Tujuh panduan (halaman sendiri) untuk setiap bagian sistem. Dapat dibuka dari panel Mincy.
- **Panel Mincy.** Panel bantuan di bilah bawah HP dan tombol mengambang di PC, berisi daftar panduan dan tombol chat WhatsApp admin.
- **Dashboard per peran.** Siswa, guru, mentor, perusahaan, dan admin masing-masing punya sidebar dan menu sendiri.
- **Persetujuan privasi.** Siswa dapat mengatur persetujuan untuk tampil di beranda, berbagi kontak, dan kontak ke perusahaan.
- **Hak data.** Unduh data akun dalam JSON, dan hapus akun beserta datanya.

## Peran pengguna

| Peran | Yang bisa dilakukan |
|---|---|
| Tamu | Melihat beranda, Portofolio (karya terverifikasi), Peluang PKL (daftar), Tentang, dan panduan. |
| Visitor | Akun baru yang menunggu persetujuan. Belum bisa memakai fitur sekolah. |
| Siswa | Membuat dan mengedit portofolio, melamar PKL, membagikan karya, mengatur persetujuan dan profil. |
| Guru pembimbing | Meninjau karya siswa bimbingannya, ACC atau meminta revisi, meneruskan lamaran. |
| Mentor | Sama dengan guru pembimbing untuk peninjauan karya. |
| Perusahaan | Membuat lowongan, melihat pelamar yang sudah diteruskan guru, menerima atau menolak. |
| Admin | Menyetujui permintaan peran, memilih guru pembimbing, mengimpor daftar PKL, menyetujui lowongan. |
| Wali | Mengatur persetujuan untuk anaknya yang terhubung. |

## Halaman

Halaman dibuat otomatis oleh tema dari file `page-{slug}.php`.

- `/` Beranda (karya pilihan, contoh peluang, ajakan masuk)
- `/peluang/` Daftar peluang PKL
- `/portofolio/` Karya terverifikasi semua siswa
- `/portofolio-detail/?karya=ID` Detail karya
- `/portofolio-baru/` Buat atau edit portofolio (siswa)
- `/akun/` Dashboard per peran (tab: dashboard, profil, karya, lamaran, pesan)
- `/review/` Antrean review karya dan lamaran (guru, mentor, admin)
- `/company/` Lowongan dan pelamar (perusahaan)
- `/masuk/`, `/verifikasi/`, `/lengkapi-akun/` Login dan verifikasi
- `/tentang/` Tentang MINCAT
- `/panduan/` dan `/panduan-{kunci}/` Panduan
- `/kebijakan-privasi/`, `/syarat-layanan/` Dokumen legal (draf, perlu ditinjau)

## Persyaratan

- WordPress 6.2 atau lebih baru
- PHP 7.4 atau lebih baru
- Plugin **Nextend Social Login** untuk login Google
- Plugin **MINCAT Core** (folder terpisah di repo ini), berisi tipe konten dan tabel tambahan
- Disarankan: Wordfence atau plugin keamanan lain

## Pemasangan

1. Unggah folder tema `mincat` ke `wp-content/themes/`, atau unggah zip lewat **Tampilan > Tema > Tambah baru > Unggah tema**.
2. Aktifkan tema **MINCAT**.
3. Pasang dan aktifkan plugin Nextend Social Login, lalu hubungkan dengan Google Cloud (Client ID dan Client Secret).
4. Pasang dan aktifkan plugin MINCAT Core.
5. Buka **Pengaturan > Permalink** dan simpan ulang supaya tautan rapi.
6. Halaman akan dibuat otomatis saat tema diaktifkan. Kalau ada halaman yang belum muncul, bersihkan cache lalu muat ulang.

## Konfigurasi

- **Nomor WhatsApp admin.** Diatur di beberapa tempat di kode (footer, panel Mincy, halaman bantuan). Cari `wa.me/` untuk mengganti.
- **Logo.** Logo ada di `assets/images/`. Logo hero (`mincat-x-smkn7.webp`) dan logo Mincy (`mincy.webp`) bisa diganti dengan file baru, lalu naikkan nomor versi di `functions.php` agar browser memuat ulang.
- **Daftar PKL awal.** Admin dapat mengimpor daftar lowongan dari `assets/data/iduka-pkl.csv` lewat tombol **Impor daftar PKL** di dashboard admin.
- **Skill per bidang.** Daftar skill default dan bidang ada di `inc/mincat-helpers.php` (`mincat_skill_taxonomy`).

## Alur penggunaan

**Siswa**
1. Masuk dengan Google. Akun dibuat sebagai Visitor.
2. Kirim permintaan peran Siswa dan pilih guru pembimbing (lewat admin).
3. Buat portofolio, unggah foto dan sertifikat, lalu kirim ke review.
4. Setelah diterima guru, karya terverifikasi tampil. Bisa ditampilkan di beranda dan dibagikan.
5. Melamar lowongan dari Peluang PKL. Lamaran diteruskan guru.

**Guru pembimbing dan mentor**
1. Buka **Antrean review** dan periksa karya siswa bimbingan.
2. ACC, atau minta revisi dengan catatan minimal 10 karakter.
3. Teruskan lamaran siswa bimbingan ke perusahaan.

**Perusahaan**
1. Buat lowongan dengan judul, lokasi, bidang, kuota, dan deskripsi.
2. Lihat pelamar yang sudah diteruskan guru.
3. Terima atau tolak pelamar.

**Admin**
1. Setujui permintaan peran dan pilih guru pembimbing untuk siswa.
2. Impor daftar PKL dan setujui lowongan.

## Privasi dan keamanan

Data yang dikumpulkan: nama, username, email, nomor telepon, kelas dan jurusan, portofolio, foto, lamaran, dan alamat (jika diisi siswa).

Siapa yang bisa melihat:
- **Email dan nomor telepon:** siswa sendiri dan admin. Perusahaan menerima nomor hanya jika siswa setuju.
- **Alamat rumah:** siswa sendiri, guru, mentor, perusahaan, dan admin. Wali dan siswa lain tidak bisa melihat.
- **Detail karya:** siswa, guru, mentor, perusahaan, dan admin yang sudah masuk. Tamu tidak bisa melihat, kecuali lewat tautan bagikan yang dibuat siswa.
- **Karya di beranda:** hanya inisial dan jurusan, dan hanya jika siswa mengizinkan.

Catatan keamanan:
- Semua aksi tombol dikirim ke satu endpoint `admin-post` dengan nonce dan pengecekan peran di server.
- Persetujuan peran memakai ID akun pengirim, bukan email, supaya email yang diganti tidak bisa dipakai untuk mengambil peran.
- Upload dibatasi jenis dan ukuran, serta diperkecil di server. SVG tidak diizinkan.
- Tautan bagikan memakai token acak yang disimpan di meta karya (`share_token`).
- Tidak ada kata sandi atau kunci API di dalam kode.

Hapus akun menghapus data akun dan karya di database. File foto dan sertifikat di folder upload belum ikut dihapus.

## Struktur kode

```
mincat/
├── functions.php          Pengaturan tema, skrip dan gaya, pembuatan halaman otomatis
├── style.css              Header tema dan gaya dasar
├── header.php, footer.php Kerangka halaman dan panel Mincy
├── front-page.php         Beranda
├── page-*.php             Satu file per halaman
├── template-parts/        Bagian dashboard dan kerangka halaman
├── inc/
│   ├── mincat-helpers.php Fungsi bantu, navigasi, skill, bidang
│   ├── mincat-data.php    Data lowongan, lamaran, pesan, karya
│   ├── mincat-auth.php    Peran, persetujuan, profil, upload foto
│   ├── mincat-flow.php    Alur lamaran dan lowongan
│   ├── mincat-karya.php   Portofolio: simpan, tinjau, status
│   ├── mincat-import.php  Impor daftar PKL
│   ├── mincat-panduan.php Isi panduan
│   └── mincat-actions.php Endpoint aksi tombol (admin-post mincat_act)
├── assets/
│   ├── css/               mincat.css (dasar), mincat-links.css (tambahan), mincat-akun*.css, mincat-auth.css
│   ├── js/                mincat-actions.js, mincy.js, mincat-geo.js
│   ├── images/            Logo dan gambar
│   └── data/              iduka-pkl.csv
└── README.md
```

## Pengembangan

- Tidak ada langkah build. Ubah file PHP, CSS, atau JS langsung.
- Saat mengubah file statis (CSS, JS, gambar), naikkan nomor versi `MINCAT_VERSION` di `functions.php` dan `Version` di `style.css` agar browser memuat ulang.
- Tambah halaman baru dengan membuat `page-{slug}.php`, lalu daftarkan slug dan judulnya di `inc/mincat-helpers.php` dan `functions.php`.
- Tambah aksi tombol baru dengan atribut `data-mincat-action`, lalu tambahkan penanganannya di `assets/js/mincat-actions.js` dan `inc/mincat-actions.php`.
- Pemeriksaan sintaks PHP: `php -l file.php`.

## Batasan saat ini

- Tombol **Bagikan tautan** hanya membuat tautan. Belum ada tombol untuk mencabut tautan.
- Notifikasi perubahan status lamaran dan karya belum ada. Tombol lonceng hanya menandai semua notifikasi sudah dibaca.
- Dashboard guru, mentor, dan perusahaan masih sederhana. Statistik dan daftar hanya ringkasan.
- Dokumen kebijakan privasi dan syarat layanan masih berupa draf dan perlu ditinjau pihak sekolah.
- Filter lokasi di Peluang PKL belum disesuaikan dengan daftar IDUKA.
- Belum ada pembatasan frekuensi untuk permintaan peran dan upload, serta belum ada catatan audit persetujuan.
- Belum ada pemeriksaan akses terpusat (middleware). Pengecekan peran dilakukan di tiap halaman dan handler.
- Rute ke tempat PKL memakai Google Maps dan alamat otomatis dari OpenStreetMap (Nominatim). Hasilnya bergantung pada kualitas data dari layanan tersebut.

## Lisensi

Belum ditentukan. Tambahkan file `LICENSE` sebelum repo dibuka untuk umum.

## Tim

- **Fallen Pradita**, Full-Stack Developer
- **Ahmad Syahrul Gunawan**, Project Documentation & Research
- SMK Negeri 7 Kendal
