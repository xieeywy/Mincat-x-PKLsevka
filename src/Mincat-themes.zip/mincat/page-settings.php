<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_enforce_role( 'settings' );
if ( 'siswa' === mincat_role() ) {
	wp_safe_redirect( add_query_arg( 'tab', 'profil', mincat_url( 'akun' ) ) );
	exit;
}
$mincat_pf = mincat_profile();
set_query_var( 'mincat_page', 'settings' );
get_header();
get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Pengaturan Akun', 'Kelola informasi profil dan preferensi akun.' ); ?>

<div class="panel" style="max-width:650px;margin-bottom:14px">
	<b>Data saya</b>
	<p class="tiny muted">
		Kamu berhak melihat, mengunduh, dan menghapus data akunmu. Penghapusan juga mencabut tautan bagikan yang aktif.
	</p>
	<div class="app-acts">
		<button class="btn secondary small" data-mincat-action="download-my-data">Unduh data saya (JSON)</button><button class="btn danger small" data-mincat-action="confirm-delete">Hapus akun dan data</button>
	</div>
</div>
<form class="panel" style="max-width:650px" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
	<input type="hidden" name="action" value="mincat_save_settings"><?php wp_nonce_field( 'mincat_save_settings' ); ?>

	<div class="user">
		<div class="avatar">
			AP
		</div>
		<div>
			<b><?php echo esc_html( $mincat_pf['name'] ); ?></b>
			<p class="tiny muted">
				Siswa · SMK 1
			</p>
		</div>
	</div>
	<div class="content">
		<label for="sn">Nama tampilan</label><input id="sn" name="name" class="fld" value="<?php echo esc_attr( $mincat_pf['name'] ); ?>">
		<p class="err" data-err="name">
		</p>
	</div>
	<div class="content">
		<label for="se">Email</label><input id="se" name="email" class="fld" type="email" value="<?php echo esc_attr( $mincat_pf['email'] ); ?>">
		<p class="err" data-err="email">
		</p>
	</div>

	<button class="btn primary" type="submit">Simpan perubahan</button>
	<p class="tiny muted">
		Perubahan hanya tersimpan selama sesi ini. Login Google dan akun backend belum terhubung.
	</p>
</form>
<?php get_template_part( 'template-parts/shell', 'close' ); get_footer();
