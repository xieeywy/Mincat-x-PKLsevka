/**
 * Mincy: panel teman panduan. Isi panel dirender di footer.php; skrip ini hanya membuka dan menutup panel
 * (dengan kelas mc-open, supaya transisi CSS bisa berjalan).
 */
(function () {
	function panel() {
		return document.getElementById('mincyPanel');
	}
	function isOpen(p) {
		return p.classList.contains('mc-open');
	}
	window.mincyToggle = function (e) {
		if (e) {
			e.stopPropagation();
		}
		var p = panel();
		if (p) {
			p.classList.toggle('mc-open', !isOpen(p));
		}
	};
	document.addEventListener('click', function (e) {
		var p = panel();
		if (!p || !isOpen(p)) {
			return;
		}
		if (!p.contains(e.target) && !(e.target.closest && e.target.closest('.mc-center, .mc-fab'))) {
			p.classList.remove('mc-open');
		}
	});
	document.addEventListener('keydown', function (e) {
		var p = panel();
		if (p && e.key === 'Escape') {
			p.classList.remove('mc-open');
		}
	});
})();
