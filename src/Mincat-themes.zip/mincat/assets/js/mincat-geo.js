/**
 * Ambil lokasi saat ini untuk kolom koordinat di profil siswa (opsional).
 * Setelah lokasi didapat, kolom alamat diisi otomatis (hanya kalau masih kosong).
 * Pesan galat dibuat sesuai penyebabnya, dan alamat tetap bisa diisi manual.
 */
function mcFillAddress(f, lat, lng) {
	var ta = f.querySelector('textarea[name="alamat"]');
	if (!ta || ta.value.trim() !== '') {
		return;
	}
	fetch('https://nominatim.openstreetmap.org/reverse?format=jsonv2&accept-language=id&zoom=18&lat=' + lat + '&lon=' + lng, {
		headers: { 'Accept': 'application/json' }
	}).then(function (r) {
		return r.ok ? r.json() : null;
	}).then(function (d) {
		if (d && d.display_name && ta.value.trim() === '') {
			ta.value = d.display_name;
		}
	}).catch(function () {});
}
window.mcGeo = function (btn) {
	var f = btn.form;
	if (!navigator.geolocation) {
		alert('Perangkat ini tidak mendukung lokasi. Isi alamat secara manual saja.');
		return;
	}
	btn.disabled = true;
	btn.textContent = 'Mengambil lokasi...';
	navigator.geolocation.getCurrentPosition(function (p) {
		var lat = p.coords.latitude.toFixed(6);
		var lng = p.coords.longitude.toFixed(6);
		f.querySelector('input[name="lat"]').value = lat;
		f.querySelector('input[name="lng"]').value = lng;
		mcFillAddress(f, lat, lng);
		btn.textContent = 'Lokasi diambil. Simpan profil untuk menyimpan.';
		btn.disabled = false;
	}, function (err) {
		btn.textContent = 'Ambil lokasi saat ini';
		btn.disabled = false;
		var pesan = 'Lokasi belum bisa diambil.';
		if (err && err.code === 1) {
			pesan = 'Izin lokasi untuk mincat.my.id belum diberikan. Buka pengaturan situs di Chrome, lalu izinkan Lokasi.';
		} else if (err && err.code === 2) {
			pesan = 'Lokasi tidak terdeteksi. Pastikan GPS HP menyala, lalu coba lagi.';
		} else if (err && err.code === 3) {
			pesan = 'Waktu pengambilan lokasi habis. Coba lagi di tempat yang sinyalnya lebih baik.';
		}
		alert(pesan + ' Kamu tetap bisa mengisi alamat secara manual.');
	}, { enableHighAccuracy: true, timeout: 20000, maximumAge: 300000 });
};
