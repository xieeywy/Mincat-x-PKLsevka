/**
 * Tombol aksi (data-mincat-action). Semua aksi dikirim ke endpoint admin-post mincat_act.
 */
(function () {
	var cfg = window.MINCAT_ACT || {};

	function findButton(e) {
		var path = e.composedPath ? e.composedPath() : [];
		for (var i = 0; i < path.length; i++) {
			var n = path[i];
			if (n && n.hasAttribute && n.hasAttribute('data-mincat-action')) {
				return n;
			}
		}
		return null;
	}

	function send(fields) {
		var body = new URLSearchParams(fields);
		body.append('action', 'mincat_act');
		body.append('_wpnonce', cfg.nonce);
		return fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				if (!j.success) {
					throw new Error((j.data && j.data.msg) || 'Aksi gagal.');
				}
				return j.data || {};
			});
	}

	function downloadForm(fields) {
		var f = document.createElement('form');
		f.method = 'POST';
		f.action = cfg.ajax;
		Object.keys(fields).forEach(function (k) {
			var i = document.createElement('input');
			i.type = 'hidden';
			i.name = k;
			i.value = fields[k];
			f.appendChild(i);
		});
		document.body.appendChild(f);
		f.submit();
		f.remove();
	}

	function done(p, msg) {
		p.then(function () { if (msg) { alert(msg); } location.reload(); })
			.catch(function (err) { alert(err.message); });
	}

	document.addEventListener('click', function (e) {
		var btn = findButton(e);
		if (!btn) {
			return;
		}
		var act = btn.getAttribute('data-mincat-action');
		var id = btn.getAttribute('data-id') || btn.getAttribute('data-job') || '';
		e.preventDefault();

		if (act === 'download-my-data') {
			downloadForm({ action: 'mincat_act', _wpnonce: cfg.nonce, do: 'download_data' });
		} else if (act === 'toggle-consent') {
			done(send({ do: 'toggle_consent', key: btn.getAttribute('data-key') || '' }));
		} else if (act === 'toggle-save') {
			done(send({ do: 'toggle_save', id: btn.getAttribute('data-job') || '' }));
		} else if (act === 'set-job-status') {
			done(send({ do: 'set_job_status', id: id, status: btn.getAttribute('data-status') || '' }));
		} else if (act === 'toggle-notif') {
			done(send({ do: 'toggle_notif' }));
		} else if (act === 'bagikan-kontak') {
			done(send({ do: 'bagikan_kontak', id: id }), 'Kontakmu dibagikan ke perusahaan.');
		} else if (act === 'tolak-pesan') {
			done(send({ do: 'tolak_pesan', id: id }));
		} else if (act === 'share-portfolio') {
			send({ do: 'share_portfolio', id: id }).then(function (d) {
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(d.url).then(function () { alert('Tautan disalin:\n' + d.url); }, function () { prompt('Salin tautan ini:', d.url); });
				} else {
					prompt('Salin tautan ini:', d.url);
				}
			}).catch(function (err) { alert(err.message); });
		} else if (act === 'print-portfolio') {
			window.open((cfg.detail || '') + '?karya=' + encodeURIComponent(id) + '&cetak=1', '_blank');
		} else if (act === 'confirm-delete') {
			var c = prompt('Ini menghapus akun dan semua datamu. Ketik HAPUS untuk melanjutkan.');
			if (c === 'HAPUS') {
				send({ do: 'confirm_delete', confirm: c }).then(function (d) {
					location.href = d.redirect || '/';
				}).catch(function (err) { alert(err.message); });
			}
		}
	}, true);
})();
