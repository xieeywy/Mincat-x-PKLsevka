<?php
/**
 * Panduan: portofolio (halaman sendiri). Isi ada di inc/mincat-panduan.php.
 *
 * @package mincat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
mincat_render_panduan( 'portofolio', 'panduan-portofolio' );
