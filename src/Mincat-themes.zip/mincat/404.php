<?php
/** Halaman tidak ditemukan. */
get_header();
?>
<section class="page-head">
	<h1>
		Halaman tidak ditemukan
	</h1>
	<p class="lead">
		Halaman ini belum tersedia. Kalau kamu admin, pastikan halaman dengan slug yang sesuai sudah dibuat dan berstatus Published.
	</p>
</section>
<p>
	<a class="btn primary small" href="<?php echo esc_url( home_url( '/' ) ); ?>">Kembali ke beranda</a>
</p>
<?php get_footer(); ?>
