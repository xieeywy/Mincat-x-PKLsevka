<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}
$mincat_role = mincat_role();
if ( $mincat_role && 'visitor' !== $mincat_role ) {
	$mincat_nav = mincat_role_nav();
	wp_safe_redirect( mincat_url( $mincat_nav[ $mincat_role ][0][0] ) );
	exit;
}
$mincat_pf     = mincat_profile();
$mincat_labels = mincat_role_label();
$mincat_mine   = mincat_requests_for( $mincat_pf['email'] );
$mincat_last   = $mincat_mine ? $mincat_mine[0] : null;
$mincat_note   = '';
$mincat_reqerr = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( $_GET['err'] ) ) : '';
if ( $mincat_last && 'ditolak' === $mincat_last['status'] ) {
	$mincat_note = '<p class="err">Permintaan ditolak. ' . esc_html( $mincat_last['note'] ? $mincat_last['note'] : 'Hubungi admin sekolah.' ) . '</p>';
}
set_query_var( 'mincat_page', 'verifikasi' );
get_header();
if ( $mincat_last && 'menunggu' === $mincat_last['status'] ) { get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Akun kamu sedang diverifikasi', 'Permintaan akses sudah dikirim. Kamu akan melihat halaman utamamu setelah disetujui.' ); ?>

	<div class="panel">
		<b>Peran diminta: <?php echo esc_html( $mincat_labels[ $mincat_last['role'] ] ); ?></b>
		<p class="tiny muted">
			Dikirim <?php echo esc_html( $mincat_last['t'] ); ?>. Menunggu persetujuan admin sekolah atau tim MINCAT.
		</p>
	</div>
<?php } else { get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Lengkapi permintaan akses', 'Akunmu berstatus Visitor. Pilih peranmu, lalu admin akan memeriksa sebelum data bisa dibuka.' ); ?>

	<?php echo $mincat_note; ?>

	<form class="panel" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
		<input type="hidden" name="action" value="mincat_submit_request"><?php wp_nonce_field( 'mincat_submit_request' ); ?>

		<div class="field">
			<label for="req-role">Saya adalah</label><select id="req-role" name="role" class="fld"><option value="siswa">Siswa</option><option value="guru">Guru pembimbing</option><option value="perusahaan">Perusahaan</option><option value="wali">Wali siswa</option></select>
		</div>
		<div id="reqFields">
			<div class="field">
				<label>Nama lengkap</label><input name="nama" class="fld" value="<?php echo esc_attr( $mincat_pf['name'] ); ?>">
			</div>
			<div class="field">
				<label>Sekolah atau perusahaan</label><input name="sekolah" class="fld" placeholder="contoh: SMK Negeri 1">
			</div>
			<div class="field">
				<label>Kelas dan jurusan (khusus siswa)</label><input name="kelas" class="fld" placeholder="contoh: XII TKJ 1">
			</div>
			<label class="chk"><input type="checkbox" name="wali"> Wali sudah tahu dan menyetujui akun ini (wajib untuk siswa)</label>
		</div>
		<p class="err" id="reqErr">
			<?php echo esc_html( $mincat_reqerr ); ?>
		</p>
		<button class="btn primary small" type="submit">Kirim permintaan</button>
	</form>
<?php }
get_template_part( 'template-parts/shell', 'close' );
get_footer();
