<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mincat_role = mincat_role();
if ( ! is_user_logged_in() ) {
	wp_safe_redirect( mincat_url( 'masuk' ) );
	exit;
}
if ( 'visitor' === $mincat_role ) {
	wp_safe_redirect( mincat_url( 'verifikasi' ) );
	exit;
}
$mincat_dash = ! in_array( $mincat_role, array( 'wali', 'admin' ), true );
set_query_var( 'mincat_dash', $mincat_dash );
set_query_var( 'mincat_page', 'akun' );
get_header();
if ( 'wali' === $mincat_role ) {
	$mincat_child    = (int) get_user_meta( get_current_user_id(), 'mincat_anak_id', true );
	$mincat_anak     = (string) get_user_meta( get_current_user_id(), 'mincat_anak', true );
	$mincat_anak     = '' !== $mincat_anak ? $mincat_anak : '-';
	$mincat_verified = 0;
	foreach ( mincat_projects( $mincat_child ) as $p ) {
		if ( 'verified' === $p['k'] ) {
			$mincat_verified++;
		}
	}
	$mincat_c = mincat_consent( $mincat_child );
	get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Anak saya', 'Pantau perkembangan anakmu dan atur persetujuan tampilan datanya.' ); ?>

	<div class="panel">
		<b>Akun anak: <?php echo esc_html( $mincat_anak ); ?></b>
		<p class="tiny muted">
			Karya terverifikasi: <?php echo (int) $mincat_verified; ?> · Lamaran: <?php echo (int) count( mincat_apps( $mincat_child ) ); ?> · Jurnal: <?php echo (int) count( mincat_jurnal( $mincat_child ) ); ?>
		</p>
	</div>
	<div class="sec-head" style="margin:14px 0 8px">
		<b>Persetujuan</b>
	</div>
	<?php $mincat_k = 'showcase'; ?>
	<div class="ak-card" style="margin:0 0 10px;display:flex;justify-content:space-between;gap:12px;align-items:center">
		<div>
			<b>Tampilkan karya di halaman utama</b>
			<p class="tiny muted" style="margin:2px 0 0">
				Karya terverifikasi tampil di landing, tanpa nama lengkap.
			</p>
		</div>
		<button class="btn <?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'secondary' : 'primary'; ?> small" data-mincat-action="toggle-consent" data-key="showcase"><?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'Cabut' : 'Setujui'; ?></button>
	</div>
	<?php $mincat_k = 'share'; ?>
	<div class="ak-card" style="margin:0 0 10px;display:flex;justify-content:space-between;gap:12px;align-items:center">
		<div>
			<b>Bagikan tautan portofolio</b>
			<p class="tiny muted" style="margin:2px 0 0">
				Anak boleh membuat tautan portofolio untuk perusahaan.
			</p>
		</div>
		<button class="btn <?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'secondary' : 'primary'; ?> small" data-mincat-action="toggle-consent" data-key="share"><?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'Cabut' : 'Setujui'; ?></button>
	</div>
	<?php $mincat_k = 'kontak'; ?>
	<div class="ak-card" style="margin:0 0 10px;display:flex;justify-content:space-between;gap:12px;align-items:center">
		<div>
			<b>Dihubungi perusahaan lewat MINCAT</b>
			<p class="tiny muted" style="margin:2px 0 0">
				Perusahaan bisa mengirim pesan. Kontak anak hanya dibagikan jika anak setuju.
			</p>
		</div>
		<button class="btn <?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'secondary' : 'primary'; ?> small" data-mincat-action="toggle-consent" data-key="kontak"><?php echo ! empty( $mincat_c[ $mincat_k ] ) ? 'Cabut' : 'Setujui'; ?></button>
	</div>
	<a class="btn secondary small" style="margin-top:8px" href="<?php echo esc_url( wp_logout_url( mincat_url( 'home' ) ) ); ?>">Keluar</a><?php
} elseif ( 'admin' === $mincat_role ) {
	$mincat_labels = mincat_role_label();
	$mincat_reqs   = mincat_requests_all();
	$mincat_pend   = array();
	foreach ( mincat_jobs() as $j ) {
		if ( 'menunggu' === $j[9] ) {
			$mincat_pend[] = $j;
		}
	}
	get_template_part( 'template-parts/shell', 'open' ); ?><?php echo mincat_title( 'Verifikasi akun', 'Setujui atau tolak permintaan akses. Permintaan dari siswa dan guru diperiksa admin sekolah.' ); ?>

	<div class="panel" style="margin-bottom:16px">
		<b>Menu</b>
		<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
			<?php foreach ( mincat_role_menu_links() as $mincat_m ) { ?><a href="<?php echo esc_url( mincat_url( $mincat_m[0] ) ); ?>" style="display:inline-block;padding:9px 14px;border:1px solid #dfe7f1;border-radius:10px;color:#0b1734;text-decoration:none;font-weight:600;font-size:13px;background:#fff"><?php echo esc_html( $mincat_m[1] ); ?></a><?php } ?>
		</div>
	</div>
	<div class="panel" style="margin-bottom:16px">
		<b>Daftar PKL</b>
		<p class="tiny muted" style="margin:4px 0 10px">
			Impor 56 IDUKA dan bengkel (TKJ dan TSM) sebagai lowongan PKL yang tersedia. Data yang sudah ada tidak akan digandakan.
		</p>
		<?php if ( isset( $_GET['impor'] ) ) { ?>
			<p class="tiny" style="color:#0C7A4B;margin:0 0 10px">
				Impor selesai: <?php echo absint( $_GET['tambah'] ?? 0 ); ?> ditambahkan, <?php echo absint( $_GET['lewati'] ?? 0 ); ?> sudah ada.
			</p>
		<?php } ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
			<input type="hidden" name="action" value="mincat_import_pkl"><?php wp_nonce_field( 'mincat_import_pkl' ); ?><button class="btn primary small" type="submit">Impor daftar PKL</button>
		</form>
	</div>
	<div class="sec-head" style="margin:0 0 8px">
		<b>Permintaan akses</b>
	</div>
	<div class="panel">
		<?php if ( $mincat_reqs ) { foreach ( $mincat_reqs as $r ) { ?>
				<div class="ak-card" style="margin:0 0 10px">
					<div class="ak-card-head">
						<b><?php echo esc_html( $r['name'] ); ?></b><?php echo mincat_status( 'menunggu' === $r['status'] ? 'Menunggu' : ( 'disetujui' === $r['status'] ? 'Disetujui' : 'Ditolak' ), 'disetujui' === $r['status'] ? 'verified' : ( 'ditolak' === $r['status'] ? 'revision' : 'review' ) ); ?>
					</div>
					<p class="tiny muted">
						<?php echo esc_html( $mincat_labels[ $r['role'] ] ); ?> · <?php echo esc_html( $r['email'] ); ?> · <?php echo esc_html( $r['t'] ); ?>
					</p>
					<p class="tiny">
						<?php echo esc_html( mincat_req_data_line( $r['data'] ) ); ?>
					</p>
					<?php if ( 'menunggu' === $r['status'] ) { ?>
						<div class="app-acts">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
								<input type="hidden" name="action" value="mincat_request_decision"><input type="hidden" name="id" value="<?php echo (int) $r['id']; ?>"><input type="hidden" name="decision" value="disetujui"><?php wp_nonce_field( 'mincat_decide_' . $r['id'], '_wpnonce', false ); ?><?php if ( 'siswa' === get_post_meta( $r['id'], 'role', true ) ) { ?><select name="guru" required style="display:inline-block;width:auto;margin-right:6px"><option value="">Pilih guru</option><?php foreach ( get_users( array( 'role' => 'mincat_teacher' ) ) as $mincat_g ) { ?><option value="<?php echo (int) $mincat_g->ID; ?>"><?php echo esc_html( $mincat_g->display_name ); ?></option><?php } ?></select><?php } ?><button class="btn primary small" type="submit">Setujui</button>
							</form>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
								<input type="hidden" name="action" value="mincat_request_decision"><input type="hidden" name="id" value="<?php echo (int) $r['id']; ?>"><input type="hidden" name="decision" value="ditolak"><?php wp_nonce_field( 'mincat_decide_' . $r['id'], '_wpnonce', false ); ?><button class="btn secondary small" type="submit">Tolak</button>
							</form>
						</div>
					<?php } ?>
				</div>
			<?php } } else { echo mincat_empty_box( 'Belum ada permintaan.', 'Permintaan akses dari visitor akan tampil di sini.' ); } ?>
	</div>
	<div class="sec-head" style="margin:18px 0 8px">
		<b>Lowongan menunggu</b>
	</div>
	<div class="panel">
		<?php if ( $mincat_pend ) { foreach ( $mincat_pend as $j ) { ?>
				<div class="ak-card" style="margin:0 0 10px">
					<div class="ak-card-head">
						<b><?php echo esc_html( $j[0] ); ?></b><?php echo mincat_status( 'Menunggu', 'review' ); ?>
					</div>
					<p class="tiny muted">
						<?php echo esc_html( $j[1] ); ?> · <?php echo esc_html( $j[2] ); ?> · <?php echo esc_html( $j[3] ); ?> · batas <?php echo esc_html( $j[6] ); ?>
					</p>
					<div class="app-acts">
						<button class="btn primary small" data-mincat-action="set-job-status" data-id="<?php echo (int) $j['id']; ?>" data-status="disetujui">Setujui</button><button class="btn secondary small" data-mincat-action="set-job-status" data-id="<?php echo (int) $j['id']; ?>" data-status="ditolak">Tolak</button>
					</div>
				</div>
			<?php } } else { ?>
			<p class="tiny muted">
				Tidak ada lowongan yang menunggu.
			</p>
		<?php } ?>
	</div>
	<?php
}
if ( ! $mincat_dash ) {
	get_template_part( 'template-parts/shell', 'close' );
}
get_footer();
