<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
set_query_var( 'mincat_page', 'home' );
get_header();
$mincat_lg        = mincat_logged_in();
$mincat_nav       = mincat_role_nav();
$mincat_home0     = $mincat_lg ? $mincat_nav[ mincat_nav_role() ][0][0] : 'masuk';
$mincat_home0_url = mincat_url( $mincat_home0 );
?>
<section class="hero-simple">
	<div class="hs-inner">
		<div class="eyebrow">
			<img class="hs-logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mincat-x-smkn7.webp?v=<?php echo esc_attr( MINCAT_VERSION ); ?>" alt="MINCAT x SMKN 7 Kendal" width="360" height="74">
		</div>
		<?php if ( $mincat_lg ) : ?><p class="hs-sub">Selamat datang kembali, <?php echo esc_html( mincat_first_name() ); ?></p><?php endif; ?>
		<h1>
			Karyamu,<em>jalan PKL-mu.</em>
		</h1>
		<?php if ( ! $mincat_lg ) : ?><p class="hs-sub">Find &amp; be your journey</p><?php endif; ?>
		<div class="hs-chips">
			<?php if ( $mincat_lg ) : ?>
			<span class="hs-chip">Karya nyata</span>
			<span class="hs-chip">Review guru</span>
			<span class="hs-chip">Lamar PKL</span>
			<?php else : ?>
			<span class="hs-chip">Informasi PKL</span>
			<span class="hs-chip">Portofolio</span>
			<span class="hs-chip">SMKN 7 KENDAL</span>
			<?php endif; ?>
		</div>
		<div class="hero-actions">
			<a class="btn primary" href="<?php echo esc_url( $mincat_home0_url ); ?>"><?php echo $mincat_lg ? 'Buka dashboard' : 'Start your journey'; ?></a>
		</div>
		<p class="hs-note">Karya yang diverifikasi guru menjadi bukti kemampuanmu.</p>
	</div>
</section>

<section class="home-section" id="karya">
	<div class="section-heading">
		<div>
			<div class="eyebrow">
				Karya pilihan
			</div>
			<h2>
				Lihat Portofolio siswa<br><em>yang sudah terverifikasi.</em>
			</h2>
		</div>
	</div>
	<?php $mincat_list = mincat_showcase_projects();
	if ( ! $mincat_list ) { echo mincat_empty_box( 'Belum ada karya yang ditampilkan.', 'Siswa bisa memilih menampilkan karya terverifikasinya di halaman ini.' ); } else { ?>
		<div class="showcase">
			<?php foreach ( $mincat_list as $p ) { ?>
				<article class="showcase-card">
					<?php echo $p['banner_html']; ?>
					<div class="showcase-head">
						<span class="avatar"<?php echo $p['photo'] ? ' style="padding:0;overflow:hidden"' : ''; ?>><?php if ( $p['photo'] ) { ?><img src="<?php echo esc_url( $p['photo'] ); ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%"><?php } else { echo esc_html( $p['ini'] ); } ?></span>
						<div>
							<b>Siswa <?php echo esc_html( $p['jur'] ); ?></b><small><?php echo esc_html( $p['c'] ); ?></small>
						</div>
					</div>
					<h3>
						<?php echo esc_html( $p['t'] ); ?>
					</h3>
					<p class="tiny muted">
						<?php echo esc_html( $p['d'] ); ?>
					</p>
					<div class="tags">
						<?php foreach ( $p['tools'] as $tool ) { ?><span class="pill"><?php echo esc_html( $tool ); ?></span><?php } ?>
					</div>
					<div style="margin-top:12px">
						<?php echo mincat_status( 'Terverifikasi', 'verified' ); ?>
					</div>
					<a class="link" style="display:inline-block;margin-top:12px;font-weight:600" href="<?php echo esc_url( mincat_logged_in() ? add_query_arg( 'karya', (int) $p['id'], mincat_url( 'portofolio-detail' ) ) : mincat_url( 'masuk' ) ); ?>"><?php echo mincat_logged_in() ? 'Lihat detail' : 'Masuk untuk lihat detail'; ?> <?php echo mincat_ic( 'arrow' ); ?></a>
				</article>
			<?php } ?>
		</div>
	<?php } ?>

	<p class="data-note">
		Hanya karya yang sudah diverifikasi guru dan dipilih siswa untuk ditampilkan.
	</p>
</section>

<section class="home-section">
	<div class="section-heading">
		<div>
			<div class="eyebrow">
				Contoh peluang
			</div>
			<h2>
				Daftar tempat PKL<br><em>yang tersedia</em>
			</h2>
		</div>
	</div>
	<div class="opportunity-preview">
		<?php foreach ( array_slice( mincat_approved_jobs(), 0, 6 ) as $j ) { ?>
			<article class="op-preview">
				<div class="op-preview-top">
					<span class="op-type"><?php echo esc_html( $j[3] ); ?></span>
				</div>
				<h3>
					<?php echo esc_html( $j[0] ); ?>
				</h3>
				<p>
					<?php echo esc_html( $j[1] ); ?>
				</p>
				<div class="op-meta">
					<span><?php echo esc_html( $j[2] ); ?></span><span><?php echo esc_html( $j[4] ); ?></span>
				</div>
				<a class="enter-btn" href="<?php echo esc_url( mincat_url( 'masuk' ) ); ?>">Enter</a>
			</article>
		<?php } ?>
	</div>
	<p class="data-note">
		Mulai Pengalaman Kerjamu di Sini
	</p>
</section>

<section class="closing-cta">
	<div class="eyebrow">
		Mulai dari sini
	</div>
	<h2>
		Daftar Portofolio siswa<br><em>SMKN 7 KENDAL</em>
	</h2>
	<p>
		<?php echo $mincat_lg ? 'Lanjutkan karyamu, atau cek peluang PKL yang baru.' : 'Masuk untuk membuat karyamu pertama, atau lihat peranmu di MINCAT.'; ?>
	</p>
	<a class="btn primary" href="<?php echo esc_url( $mincat_home0_url ); ?>"><?php echo $mincat_lg ? 'Buka dashboard' : 'Masuk'; ?></a>
</section>

<?php get_footer();
